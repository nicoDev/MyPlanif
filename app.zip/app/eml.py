"""Construction d'un brouillon .eml (en-tête X-Unsent) qu'Outlook ouvre comme message à modifier."""
import mimetypes
import re
from email import policy
from email.message import EmailMessage
from pathlib import Path


def _liste(adresses):
    """Adresses séparées par « ; » ou « , » (saisie Outlook) -> en-tête RFC avec virgules."""
    return ", ".join(a.strip() for a in re.split(r"[;,]", adresses or "") if a.strip())


def construire_eml(objet, corps_html, destinataires, cc, expediteur, pieces, dossier_images):
    """Retourne les octets du message. `expediteur` vide : aucun en-tête From (Outlook utilise la boîte de la personne)."""
    m = EmailMessage(policy=policy.SMTP)
    m["X-Unsent"] = "1"
    if expediteur:
        m["From"] = expediteur
    m["To"] = _liste(destinataires)
    if cc:
        m["Cc"] = _liste(cc)
    m["Subject"] = objet
    m.set_content("Ce message est au format HTML.")
    m.add_alternative(corps_html, subtype="html")
    html = m.get_payload()[1]
    for cid in sorted(set(re.findall(r"cid:([\w-]+)", corps_html))):
        trouves = list(Path(dossier_images).glob(cid + ".*"))
        if trouves:
            f = trouves[0]
            mt = mimetypes.guess_type(f.name)[0] or "image/png"
            html.add_related(f.read_bytes(), *mt.split("/"), cid=f"<{cid}>", filename=f.name)
    for p in pieces:
        p = Path(p)
        mt = mimetypes.guess_type(p.name)[0] or "application/octet-stream"
        m.add_attachment(p.read_bytes(), maintype=mt.split("/")[0], subtype=mt.split("/")[1], filename=p.name)
    return m.as_bytes()
