"""Lecture du fichier planning ERP (Planning.xlsx) et conversion au format compact lu par l'interface.

Même format que l'ancien erp-data.json : {rev, updatedAt, keys, dict, n, orders, rows}.
Chaque ligne est une liste de codes (index dans « dict »), sauf la quantité « q » qui reste un nombre.
"""
import datetime
import json
import os
import re
import unicodedata
from pathlib import Path

from openpyxl import load_workbook

COLONNES = {'N° COMMANDE': 'o', 'VOTRE RÉFÉRENCE': 'ref', 'DATE DE SAISIE': 'd', 'ÉTAT COMMANDE': 'et',
            'STATUT DE LA PIÈCE': 'st', 'NOM SITE': 'site', 'CODE POSTAL SITE': 'cp', 'VILLE SITE': 'ville',
            'COMMERCIAL PRINCIPAL': 'com', 'PERSONNE PLANNING': 'plan', 'REFERENCE ARTICLE': 'art', 'GROUPE': 'grp',
            'FAMILLE': 'fam', 'ACTIVITE': 'act', 'DESIGNATION ARTICLE': 'des', 'QUANTITE': 'q', 'ÉTAT LIGNE': 'el',
            'BL N°': 'bl', 'DATE BL': 'dbl', 'FACTURE N°': 'fac', 'DELAI DEMANDE': 'dd', 'DELAI ACCEPTE': 'da',
            'DELAI REPORTE': 'dr', 'PIÈCE CONFIRMÉE': 'conf', 'CODE OP': 'op', 'SOUS REFERENCE': 'sref'}
CLES_DATE = {'d', 'dbl', 'dd', 'da', 'dr'}


def _nh(s):
    sans = ''.join(c for c in unicodedata.normalize('NFD', str(s)) if unicodedata.category(c) != 'Mn')
    return re.sub(r'[^a-z0-9]', '', sans, flags=re.I).upper()


_HM = {_nh(k): v for k, v in COLONNES.items()}


def _texte(v, cle):
    if v is None:
        return ''
    if cle in CLES_DATE:
        if isinstance(v, (datetime.datetime, datetime.date)):
            return v.strftime('%Y-%m-%d')
        return str(v).strip()[:10]
    if isinstance(v, float) and v == int(v):
        return str(int(v))
    return str(v).strip()


def lire_classeur(chemin):
    """Retourne (keys, rows_brutes) de la feuille de données (DATA_ERP de préférence)."""
    wb = load_workbook(chemin, read_only=True, data_only=True)
    try:
        noms = sorted(wb.sheetnames, key=lambda n: _nh(n) not in ('DATAERP', 'DONNEES'))
        for nom in noms:
            ws = wb[nom]
            cols = None
            lignes = []
            for i, row in enumerate(ws.iter_rows(values_only=True)):
                if cols is None:
                    if i >= 15:
                        break
                    if any(c is not None and _nh(c) == 'NCOMMANDE' for c in row):
                        vus, cols = set(), []
                        for j, c in enumerate(row):
                            cle = _HM.get(_nh(c)) if c is not None else None
                            if cle and cle not in vus:
                                vus.add(cle)
                                cols.append((j, cle))
                    continue
                lignes.append(row)
            if cols:
                return cols, lignes
        raise ValueError("Colonne « N° COMMANDE » introuvable dans les 15 premières lignes d'aucune feuille.")
    finally:
        wb.close()


def encoder(chemin, mis_a_jour):
    cols, lignes = lire_classeur(chemin)
    keys = [k for _, k in cols]
    ci = keys.index('o')
    dic, idx = [''], {'': 0}

    def code(s):
        if s not in idx:
            idx[s] = len(dic)
            dic.append(s)
        return idx[s]

    rows = []
    for row in lignes:
        brut = [row[j] if j < len(row) else None for j, _ in cols]
        if brut[ci] is None or str(brut[ci]).strip() == '':
            continue
        r = []
        for v, k in zip(brut, keys):
            if k == 'q':
                try:
                    q = float(v) if v is not None and str(v).strip() != '' else 0.0
                except (TypeError, ValueError):
                    q = 0.0
                r.append(int(q) if q == int(q) else q)
            else:
                r.append(code(_texte(v, k)))
        rows.append(r)
    commandes = len({dic[r[ci]] for r in rows})
    rev = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S')
    return {'rev': rev, 'updatedAt': mis_a_jour, 'keys': keys, 'dict': dic, 'n': len(rows), 'orders': commandes, 'rows': rows}


def ecrire(data, destination):
    destination = Path(destination)
    tmp = destination.with_suffix('.tmp')
    tmp.write_text(json.dumps(data, ensure_ascii=False, separators=(',', ':')), encoding='utf-8')
    os.replace(tmp, destination)
