"""MyPlanif : suivi des commandes ERP + préparation des mails de planification (logique de Horizon 1.5.0).

Variables d'environnement :
  DATA_DIR      dossier de données persistant (sur Railway : le point de montage du volume, ex. /data)
  ACCESS_CODE   code d'accès commun aux utilisateurs (vide : aucun code demandé)
  UPLOAD_TOKEN  jeton du script qui envoie Planning.xlsx (vide : l'envoi est refusé)
"""
import base64
from contextlib import asynccontextmanager
import hashlib
import hmac
import json
import mimetypes
import os
import re
import shutil
import sys
import time
import unicodedata
import secrets
import uuid
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import quote

from starlette.applications import Starlette
from starlette.exceptions import HTTPException
from starlette.requests import Request
from starlette.responses import FileResponse, JSONResponse, Response
from starlette.routing import Mount, Route
from starlette.staticfiles import StaticFiles

DATA = Path(os.environ.get("DATA_DIR", Path(__file__).resolve().parent.parent / "data")).resolve()
DATA.mkdir(parents=True, exist_ok=True)
(DATA / "uploads").mkdir(exist_ok=True)
os.environ.setdefault("PLANIF_REGLAGES", str(DATA / "reglages"))      # lu par partage.py
os.environ.setdefault("PLANIF_REGLAGES_ANCIEN", str(DATA / "reglages_ancien"))

HORIZON = Path(__file__).resolve().parent / "horizon"
sys.path.insert(0, str(HORIZON))
import adresses  # noqa: E402
import core  # noqa: E402
import import_excel  # noqa: E402
from . import auto, eml, erp  # noqa: E402

# La configuration (intervenants, types, prérequis) vit dans le dossier de données ; copie initiale depuis le code.
CONFIG = DATA / "config.json"
if not CONFIG.exists():
    shutil.copy(HORIZON / "config.json", CONFIG)
core.CONFIG = CONFIG
core.CARNET = DATA / "destinataires.json"
core.JOURNAL = DATA / "historique.json"
adresses.FICHIER = DATA / "adresses_outlook.json"

ACCESS_CODE = os.environ.get("ACCESS_CODE", "").strip()
UPLOAD_TOKEN = os.environ.get("UPLOAD_TOKEN", "").strip()
SECRET = (os.environ.get("APP_SECRET") or ACCESS_CODE or "dev").encode()
COOKIE = "mp_auth"
ERP_FILE = DATA / "erp-data.json"
UPLOADS = DATA / "uploads"
MAX_UPLOAD = 25 * 1024 * 1024
MAX_ERP = 80 * 1024 * 1024


def _jeton():
    return hmac.new(SECRET, b"mp-session-v1:" + ACCESS_CODE.encode(), hashlib.sha256).hexdigest()


def acces_refuse(request: Request):
    """Réponse 401 si un code d'accès est configuré et que le cookie est absent ou faux ; sinon None."""
    if ACCESS_CODE and not hmac.compare_digest(request.cookies.get(COOKIE, ""), _jeton()):
        return JSONResponse({"detail": "Code d'accès requis."}, status_code=401)
    return None


def protege(fonction):
    async def enveloppe(request: Request):
        refus = acces_refuse(request)
        if refus:
            return refus
        try:
            return await fonction(request)
        except HTTPException as e:
            return JSONResponse({"detail": e.detail}, status_code=e.status_code)
    return enveloppe


_essais = defaultdict(list)


async def login(request: Request):
    corps = await request.json()
    ip = request.client.host if request.client else "?"
    maintenant = time.time()
    _essais[ip] = [t for t in _essais[ip] if maintenant - t < 300]
    if len(_essais[ip]) >= 8:
        return JSONResponse({"detail": "Trop d'essais. Réessayez dans quelques minutes."}, status_code=429)
    _essais[ip].append(maintenant)
    if ACCESS_CODE and not hmac.compare_digest(str(corps.get("code", "")), ACCESS_CODE):
        return JSONResponse({"detail": "Code incorrect."}, status_code=401)
    rep = JSONResponse({"ok": True})
    rep.set_cookie(COOKIE, _jeton() if ACCESS_CODE else "ok", max_age=60 * 60 * 24 * 90, httponly=True,
                   samesite="lax", secure=request.url.scheme == "https")
    return rep


async def health(request: Request):
    return JSONResponse({"ok": True, "erp": ERP_FILE.exists(), "acces": bool(ACCESS_CODE)})


# ---------- données ERP ----------
async def recevoir_erp(request: Request):
    """Envoi de Planning.xlsx par le script du poste (jeton dans l'en-tête X-Upload-Token)."""
    if not UPLOAD_TOKEN or not hmac.compare_digest(request.headers.get("X-Upload-Token", ""), UPLOAD_TOKEN):
        return JSONResponse({"detail": "Jeton d'envoi invalide."}, status_code=403)
    form = await request.form(max_part_size=MAX_ERP)
    fichier = form.get("file")
    if fichier is None or not hasattr(fichier, "read"):
        return JSONResponse({"detail": "Champ « file » manquant."}, status_code=400)
    mis_a_jour = str(form.get("updated_at", ""))
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z", mis_a_jour):
        mis_a_jour = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    if ERP_FILE.exists():
        try:
            actuel = json.loads(ERP_FILE.read_text(encoding="utf-8")).get("updatedAt", "")
        except Exception:
            actuel = ""
        if actuel and actuel >= mis_a_jour:
            return JSONResponse({"ok": True, "statut": "Déjà à jour", "updatedAt": actuel})
    tmp = DATA / "planning_recu.xlsx"
    tmp.write_bytes(await fichier.read())
    try:
        data = erp.encoder(tmp, mis_a_jour)
    except Exception as e:  # fichier illisible : on garde les données précédentes
        return JSONResponse({"detail": f"Lecture impossible : {e}"}, status_code=422)
    if data["n"] < 1000:
        return JSONResponse({"detail": f"Seulement {data['n']} lignes lues : fichier refusé par prudence."}, status_code=422)
    erp.ecrire(data, ERP_FILE)
    return JSONResponse({"ok": True, "statut": "Mise à jour OK", "lignes": data["n"], "commandes": data["orders"],
                         "updatedAt": mis_a_jour})


@protege
async def donnees_erp(request: Request):
    if not ERP_FILE.exists():
        raise HTTPException(404, "Aucune donnée ERP reçue pour le moment.")
    return FileResponse(ERP_FILE, media_type="application/json", headers={"Cache-Control": "no-store"})


# ---------- préparation des mails ----------
def _cfg():
    return core.charger_config()


@protege
async def config(request: Request):
    cfg = _cfg()
    prerequis = {c: {h: list(m) for h, m in cfg["prerequis"][c].items()} for c in ("Link", "Gateway")}
    return JSONResponse({"expediteur": core.expediteur_effectif(cfg),
                         "techniciens": [{"nom": t["nom"], "email": t.get("email", ""), "civilite": t.get("civilite", "M.")}
                                         for t in cfg["techniciens"]],
                         "types": {"metro": list(cfg["types"]), "nc": list(cfg["types_nc"])},
                         "prerequis": prerequis, "defauts_jri": core.defauts_jri(), "aujourdhui": core.aujourdhui()})


@protege
async def deviner(request: Request):
    """Onglet et types proposés d'après les GROUPE des lignes de la commande."""
    cfg = _cfg()
    groupes = (await request.json()).get("groupes", [])
    res = []
    for g in groupes:
        c = import_excel.type_pour_groupe(g, cfg)
        if c and list(c) not in res:
            res.append(list(c))
    return JSONResponse({"propositions": res})


@protege
async def pre_remplir(request: Request):
    """Paramètres du mail déduits des lignes de la commande (voir auto.py)."""
    brut = (await request.json()).get("lignes", [])[:600]
    lignes = []
    for l in brut:
        try:
            q = float(l.get("q") or 0)
        except (TypeError, ValueError):
            q = 0.0
        lignes.append({k: str(l.get(k) or "")[:300] for k in ("grp", "fam", "act", "des", "art", "dr", "dd")} | {"q": q})
    return JSONResponse(auto.proposer(lignes, _cfg()))


@protege
async def suggerer(request: Request):
    texte = str((await request.json()).get("texte", ""))
    sugg = core.suggestions_carnet(core.charger_carnet(), texte)
    return JSONResponse({"suggestions": [{"adresse": a, "texte": core.appliquer_suggestion(texte, a)} for a in sugg]})


def _chemin_upload(ref: str) -> Path:
    p = (UPLOADS / str(ref)).resolve()
    if UPLOADS.resolve() not in p.parents or not p.is_file():
        raise HTTPException(400, f"Fichier joint introuvable : {ref}")
    return p


@protege
async def televerser(request: Request):
    form = await request.form(max_part_size=MAX_UPLOAD)
    res = []
    for f in form.getlist("files"):
        if not hasattr(f, "read"):
            continue
        contenu = await f.read()
        if len(contenu) > MAX_UPLOAD:
            raise HTTPException(413, f"{f.filename} dépasse 25 Mo.")
        dossier = uuid.uuid4().hex
        (UPLOADS / dossier).mkdir()
        nom = core.nettoyer(Path(f.filename or "fichier").name) or "fichier"
        (UPLOADS / dossier / nom).write_bytes(contenu)
        res.append({"id": f"{dossier}/{nom}", "nom": nom, "taille": len(contenu)})
    return JSONResponse(res)


def _intervention(cfg, corps):
    kind = corps.get("kind")
    if kind not in ("metro", "nc", "jri"):
        raise HTTPException(400, "Onglet inconnu.")
    recu = corps.get("iv") or {}
    base = core.nouvelle_intervention(kind, cfg)
    autorises = set(base) - {"id", "statut", "erreur", "fichiers_sup", "fichiers_prec"}
    for k, v in recu.items():
        if k in autorises:
            base[k] = v
    base["fichiers_sup"] = [str(_chemin_upload(r)) for r in recu.get("fichiers_sup", [])]
    base["fichiers_prec"] = {t: str(_chemin_upload(r)) for t, r in (recu.get("fichiers_prec") or {}).items() if r}
    if kind != "jri" and any(t not in core.defs_types(cfg, kind) for t in base.get("types", [])):
        raise HTTPException(400, "Type d'intervention inconnu.")
    for k in ("client", "commande", "destinataires", "technicien"):
        base[k] = str(base.get(k, ""))
    return kind, core.normaliser_iv(kind, base)


def _images_en_ligne(html: str) -> str:
    def remplacer(m):
        trouves = list((HORIZON / "modeles" / "images").glob(m.group(1) + ".*"))
        if not trouves:
            return m.group(0)
        mt = mimetypes.guess_type(trouves[0].name)[0] or "image/png"
        return f"data:{mt};base64,{base64.b64encode(trouves[0].read_bytes()).decode()}"
    return re.sub(r"cid:([\w-]+)", remplacer, html)


def _construire(cfg, kind, iv):
    core.valider(cfg, iv, kind)
    return core.construire_objet(cfg, iv, kind), core.construire_corps(cfg, iv, kind), core.preparer_pieces_jointes(cfg, iv, kind)


@protege
async def apercu(request: Request):
    cfg = _cfg()
    kind, iv = _intervention(cfg, await request.json())
    try:
        objet, corps, pj = _construire(cfg, kind, iv)
    except (ValueError, FileNotFoundError, KeyError) as e:
        return JSONResponse({"ok": False, "erreur": str(e)})
    tech = core.trouver_tech(cfg, iv["technicien"]) or {}
    return JSONResponse({"ok": True, "objet": objet, "corps": _images_en_ligne(corps), "pj": [p.name for p in pj],
                         "expediteur": "" if kind == "nc" else core.expediteur_effectif(cfg),
                         "cc": tech.get("email", "") if iv.get("cc_tech") else "", "bornes": [iv.get("debut"), iv.get("fin")]})


def _fabriquer_eml(cfg, corps_requete):
    kind, iv = _intervention(cfg, corps_requete)
    try:
        objet, corps, pj = _construire(cfg, kind, iv)
    except (ValueError, FileNotFoundError, KeyError) as e:
        raise HTTPException(422, str(e))
    tech = core.trouver_tech(cfg, iv["technicien"]) or {}
    cc = tech.get("email", "") if iv.get("cc_tech") else ""
    expediteur = "" if kind == "nc" else core.expediteur_effectif(cfg)  # Non COFRAC : adresse personnelle
    data = eml.construire_eml(objet, corps, iv["destinataires"].strip(), cc, expediteur, pj, HORIZON / "modeles" / "images")
    core.memoriser_destinataires(iv["destinataires"])
    return data, core.nettoyer(objet.replace(" / ", "_"))[:120] + ".eml"


def _reponse_eml(data, nom):
    ascii_nom = unicodedata.normalize("NFKD", nom).encode("ascii", "ignore").decode() or "brouillon.eml"
    return Response(data, media_type="message/rfc822", headers={
        "Content-Disposition": f"attachment; filename=\"{ascii_nom}\"; filename*=UTF-8''{quote(nom)}",
        "Cache-Control": "no-store"})


@protege
async def brouillon(request: Request):
    data, nom = _fabriquer_eml(_cfg(), await request.json())
    return _reponse_eml(data, nom)


# --- ouverture directe dans Outlook : lien à usage unique lu par l'utilitaire installé sur le PC ---
TMP_EML = DATA / "tmp_eml"
TMP_EML.mkdir(exist_ok=True)
DUREE_LIEN = 300  # secondes
JETON_RE = re.compile(r"[A-Za-z0-9_-]{20,64}")


def _purger_liens():
    for f in TMP_EML.glob("*.eml"):
        try:
            if time.time() - f.stat().st_mtime > DUREE_LIEN:
                f.unlink()
        except OSError:
            pass


@protege
async def lien_brouillon(request: Request):
    data, nom = _fabriquer_eml(_cfg(), await request.json())
    _purger_liens()
    jeton = secrets.token_urlsafe(24)
    (TMP_EML / (jeton + ".eml")).write_bytes(data)
    return JSONResponse({"token": jeton, "nom": nom})


async def lire_lien(request: Request):
    """Pas de cookie ici (l'utilitaire n'en a pas) : le jeton aléatoire, à usage unique et valable 5 minutes, fait foi."""
    jeton = request.path_params["token"]
    f = TMP_EML / (jeton + ".eml")
    if not JETON_RE.fullmatch(jeton) or not f.is_file() or time.time() - f.stat().st_mtime > DUREE_LIEN:
        return JSONResponse({"detail": "Lien expiré."}, status_code=404)
    data = f.read_bytes()
    f.unlink(missing_ok=True)
    return _reponse_eml(data, "brouillon.eml")


async def installeur(request: Request):
    serveur = str(request.base_url).rstrip("/")
    if not re.fullmatch(r"https?://[A-Za-z0-9.:-]+", serveur):
        raise HTTPException(400, "Adresse du serveur inattendue.")
    texte = (Path(__file__).resolve().parent / "outil" / "installer.cmd").read_text(encoding="utf-8").replace("__SERVEUR__", serveur)
    texte = texte.replace("\r\n", "\n").replace("\n", "\r\n")
    return Response(texte.encode("cp1252", "replace"), media_type="application/octet-stream", headers={
        "Content-Disposition": 'attachment; filename="Installer-MyPlanif-Outlook.cmd"', "Cache-Control": "no-store"})


def nettoyer_televersements():
    limite = time.time() - 60 * 60 * 24 * 30
    for d in UPLOADS.iterdir():
        try:
            if d.stat().st_mtime < limite:
                shutil.rmtree(d, ignore_errors=True)
        except OSError:
            pass


@asynccontextmanager
async def cycle_de_vie(_app):
    nettoyer_televersements()
    yield


app = Starlette(
    routes=[
        Route("/api/login", login, methods=["POST"]),
        Route("/api/health", health),
        Route("/api/erp", recevoir_erp, methods=["POST"]),
        Route("/api/erp-data", donnees_erp),
        Route("/api/config", config),
        Route("/api/guess", deviner, methods=["POST"]),
        Route("/api/auto", pre_remplir, methods=["POST"]),
        Route("/api/suggest", suggerer, methods=["POST"]),
        Route("/api/upload", televerser, methods=["POST"]),
        Route("/api/preview", apercu, methods=["POST"]),
        Route("/api/eml", brouillon, methods=["POST"]),
        Route("/api/eml-lien", lien_brouillon, methods=["POST"]),
        Route("/api/eml/{token}", lire_lien),
        Route("/outil/installer", installeur),
        Mount("/", StaticFiles(directory=Path(__file__).resolve().parent / "static", html=True), name="static"),
    ],
    lifespan=cycle_de_vie,
)
