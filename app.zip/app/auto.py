"""Pré-remplissage automatique de la fiche « Planifier » à partir des lignes d'une commande ERP.

Règles (validées avec l'utilisateur) :
- onglet / type : d'après le GROUPE (même logique qu'Horizon) ; à défaut, lignes MySirius / Link / Gateway -> JRI ;
- date : métrologie sur site ou commande sans matériel = délai reporté ; commande avec matériel = délai reporté - 14 jours ouvrés ;
- JRI nature : une référence MySirius dans la commande = installation, sinon extension ;
- l'intervenant n'est jamais déduit (les codes OP_xxx désignent les personnes du planning, pas les intervenants).
Chaque champ incertain ou calculé est listé dans « verif » (affiché en rouge, à confirmer avant la création du mail)."""
import re
from collections import Counter
from datetime import date, datetime, timedelta

import import_excel

DATE_FMT = "%d/%m/%Y"


def _maj(s):
    return (s or "").upper()


def paques(annee):
    a, b, c = annee % 19, annee // 100, annee % 100
    d, e = b // 4, b % 4
    f = (b + 8) // 25
    g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30
    i, k = c // 4, c % 4
    l = (32 + 2 * e + 2 * i - h - k) % 7
    m = (a + 11 * h + 22 * l) // 451
    mois, jour = divmod(h + l - 7 * m + 114, 31)
    return date(annee, mois, jour + 1)


def jours_feries(annee):
    p = paques(annee)
    fixes = [(1, 1), (5, 1), (5, 8), (7, 14), (8, 15), (11, 1), (11, 11), (12, 25)]
    return {date(annee, m, j) for m, j in fixes} | {p + timedelta(days=39), p + timedelta(days=1), p + timedelta(days=50)}


def est_ouvre(d):
    return d.weekday() < 5 and d not in jours_feries(d.year)


def moins_jours_ouvres(d, n):
    while n > 0:
        d -= timedelta(days=1)
        if est_ouvre(d):
            n -= 1
    return d


def _date(iso):
    try:
        return datetime.strptime((iso or "")[:10], "%Y-%m-%d").date()
    except ValueError:
        return None


RE_SERVICE = re.compile(r"M[ÉE]TROLOGIE|SERVICE|^ABO|MAINTENANCE|SUPPORT|R[ÉE]CURRENT|^MAD")
RE_LINK = re.compile(r"\bLINK\b")
RE_GATEWAY = re.compile(r"GATE(A)?WAY")


def proposer(lignes, cfg):
    """lignes : [{grp, fam, act, des, art, dr, q}] d'une commande. Retourne {kind, iv, verif: {champ: raison}}."""
    verif, iv = {}, {}
    desc = [_maj(l.get("des")) for l in lignes]
    fams = [_maj(l.get("fam")) for l in lignes]

    # --- onglet et types -----------------------------------------------------------------
    props = []
    for g in dict.fromkeys(l.get("grp") or "" for l in lignes):
        c = import_excel.type_pour_groupe(g, cfg) if g else None
        if c and list(c) not in props:
            props.append(list(c))
    mysirius = [i for i, d in enumerate(desc) if "MYSIRIUS" in d.replace(" ", "")]
    refs_ms = [i for i in mysirius if not fams[i].startswith(("CONSOMMABLES", "RECURENTS"))]
    jri_signes = bool(mysirius) or any(RE_LINK.search(d) or RE_GATEWAY.search(d) for d, f in zip(desc, fams) if f in ("GATEWAY", "LINKS") or "MYSIRIUS" in f)
    if refs_ms:
        kind = "jri"            # commande mixte (métrologie + MySirius) : intervention JRI
    elif props:
        kind = props[0][0]
        iv["types"] = [n for k, n in props if k == kind]
    elif jri_signes:
        kind = "jri"
    else:
        kind = "metro"
        iv["types"] = []
        verif["kind"] = "Type d'intervention non reconnu dans la commande."
        verif["types"] = "Choisissez le ou les types."

    # --- matériel et date ----------------------------------------------------------------
    # matériel = toute ligne qui n'est pas un service (métrologie, services, abonnements, maintenance, support)
    materiel = any(_maj(l.get("act")).strip() and not RE_SERVICE.search(_maj(l.get("act"))) and (l.get("q") or 0) > 0 for l in lignes)
    sur_site = kind in ("metro", "nc") and any("SUR SITE" in _maj(l.get("grp")) for l in lignes)
    reportes = [d for d in (_date(l.get("dr")) for l in lignes) if d]
    if reportes:
        base = max(reportes)
        if sur_site or not materiel:
            cible = base
            why = f"Délai reporté du {base:{DATE_FMT}} ({'métrologie sur site' if sur_site else 'commande sans matériel'})."
        else:
            cible = moins_jours_ouvres(base, 14)
            why = f"Délai reporté du {base:{DATE_FMT}} moins 14 jours ouvrés (commande avec matériel : toute ligne hors service)."
        txt = f"{cible:{DATE_FMT}}"
        champs = ("deploiement_debut", "deploiement_fin") if kind == "jri" else ("debut", "fin")
        for c in champs:
            iv[c] = txt
            verif[c] = why
    else:
        for c in (("deploiement_debut", "deploiement_fin") if kind == "jri" else ("debut", "fin")):
            dem = [d for d in (_date(l.get("dd")) for l in lignes) if d]
            verif[c] = "Aucun délai reporté dans la commande : saisissez la date." + (f" (délai demandé : {max(dem):{DATE_FMT}})" if dem else "")

    # --- JRI -----------------------------------------------------------------------------
    if kind == "jri":
        # nature : référence MySirius (licence, module, prestation) = installation, sinon extension
        refs = refs_ms
        iv["nature"] = "installation" if refs else "extension"
        if mysirius and not refs:
            verif["nature"] = "Seulement des consommables ou abonnements MySirius : extension supposée."
        # hébergement
        cl = sum(1 for d in desc if "MYSIRIUS" in d.replace(" ", "") and "CLOUD" in d and "SERVEUR" not in d and "SERVER" not in d)
        sv = sum(1 for d in desc if "MYSIRIUS" in d.replace(" ", "") and ("SERVEUR" in d or "SERVER" in d) and "CLOUD" not in d)
        iv["hebergement"] = "Serveur" if sv > cl else "Cloud"
        if cl and sv:
            verif["hebergement"] = "Lignes Cloud et Serveur dans la même commande."
        elif not cl and not sv:
            verif["hebergement"] = "Hébergement non indiqué dans la commande (Cloud par défaut)."
        h = iv["hebergement"]
        iv["mysirius_serveur"] = h == "Serveur"
        # prérequis Link
        liens = [d for d in desc if RE_LINK.search(d)]
        iv["link"] = bool(liens)
        if liens:
            modes = Counter(m for d in liens for m in ("POE", "VDC", "WIFI") if m in d)
            permis = cfg["prerequis"]["Link"].get(h, {})
            mode = next((m for m, _ in modes.most_common() if m in permis), None)
            iv["link_mode"] = mode or "POE"
            if not mode or len(modes) > 1:
                verif["link_mode"] = "Mode du Link non lisible ou multiple dans la commande."
        # prérequis Gateway
        passerelles = [d for d in desc if RE_GATEWAY.search(d)]
        iv["gateway"] = bool(passerelles)
        if passerelles:
            permis = cfg["prerequis"]["Gateway"].get(h, {})
            mode = "4G + ETH" if any("4G" in d for d in passerelles) and "4G + ETH" in permis else "ETH"
            iv["gateway_mode"] = mode
        # formation
        if any("FORMATION" in d for d in desc):
            iv["formation"] = True
            iv["formation_date"] = iv.get("deploiement_fin", "")
            verif["formation_date"] = "Formation présente dans la commande : confirmez la date."
        iv["deploiement"] = True
    return {"kind": kind, "iv": {k: v for k, v in iv.items() if v != ""}, "verif": verif, "materiel": materiel}
