"""Pré-remplissage automatique de la fiche « Planifier » à partir des lignes d'une commande ERP.

Règles (validées avec l'utilisateur) :
- onglet / type : d'après le GROUPE (même logique qu'Horizon) ; à défaut, lignes MySirius / Link / Gateway -> JRI ;
- date : métrologie sur site ou commande sans matériel = délai reporté ; commande avec matériel = délai reporté - 14 jours ouvrés ;
- JRI nature : une référence MySirius dans la commande = installation, sinon extension ;
- l'intervenant n'est jamais déduit (les codes OP_xxx désignent les personnes du planning, pas les intervenants).
Chaque champ incertain ou calculé est listé dans « verif » (affiché en rouge, à confirmer avant la création du mail)."""
import json
import re
from collections import Counter
from datetime import date, datetime, timedelta

import import_excel
from pathlib import Path

DATE_FMT = "%d/%m/%Y"


def _maj(s):
    return (s or "").upper()


def paques(annee):
    a, b, c = annee % 19, annee // 100, annee % 100
    d, e = b // 4, b % 4
    f = (b + 8) // 25
    g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30
    i, k = c // 4, c % 4
    l = (32 + 2 * e + 2 * i - h - k) % 7
    m = (a + 11 * h + 22 * l) // 451
    mois, jour = divmod(h + l - 7 * m + 114, 31)
    return date(annee, mois, jour + 1)


def jours_feries(annee):
    p = paques(annee)
    fixes = [(1, 1), (5, 1), (5, 8), (7, 14), (8, 15), (11, 1), (11, 11), (12, 25)]
    return {date(annee, m, j) for m, j in fixes} | {p + timedelta(days=39), p + timedelta(days=1), p + timedelta(days=50)}


def est_ouvre(d):
    return d.weekday() < 5 and d not in jours_feries(d.year)


def moins_jours_ouvres(d, n):
    while n > 0:
        d -= timedelta(days=1)
        if est_ouvre(d):
            n -= 1
    return d


def _date(iso):
    try:
        return datetime.strptime((iso or "")[:10], "%Y-%m-%d").date()
    except ValueError:
        return None


RE_SERVICE = re.compile(r"M[ÉE]TROLOGIE|SERVICE|^ABO|MAINTENANCE|SUPPORT|R[ÉE]CURRENT|^MAD")
RE_LINK = re.compile(r"\bLINK\b")
RE_GATEWAY = re.compile(r"GATE(A)?WAY")


def norm_des(s):
    """Désignation normalisée (chiffres remplacés par N), clé de la table regles_planification.json."""
    return re.sub(r"\d+([.,]\d+)?", "N", (s or "").upper().strip())


def _regles():
    f = Path(__file__).resolve().parent / "horizon" / "regles_planification.json"
    return json.loads(f.read_text(encoding="utf-8")) if f.exists() else {"designations": {}, "groupes": {}, "service_force": []}


REGLES = _regles()


def _cle_groupe(l):
    return "||".join((l.get(k) or "").strip() for k in ("grp", "fam", "act"))


def _attrs(l):
    """Attributs de la table (onglet, hébergement, prérequis, section) pour la désignation de la ligne, ou None si inconnue."""
    return REGLES["designations"].get(norm_des(l.get("des")))


def proposer(lignes, cfg):
    """lignes : [{grp, fam, act, des, art, dr, dd, q}] d'une commande. Retourne {kind, iv, verif: {champ: raison}}."""
    verif, iv = {}, {}
    desc = [_maj(l.get("des")) for l in lignes]
    fams = [_maj(l.get("fam")) for l in lignes]
    attrs = [_attrs(l) for l in lignes]

    def val(i, cle):
        """Valeur de la table pour la ligne i ; si la désignation est inconnue : None (on se rabat sur la lecture du texte)."""
        return None if attrs[i] is None else attrs[i].get(cle)

    # --- onglet et types -----------------------------------------------------------------
    props = []
    for g in dict.fromkeys(l.get("grp") or "" for l in lignes):
        c = import_excel.type_pour_groupe(g, cfg) if g else None
        if c and list(c) not in props:
            props.append(list(c))
    for i, l in enumerate(lignes):   # lignes COFRAC / Non COFRAC désignées par la table
        o = val(i, "onglet")
        if o in ("Non COFRAC", "Métrologie / COFRAC"):
            carac = "CARACT" in desc[i]
            if o == "Non COFRAC":
                p = ["nc", "Caractérisation non COFRAC" if carac else "Métrologie non COFRAC"]
            else:
                p = ["metro", "Caractérisation COFRAC" if carac else "Métrologie COFRAC"]
            if p not in props and (p[1] in cfg["types"] or p[1] in cfg["types_nc"]):
                props.append(p)
    # référence MySirius : ligne désignée « JRI installation / extension » par la table, ou ligne inconnue de la table citant MySirius
    refs_ms = [i for i in range(len(lignes)) if (val(i, "onglet") or "").startswith("JRI")
               or (attrs[i] is None and "MYSIRIUS" in desc[i].replace(" ", "") and not fams[i].startswith(("CONSOMMABLES", "RECURENTS")))]
    jri_signes = any((val(i, "prerequis") or "") != "" for i in range(len(lignes))) or \
        any(attrs[i] is None and (RE_LINK.search(desc[i]) or RE_GATEWAY.search(desc[i])) for i in range(len(lignes)))
    groupes_jri = any((REGLES["groupes"].get(_cle_groupe(l)) or {}).get("onglet", "").startswith("JRI") for l in lignes)
    if refs_ms:
        kind = "jri"            # commande mixte (métrologie + MySirius) : intervention JRI
    elif props:
        kind = props[0][0]
        iv["types"] = [n for k, n in props if k == kind]
    elif jri_signes:
        kind = "jri"
    elif groupes_jri:
        kind = "jri"
        verif["kind"] = "Onglet JRI par défaut (aucune ligne COFRAC / Non COFRAC sur site) : vérifiez."
    else:
        kind = "metro"
        iv["types"] = []
        verif["kind"] = "Type d'intervention non reconnu dans la commande."
        verif["types"] = "Choisissez le ou les types."

    # --- matériel et date ----------------------------------------------------------------
    # matériel = toute ligne qui n'est pas un service (services, métrologie, abonnements, maintenance, support)
    def est_materiel(l):
        act = _maj(l.get("act")).strip()
        return bool(act) and not RE_SERVICE.search(act) and (l.get("q") or 0) > 0 and _cle_groupe(l) not in REGLES["service_force"]
    materiel = any(est_materiel(l) for l in lignes)
    sur_site = kind in ("metro", "nc") and any("SUR SITE" in _maj(l.get("grp")) for l in lignes)
    reportes = [d for d in (_date(l.get("dr")) for l in lignes) if d]
    champs = ("deploiement_debut", "deploiement_fin") if kind == "jri" else ("debut", "fin")
    cible = None
    if reportes:
        base = max(reportes)
        if sur_site or not materiel:
            cible = base
            why = f"Délai reporté du {base:{DATE_FMT}} ({'métrologie sur site' if sur_site else 'commande sans matériel'})."
        else:
            cible = moins_jours_ouvres(base, 14)
            why = f"Délai reporté du {base:{DATE_FMT}} moins 14 jours ouvrés (commande avec matériel : toute ligne hors service)."
        iv[champs[0]] = f"{cible:{DATE_FMT}}"
        verif[champs[0]] = why
    else:
        dem = [d for d in (_date(l.get("dd")) for l in lignes) if d]
        iv[champs[0]] = ""
        verif[champs[0]] = "Aucun délai reporté dans la commande : saisissez la date." + (f" (délai demandé : {max(dem):{DATE_FMT}})" if dem else "")
    iv[champs[1]] = ""   # date de fin : toujours à saisir
    verif[champs[1]] = "Date de fin à saisir."

    # --- JRI -----------------------------------------------------------------------------
    if kind == "jri":
        inst = any(val(i, "onglet") == "JRI installation" for i in range(len(lignes))) or \
            any(attrs[i] is None and i in refs_ms for i in range(len(lignes)))
        ext = any(val(i, "onglet") == "JRI extension" for i in range(len(lignes)))
        iv["nature"] = "installation" if inst or not ext else "extension"
        if not refs_ms:
            iv["nature"] = "extension"      # aucune référence MySirius : extension
        # hébergement : table, sinon lecture du texte des lignes MySirius
        cl = sv = 0
        for i in range(len(lignes)):
            h = val(i, "hebergement")
            if h in ("Cloud", "Serveur"):
                cl += h == "Cloud"; sv += h == "Serveur"
            elif not h:   # non précisé par la table : lecture du texte des lignes MySirius
                d = desc[i]
                if "MYSIRIUS" in d.replace(" ", ""):
                    cl += ("CLOUD" in d and "SERVEUR" not in d and "SERVER" not in d)
                    sv += (("SERVEUR" in d or "SERVER" in d) and "CLOUD" not in d)
        iv["hebergement"] = "Serveur" if sv > cl else "Cloud"
        if cl and sv:
            verif["hebergement"] = "Lignes Cloud et Serveur dans la même commande."
        elif not cl and not sv:
            verif["hebergement"] = "Hébergement non indiqué dans la commande (Cloud par défaut)."
        h = iv["hebergement"]
        # prérequis
        def a_prerequis(mot, regex):
            for i in range(len(lignes)):
                p = val(i, "prerequis")
                if attrs[i] is not None:
                    if p and (mot in p):
                        yield desc[i]
                elif regex.search(desc[i]):
                    yield desc[i]
        liens = list(a_prerequis("Link", RE_LINK))
        iv["link"] = bool(liens)
        if liens:
            modes = Counter(m for d in liens for m in ("POE", "VDC", "WIFI") if m in d)
            permis = cfg["prerequis"]["Link"].get(h, {})
            mode = next((m for m, _ in modes.most_common() if m in permis), None)
            iv["link_mode"] = mode or "POE"
            if not mode or len(modes) > 1:
                verif["link_mode"] = "Mode du Link non lisible ou multiple dans la commande."
        passerelles = list(a_prerequis("Gateway", RE_GATEWAY))
        iv["gateway"] = bool(passerelles)
        if passerelles:
            permis = cfg["prerequis"]["Gateway"].get(h, {})
            iv["gateway_mode"] = "4G + ETH" if any("4G" in d for d in passerelles) and "4G + ETH" in permis else "ETH"
        iv["mysirius_serveur"] = h == "Serveur" or any("MySirius Serveur" in (val(i, "prerequis") or "") for i in range(len(lignes)))
        # sections du mail
        sections = {val(i, "section") for i in range(len(lignes))}
        sections |= {"Formation" for i in range(len(lignes)) if attrs[i] is None and "FORMATION" in desc[i]}
        date_ref = iv.get(champs[0], "")
        for nom, cle in (("Formation", "formation"), ("Visite", "visite"), ("Teams", "teams")):
            if nom in sections:
                iv[cle] = True
                if date_ref:
                    iv[cle + "_date"] = date_ref
                verif[cle + "_date"] = f"{nom} indiquée par la commande : confirmez la date."
        iv["deploiement"] = True
    sortie = {k: v for k, v in iv.items() if v != "" or k in ("debut", "fin", "deploiement_debut", "deploiement_fin")}
    return {"kind": kind, "iv": sortie, "verif": verif, "materiel": materiel}
