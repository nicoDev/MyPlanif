@echo off
title Installation MyPlanif - ouverture directe dans Outlook
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=[IO.File]::ReadAllText('%~f0'); $i=$s.IndexOf('#'+'PS'+'#'); Invoke-Expression $s.Substring($i+4)"
echo.
pause
exit /b
#PS#
$ErrorActionPreference = 'Stop'
$dir = Join-Path $env:LOCALAPPDATA 'MyPlanif'
New-Item -ItemType Directory -Force $dir | Out-Null

$ouvrir = @'
param([string]$u)
$srv = '__SERVEUR__'
$tmp = Join-Path $env:LOCALAPPDATA 'MyPlanif\tmp'
New-Item -ItemType Directory -Force $tmp | Out-Null
Get-ChildItem $tmp -ErrorAction SilentlyContinue | Where-Object { $_.LastWriteTime -lt (Get-Date).AddHours(-2) } | Remove-Item -Force -ErrorAction SilentlyContinue
if ($u -notmatch 't=([A-Za-z0-9_-]{20,64})') { exit 1 }
$t = $Matches[1]
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$f = Join-Path $tmp ($t.Substring(0, 12) + '.eml')
try {
  Invoke-WebRequest -UseBasicParsing -Uri "$srv/api/eml/$t" -OutFile $f
  Start-Process $f
  Start-Sleep -Seconds 30
  Remove-Item $f -Force -ErrorAction SilentlyContinue
} catch {
  Add-Type -AssemblyName PresentationFramework
  [System.Windows.MessageBox]::Show('Le brouillon n''a pas pu etre ouvert : ' + $_.Exception.Message, 'MyPlanif') | Out-Null
}
'@
Set-Content -Path (Join-Path $dir 'ouvrir.ps1') -Value $ouvrir -Encoding UTF8

$vbs = @'
Set sh = CreateObject("WScript.Shell")
dossier = sh.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\MyPlanif\"
sh.Run "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & dossier & "ouvrir.ps1"" """ & WScript.Arguments(0) & """", 0, False
'@
Set-Content -Path (Join-Path $dir 'lancer.vbs') -Value $vbs -Encoding ASCII

$cle = 'HKCU:\Software\Classes\myplanif'
New-Item -Path $cle -Force | Out-Null
Set-ItemProperty -Path $cle -Name '(Default)' -Value 'URL:MyPlanif'
New-ItemProperty -Path $cle -Name 'URL Protocol' -Value '' -Force | Out-Null
New-Item -Path "$cle\shell\open\command" -Force | Out-Null
Set-ItemProperty -Path "$cle\shell\open\command" -Name '(Default)' -Value ('wscript.exe "' + (Join-Path $dir 'lancer.vbs') + '" "%1"')
Write-Host 'Installation terminee. Retournez dans MyPlanif et cochez : Ouvrir directement dans Outlook.'
