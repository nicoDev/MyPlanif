# Journal des modifications
Format : [SemVer](https://semver.org/lang/fr/) — MAJEUR.MINEUR.CORRECTIF

## [1.5.0] - 2026-10-20
**Version définitive** (fin de la série bêta). Elle réunit les nouveautés de la bêta 1.5.0-beta.11 (non diffusée : D-049 à D-055, voir ci-dessous) et quatre ajouts : langue du mail, sortie du mode sécurisé, relance de secours, épinglage dans la barre des tâches. Une **recette** de 27 contrôles essentiels est dans `FICHE_DE_VIE.md` (§38). **L'installeur doit être reconstruit** (`construire_installeur.bat`) : `Setup_Horizon_1.5.0.exe`.
### Nouvelles fonctionnalités
- D-057 : **langue du mail FR / EN** dans chaque onglet (COFRAC, Non COFRAC, JRI), **intervention par intervention**, français par défaut. L'anglais change : l'objet (types traduits : « COFRAC Metrology / CC… / Client »), tout le texte du mail (introduction, blocs métrologie et caractérisation, JRI complet, formules de politesse), la civilité (« Mr » / « Ms »), les **dates écrites** (« 14 October 2026 », « from … to … »), les **heures sur 24 h** (« 14:00 to 15:00 »), le tableau des flux du JRI et la **relance**. Restent en français : l'application, les **pièces jointes** (revues techniques, prérequis) et l'objet des mails JRI (« INSTALLATION MYSIRIUS CLOUD / … »). Un repère « EN » apparaît dans la liste de gauche et sur la carte du Suivi ; l'import Excel crée des fiches en français. **Textes anglais rédigés par l'assistant, à relire avant usage client** (`templates/en/`)
- D-044 : **sortie simple du mode sécurisé** : une ligne permanente « Mode sécurisé actif (cause) » en haut de l'application, avec le bouton **« Quitter le mode sécurisé »** (le fond d'écran revient aussitôt ; l'import automatique et la présentation des onglets reviennent au démarrage suivant). Un mode sécurisé **déclenché automatiquement** après un arrêt anormal est **levé tout seul après 3 fermetures normales de suite** (un nouvel arrêt anormal remet le compteur à zéro, un message le signale) ; un mode **coché dans Paramètres › Poste** reste actif jusqu'à ce qu'on le décoche
- D-048 : **relance de secours** : quand « Relancer » ne retrouve pas le mail initial, une question propose de créer la relance dans un **nouveau message** (hors de la conversation d'origine, ce que la question précise) : mêmes destinataires, intervenant en copie, objet « RE : » + objet d'origine (« RE: » en anglais), texte de relance habituel, même expéditeur qu'une relance normale. La date de relance est enregistrée comme d'habitude. Pour une carte Non COFRAC relancée par un autre collègue, la question précise que le message part de **sa** adresse personnelle
### Correctifs
- D-056 : **épinglage dans la barre des tâches** : épinglée depuis la fenêtre ouverte, l'icône n'est plus celle de Python sans nom : Horizon déclare à Windows sa commande de relance, son icône et son nom ; les trois raccourcis de l'installeur portent le même identifiant d'application (**une seule icône** une fois l'application lancée). Non essayé sous Windows par le développement : si l'ancienne icône épinglée subsiste, la détacher d'abord ; en cas d'échec, `journal.log` contient la ligne « Barre des tâches : propriétés de relance … »
### Repris de la bêta 1.5.0-beta.11 (non diffusée)
D-049 mails Non COFRAC par défaut et revue technique du COFRAC renommée ; D-050 coches ; D-051 onglet Archives (cartes Validée, un mois après la date de fin) ; D-052 Non COFRAC depuis l'adresse personnelle ; D-053 liste des 33 techniciens et « Importer des adresses… » ; D-054 fichiers de tout format dans chaque onglet ; D-055 recherche dans le champ Intervenant. Voir l'entrée 1.5.0-beta.11 ci-dessous.
### À savoir
- `config.json` passe en version 5 (migration automatique : libellé et prestation anglais de chaque type)
- L'intervenant n'est plus choisi d'office ; une relance Non COFRAC normale ne peut être faite que par l'expéditeur du mail (la relance de secours reste possible pour les autres)
- Les anciens plans de test (T81 à T206) sont remplacés pour la 1.5.0 par la **recette** du §38 de la fiche de vie
- La procédure en ligne destinée aux collègues décrit la bêta 1.5.0-beta.11 : elle n'a pas été mise à jour pour la 1.5.0 (langue, mode sécurisé, relance de secours)

## [1.5.0-beta.11] - 2026-10-14
*Non diffusée : intégrée à la version 1.5.0 ci-dessus.*
**Version bêta** (suite de la 1.5.0-beta.10) : mails Non COFRAC par défaut, coches dans la liste de planification, onglet Archives, Non COFRAC depuis l'adresse personnelle, liste des 33 techniciens, fichiers supplémentaires de tout format dans chaque onglet, recherche dans le champ Intervenant. Validation sur poste réel : tests T193 à T206 de `FICHE_DE_VIE.md`. **L'installeur doit être reconstruit** (`construire_installeur.bat`).
### Nouvelles fonctionnalités
- D-050 : **coches** dans la liste de planification : « Créer et ouvrir les brouillons cochés (N) » ne traite que les interventions cochées (à faire ou en erreur) ; nouvelles interventions cochées d'office ; boutons « Tout cocher » et « Tout décocher » ; les coches sont conservées au redémarrage
- D-051 : **onglet Archives** : une carte du Suivi à l'état **Validée** passe en Archives **un mois après sa date de fin** (le 14/10 donne le 14/11). Calculé d'après les dates, rien n'est déplacé : identique pour tous les postes en suivi partagé. Le Suivi indique « n archivée(s) » ; les Archives sont en lecture seule, avec recherche, respect de la vue et bouton **« Remettre dans le suivi »** (la carte reste Validée mais n'est plus archivée ; propagé aux collègues en suivi partagé)
- D-053 : **liste des 33 techniciens** (adresses fournies) : noms « Prénom NOM » déduits des adresses, accents rendus aux prénoms usuels (Aurélien, Éric, Hervé, Jean-François, Joël, Rémi, Jérémy), civilité « M. » sauf Marion BASSET « Mme ». Dans le `config.json` livré, et appliquée **automatiquement** à une installation qui n'a que l'intervenant d'exemple « Intervenant 1 » (de vrais intervenants sont conservés). Bouton **« Importer des adresses… »** dans Paramètres › Intervenants pour ajouter d'autres adresses (doublons ignorés ; à enregistrer ensuite)
- D-054 : **fichiers supplémentaires de tout format** (Excel, Word, PDF, images…) dans **chaque onglet** : zone « Fichiers à joindre en plus (facultatif) » par intervention, glisser-déposer ou « Ajouter des fichiers… », une croix par fichier, noms d'origine conservés, avertissement au-delà de 20 Mo, fichier disparu signalé en erreur au moment du brouillon
- D-055 : **recherche dans le champ Intervenant**, comme pour les destinataires : on tape une partie du nom ou de l'adresse (sans accents ni casse), les correspondances s'affichent, flèches + Entrée ou clic ; un texte qui ne correspond à personne est signalé en rouge
### Améliorations
- D-049 : **mails Non COFRAC par défaut** (plus de texte provisoire rouge) : « Je vous propose que l'intervention de qualification ait lieu du … au …. L'intervenant sera M. X en copie de ce mail. Pouvez-vous nous confirmer l'adresse d'intervention ? » puis le pied habituel ; pour la **métrologie non COFRAC**, phrase « Merci de nous retourner l'annexe technique à jour. » et revue technique jointe : **celle du COFRAC, renommée** « Revue technique non COFRAC_Client_Année » (même fichier, jamais dupliqué : le remplacer une fois dans Paramètres › Fichiers vaut pour les deux) ; zone « fichier de l'année précédente » comme au COFRAC
- D-052 : **Non COFRAC depuis l'adresse personnelle** : les brouillons Non COFRAC sont créés dans la boîte de la personne, **sans « de la part de planning@ »** ; la relance d'une carte Non COFRAC cherche le mail initial dans ses éléments envoyés et répond sans « de la part de ». COFRAC et JRI restent au nom de `planning@`
### À savoir
- **L'intervenant n'est plus choisi d'office** : une nouvelle intervention (ou importée) demande de le chercher dans le champ (une alerte le rappelle). Les fiches existantes qui portaient « Intervenant 1 » sont à re-choisir
- **Seule la personne qui a envoyé un mail Non COFRAC peut le relancer** (le mail est dans ses éléments envoyés) ; un autre collègue voit un message qui le dit
- Les zones facultatives par type (Non COFRAC) sont remplacées par la zone générale « Fichiers à joindre en plus »
- `config.json` passe en version 4 (migration automatique : la métrologie non COFRAC reprend la revue technique du COFRAC)
- Les noms des intervenants sont affichés en gras dans les mails sous la forme « M. Ali FAZALDIN »

## [1.5.0-beta.10] - 2026-10-13
**Version bêta corrective** (suite de la 1.5.0-beta.9) : lecture de la boîte partagée `planning@` sur les postes où Outlook refuse de lister ses boîtes (constaté chez un collègue : la liste des boîtes du profil est illisible, erreur `0x94740111`, alors que la boîte est bien accessible dans Outlook). Validation sur poste réel, **en priorité chez ce collègue** : tests T183 à T192 de `FICHE_DE_VIE.md`.
### Correctifs
- D-047 : **lecture robuste d'Outlook** : les boîtes sont lues **une par une** (une boîte illisible est ignorée et ne bloque plus les suivantes), puis les dossiers racines, puis un **accès direct par le nom** (adresse, nom court « planning », « Planning », « Boîte aux lettres - planning »…), sans jamais dépendre d'une liste entière. Aucune correspondance partielle : « Archive en ligne - planning@… » n'est jamais prise pour la boîte partagée
- D-047 : **dossier mémorisé** : Paramètres › Poste › « Utiliser le dossier sélectionné dans Outlook » enregistre l'identifiant du dossier « Éléments envoyés » de la boîte partagée affiché dans Outlook ; il est ensuite **ouvert directement** (sans parcourir les boîtes), en premier, par l'import des adresses et par les relances ; « Oublier » revient à la recherche automatique. Un dossier qui n'est pas du courrier, ou qui ne s'appelle pas « Éléments envoyés », est signalé avant d'être accepté
- D-047 : **message de relance explicite** : quand le mail initial est introuvable, le message donne l'objet cherché, les boîtes consultées (nombre de mails examinés ou raison de l'inaccessibilité) et la marche à suivre
### Nouvelles fonctionnalités
- D-047 : **« Tester l'accès »** (Paramètres › Poste) : compte rendu ligne à ligne de ce qui marche (✓) et de ce qui échoue (✗) pour atteindre la boîte partagée et la boîte par défaut, avec le dossier utilisé, le nombre d'éléments et les boîtes vues par Outlook ; copié dans `journal.log`. Lancé dans un fil séparé : la fenêtre reste utilisable
- Le compte rendu de l'import des adresses indique les boîtes vues par Outlook et une astuce quand la boîte partagée est inaccessible
- `outils\diagnostic_boites.py` : diagnostic en lecture seule qui essaie plusieurs chemins vers la boîte partagée (comptes, boîtes une par une, racines, accès direct, raccourci avec réception / envoyés / calendrier)
### À savoir
- **Non essayé avec le vrai Outlook du collègue** : les accès par le nom et par l'identifiant reposent sur des fonctions d'Outlook qui ne demandent aucune liste de boîtes, mais seul un essai sur son poste le confirmera ; en cas d'échec, « Tester l'accès » montre précisément la raison
- Chez un utilisateur dont Outlook liste correctement les boîtes (cas du poste de développement), rien ne change : la boîte partagée est lue comme avant
- Le « 0 mail lu » observé au démarrage chez le collègue n'est pas une panne : l'import automatique ne relit que les mails plus récents que la dernière lecture (« Importer depuis Outlook » relit tout)

## [1.5.0-beta.9] - 2026-10-13
**Version bêta** (suite de la 1.5.0-beta.8) : l'application **PlanifIntervention devient « Horizon »**, avec sa nouvelle icône. Changement de présentation uniquement : aucun changement du fonctionnement métier. Validation sur poste réel : tests T175 à T182 de `FICHE_DE_VIE.md`.
### Améliorations
- D-046 : **nom Horizon** : titre de la fenêtre (« Horizon v… »), fenêtres d'erreur, raccourcis « Horizon » et « Horizon (mode sécurisé) », entrée « Horizon » dans Paramètres Windows › Applications, installeur `Setup_Horizon_<version>.exe`, textes et guides
- D-046 : **icône Horizon** : icône de la fenêtre et de la barre des tâches (regroupée sous sa propre icône et non sous celle de Python), des raccourcis, de l'installeur et du désinstalleur ; **marque dans l'application** : l'icône puis le nom « Horizon » en haut à gauche, en mode sombre comme en mode clair ; **images de l'assistant d'installation** dessinées à partir de l'icône (ignorées sans erreur si leur création échoue)
- Les ressources graphiques sont dans le nouveau dossier `assets` (`horizon.ico`, `horizon.png`, `horizon_logo_clair.png`) ; le logo clair figure en tête du README
### À savoir
- **Mise à jour d'une installation existante** : le nouvel installeur remplace l'application sous le nouveau nom (même identifiant d'installation), retire les anciens raccourcis « Planif Intervention » et **conserve toutes les données**
- **Noms techniques volontairement conservés** : le dossier `%LOCALAPPDATA%\PlanifIntervention` (programme, données, réglages, journal) et le sous-dossier du suivi partagé `PlanifIntervention_suivi` gardent leur nom. Les renommer ferait perdre les données et les réglages des installations existantes, et séparerait les postes qui partagent le suivi. Un renommage avec migration reste possible sur demande
- Les anciens journaux, fiches de vie et changelogs conservent le nom d'origine (ils décrivent l'histoire du projet)

## [1.5.0-beta.8] - 2026-10-13
**Version bêta** (suite de la 1.5.0-beta.7) : **kit d'installeur Windows** pour faire tester l'application sans rien installer d'autre, et journalisation des erreurs de l'interface. Aucun changement du fonctionnement métier. Validation sur poste réel : tests T165 à T174 de `FICHE_DE_VIE.md`.
### Nouvelles fonctionnalités
- D-045 : **installeur hors ligne** `Setup_PlanifIntervention_<version>.exe` (environ 100 Mo), construit en un double-clic par `construire_installeur.bat` (Python 3.12 de votre poste copié sans documentation ni tests, bibliothèques installées dedans, application copiée, icône créée, compilation par Inno Setup 6). Il installe **sans droits d'administrateur** dans `%LOCALAPPDATA%\PlanifIntervention` (avertissement si le dossier choisi est dans OneDrive), avec **son propre Python** (aucune installation préalable, aucun conflit avec les autres Python du poste), les raccourcis du menu Démarrer et du Bureau (sans fenêtre noire), un raccourci « mode sécurisé » et un désinstalleur qui propose de supprimer ou de conserver les données
- **Mise à jour par-dessus** : le nouvel installeur remplace le Python et l'application, et **conserve** les données, `config.json` et les fichiers de `modeles\` remplacés par l'utilisateur ; l'application ouverte est fermée automatiquement
- Guide pas à pas : `installeur\LISEZMOI_INSTALLEUR.md`
### Améliorations
- Les erreurs d'une action de l'interface sont **journalisées** dans `journal.log` et signalées par une fenêtre (au plus une toutes les 5 s) : lancée par raccourci, l'application n'a pas de console et ces erreurs étaient invisibles ; une erreur au démarrage est elle aussi journalisée et affichée
### À savoir
- La construction demande **internet** et **Inno Setup 6** ; le résultat n'est **pas signé** : Windows peut afficher « Windows a protégé votre ordinateur » (Informations complémentaires › Exécuter quand même), et un antivirus d'entreprise peut le bloquer
- L'installeur n'a pas pu être construit ni essayé avec Windows lors du développement : seules la logique de construction et la cohérence du script sont testées ; un premier essai peut demander un ajustement
- `build.bat` (exécutable unique) reste non vérifié et déconseillé

## [1.5.0-beta.7] - 2026-10-13
**Version bêta corrective** (suite de la 1.5.0-beta.6) : allègements de performance sans changement d'apparence, outils pour la prise en main hors OneDrive, documentation de ce que les mesures ont appris. Validation sur poste réel : tests T157 à T164 de `FICHE_DE_VIE.md`.
### Correctifs
- D-043 : **calendriers** : le calendrier n'est plus détruit puis reconstruit (42 boutons) à chaque ouverture et à chaque changement de mois ; il est construit une seule fois par champ et seul le texte des cases qui changent est modifié. Apparence identique
- D-043 : **Suivi** : l'ouverture de l'onglet ne reconstruit plus toutes les cartes si rien n'a changé (cartes visibles, recherche, filtre « à relancer », vue, jour) ; la recherche et le filtre ne reconstruisent que si le résultat change ; le bouton « Actualiser » et toute modification (déplacement, relance, suppression, « En charge ») reconstruisent comme avant
### Améliorations
- **Journal** : toute opération d'affichage qui dépasse 0,4 s (changement d'onglet, ouverture d'un calendrier, rafraîchissement du Suivi, avec le nombre de cartes) est consignée dans `journal.log` sous la forme « LENTEUR : … » ; rien n'est écrit quand tout va vite
- **`creer_environnement.bat`** : crée le dossier `.venv` avec Python 3.12 (ou 3.13), l'installe au besoin avec `py install`, installe les bibliothèques et affiche la version de Tk obtenue
- **`mesurer_affichage.bat`** (et `outils/mesure_affichage.py`) : à lancer si l'application paraît lente ; compare le coût du texte et des rectangles, liste les polices et relève les processus les plus actifs de la machine (résultat dans `mesure_affichage.txt`)
### À savoir (résultat des mesures de lenteur)
- La lenteur constatée pendant les essais (changement d'onglet et calendriers de 2 à 3 s) **n'était pas due à l'application** : même des boutons Tk simples étaient 30 fois plus lents que la normale. Elle a disparu d'elle-même ; la cause la plus probable est une **charge passagère du poste** (synchronisation OneDrive et analyse Defender après la création du `.venv` dans un dossier OneDrive). **Python 3.14 / Tk 9.0 et l'échelle d'écran ont été écartés** (mêmes chiffres avec Python 3.12 / Tk 8.6, et avec l'échelle d'écran déclarée)
- **Installer le projet hors d'un dossier synchronisé par OneDrive** (par exemple `C:\PlanifIntervention`) : un `.venv` contient des milliers de petits fichiers que OneDrive synchronise et que Defender analyse
- Python 3.12 est le plus éprouvé (mesures faites avec 3.12.10 et Tk 8.6.15) ; Python 3.14.8 fonctionne aussi
- Le coût du thème (bordures et arrondis des boutons, environ deux fois plus longs à dessiner que des boutons sans bordure) n'a pas été modifié : l'apparence reste inchangée

## [1.5.0-beta.6] - 2026-10-13
**Version bêta corrective** (suite de la 1.5.0-beta.5) : l'application pouvait se figer au point de gêner l'utilisation de l'ordinateur. **La cause exacte n'est pas établie** : cette version supprime les causes les plus probables, ajoute des protections qui ne dépendent pas d'elle, et un journal qui indiquera précisément où la fenêtre se bloque si cela se reproduit. Validation sur poste réel : tests T147 à T156 de `FICHE_DE_VIE.md`.
### Correctifs
- D-042 : **l'import des adresses d'Outlook se fait dans un fil séparé** (jusqu'ici dans le fil de la fenêtre) : un appel lent à Outlook (typiquement la résolution d'une adresse interne par l'annuaire, appelée des centaines de fois) ne peut plus bloquer l'application. Le fil initialise COM lui-même, **laisse 0,2 s de repos à Outlook entre deux tranches** (Outlook n'est plus martelé en continu) et peut être **interrompu** par le bouton « Annuler » de la bande de progression ; ce qui a déjà été lu est conservé
- D-042 : **mode sécurisé automatique** : si la session précédente ne s'est pas terminée normalement (fermeture forcée, blocage), l'application redémarre **sans fond d'écran, sans import automatique et avec les onglets d'origine**, l'indique en rouge et enregistre ce mode jusqu'à ce que vous le désactiviez (Paramètres › Poste › Dépannage). Une seconde fenêtre ouverte en même temps n'est pas prise pour un arrêt anormal
- D-042 : **`lancer_securise.bat`** démarre l'application en mode sécurisé sans toucher aux réglages (utile si elle se fige avant d'atteindre les Paramètres) ; la ligne de commande `app.py --securise` fait de même
- D-042 : **fond d'écran** désactivable à chaud (Paramètres › Poste › Affichage) et **désactivé automatiquement avec explication** si son calcul dépasse 2 s sur le poste
- D-042 : la base d'adresses est écrite de façon atomique (fichier temporaire puis remplacement) : une lecture simultanée ne voit plus jamais un fichier tronqué
### Améliorations
- **Journal** `journal.log` (dossier des réglages du poste, bouton « Ouvrir le journal » dans Paramètres › Poste › Dépannage) : démarrage, versions de customtkinter et écran, durée du calcul du fond, import des adresses, erreurs, fermeture
- **Surveillance des blocages** : si la fenêtre ne répond plus depuis plus de 4 s, **la pile du fil principal est enregistrée dans le journal** (on voit où l'application est bloquée), puis le retour à la normale
### À savoir
- Si l'application se fige encore : l'arrêter par le Gestionnaire des tâches (Ctrl + Maj + Échap), la relancer (elle démarre en mode sécurisé), puis envoyer `journal.log`
- Nouveaux réglages dans Paramètres › Poste : « Fond d'écran », « Mode sécurisé », « Ouvrir le journal »

## [1.5.0-beta.5] - 2026-10-13
**Version bêta** (suite de la 1.5.0-beta.4) : import des commandes dans l'onglet JRI et possibilité de coller les cellules copiées dans Excel. Validation sur poste réel : tests T136 à T146 de `FICHE_DE_VIE.md`. Aucune nouvelle dépendance.
### Nouvelles fonctionnalités
- D-040 : **import Excel dans l'onglet JRI**, comme dans COFRAC et Non COFRAC (aperçu à cocher, doublons détectés, rien n'est créé avant validation). Colonnes lues : N° COMMANDE (commande), NOM SITE (client), ÉTAT COMMANDE (ACTIVE cochée d'office) et **DATE D'INTER = date de début du déploiement** (la date de fin est identique ; les dates déjà passées sont signalées dans l'aperçu) ; **DELAI REPORTE et toutes les autres colonnes sont ignorées** ; colonnes facultatives NATURE et HÉBERGEMENT lues si elles existent. Nature et hébergement valent par défaut Installation et Cloud : chaque fiche importée affiche **« ⚠ Fiche importée : vérifiez la nature, l'hébergement et les prérequis »** dans le bandeau, jusqu'à ce que l'un de ces choix soit modifié, et une confirmation est demandée avant de créer les brouillons de fiches non vérifiées. Un export COFRAC (colonne GROUPE) importé dans l'onglet JRI déclenche une demande de confirmation
- D-041 : bouton **« Coller depuis Excel… »** dans les trois onglets (COFRAC, Non COFRAC, JRI) : grande zone de texte, bouton « Coller le presse-papiers », puis le même aperçu à cocher ; le texte collé suit exactement les mêmes règles que le fichier ; la ligne des titres doit être copiée (tabulations, ou « ; » / « , » à défaut) ; dates lues aux formats JJ/MM/AAAA et AAAA-MM-JJ
### Améliorations
- La détection des doublons d'import couvre aussi les fiches JRI de la planification et du Suivi
### À savoir
- Un tableau sans ligne de titres (« N° COMMANDE », « NOM SITE »…) est refusé avec un message qui demande de recopier cette ligne
- Les fiches JRI importées n'ont ni prérequis ni sections Teams, visite ou formation : à renseigner fiche par fiche
- Limites inchangées : fenêtres de message natives (claires), affichage à valider sur votre poste

## [1.5.0-beta.4] - 2026-10-13
**Version bêta** (suite de la 1.5.0-beta.3) : corrige et complète l'habillage d'après vos captures d'écran. Validation sur poste réel : tests T124 à T135 de `FICHE_DE_VIE.md`. Les captures de la beta.3 montraient que la cause du fond absent était Pillow non installé : `verifier_installation.bat` (à double-cliquer) vérifie et installe les bibliothèques.
### Correctifs
- D-039 : couleurs hors palette : le **jour courant du calendrier était bleu** (écrit en dur dans `widgets.py`), le bouton ✕ de la zone de dépôt du fichier N-1 était gris ; les **menus** de la pastille et de « En charge » (menus Windows natifs) prennent maintenant les couleurs du thème
- D-037 : la **pastille du trigramme est ronde** : customtkinter élargissait le bouton en pilule (le texte plus deux fois l'arrondi) ; elle est désormais dessinée avec Pillow (disque lissé, texte centré, posée sur la portion du fond qu'elle recouvre : aucun coin visible, clair et sombre)
- D-036 : si le fond ne peut pas s'afficher, l'application le **dit et donne la raison** dans la bande du bas (Pillow absent : consigne de relancer `verifier_installation.bat` ; autre erreur : son message), au lieu de se rabattre en silence sur un fond uni
### Améliorations
- D-038 : écran plus proche de la maquette, sans changement de fonctionnement : **étiquettes au-dessus des champs** (Client, N° de commande, dates, destinataires, intervenant) ; **titres de section** en petites capitales grises (TYPE(S) D'INTERVENTION, FICHIER DE L'ANNÉE PRÉCÉDENTE…, PROJET ET PRÉREQUIS JOINTS, CONTENU DU MAIL) ; **liste de gauche** : nom du client en serif et détail en gris, alignés à gauche (la seconde ligne était centrée) ; **barres de défilement** plus fines et plus discrètes ; **onglets** plus grands et alignés à gauche (au mieux : composant interne de customtkinter, présentation d'origine conservée s'il change)
### À savoir
- Les fenêtres de confirmation et de message (37 dans l'application) sont des fenêtres Windows natives : elles restent claires tant qu'on ne les remplace pas par des fenêtres sur mesure
- Votre configuration : customtkinter 6.0.0, Python 3.14 ; les tests ont été faits sur des simulations, les écarts d'affichage restants sont à nous signaler par capture
- `verifier_installation.bat` est ajouté à la racine du projet

## [1.5.0-beta.3] - 2026-10-13
**Version bêta** (suite de la 1.5.0-beta.2) : intègre D-027 à D-035, dont le nouvel habillage « Graphite et laiton ». Validation sur poste réel indispensable (tests T101 à T123 de `FICHE_DE_VIE.md`) : l'interface, Outlook et OneDrive n'ont pu être essayés qu'avec des simulations. **Nouvelles dépendances : `openpyxl` et `pillow`** (relancer `installer.ps1`).
### Correctifs
- D-027 : l'adaptation automatique à l'échelle de l'écran est désactivée : les éléments ne se décalent plus quand on déplace la fenêtre entre deux écrans d'échelles différentes ; la fenêtre ne dépasse jamais l'écran (hauteur plafonnée) ; le texte peut paraître un peu moins net sur un écran en 125 % ou 150 %
- D-028 : les cartes du Suivi ne contiennent plus de chemin de fichier de l'année précédente (propre à un poste) ; à la restauration (✕), la fiche revient sans fichier et un rappel invite à le redéposer (types COFRAC uniquement) ; sans lui, le modèle vierge de la revue serait joint
- D-029 : les réglages du poste passent dans `%LOCALAPPDATA%\PlanifIntervention` (ils ne suivent plus un profil itinérant) ; reprise automatique et unique depuis l'ancien emplacement : trigramme et vue conservés, aucune nouvelle demande de confirmation
- D-032 : la boîte partagée `planning@` est enfin lue (relances comprises) : le raccourci d'Outlook échoue chez vous (« Paramètre incorrect »), l'application essaie ensuite les boîtes ouvertes, puis **le dossier d'envois trouvé par son nom** à la racine de la boîte (jamais un sous-dossier) ; le compte rendu de l'import indique les boîtes lues, la méthode et les anomalies, sans plus rien passer sous silence
### Nouvelles fonctionnalités
- D-030 : **import d'un export Excel** des commandes (boutons « Importer Excel… » des onglets COFRAC et Non COFRAC) : colonnes reconnues par leurs titres (N° COMMANDE, NOM SITE, GROUPE, ÉTAT COMMANDE), articles successifs rattachés à leur commande, sous-totaux ignorés ; chaque GROUPE donne un onglet et un type (Qualification et HVAC reconnus par mots-clés) ; une commande qui mélange COFRAC et non COFRAC donne une fiche par onglet ; **aperçu avec cases à cocher avant toute création** (commandes ACTIVE cochées d'office, doublons décochés) ; fiches créées « À faire » avec les dates du jour
### Améliorations
- D-033 : import des **1500 derniers mails envoyés par boîte** (au lieu de 300), avec cache de résolution des adresses internes
- D-034 : nouvelles sources d'adresses : **Contacts suggérés** (lecture par table, environ 27 s pour 12 000 adresses) et **cache des destinataires** ; stockées à part dans `adresses_outlook.json` (le carnet reste la liste des adresses utilisées) ; les suggestions de saisie interrogent le carnet d'abord, puis cette base
- D-031 : **import automatique des adresses au démarrage** (si Outlook est déjà ouvert, jamais lancé de force) : mails récents seulement ; contacts suggérés au plus une fois par semaine ; bande de progression en bas de la fenêtre (l'application reste utilisable) et compte rendu final ; case à décocher dans Paramètres › Poste ; import complet à la demande dans Paramètres › Carnet
- D-035 : **habillage « Graphite et laiton »** (mode sombre par défaut) et « Ivoire et laiton » (mode clair) : palette à une seule couleur d'accent (laiton), braise réservée aux alertes, noms de clients en serif, cartes du Suivi avec pied (« En charge » à gauche, actions à droite), formulaires en sections (INTERVENTION, DESTINATAIRES), boutons secondaires discrets, un seul bouton en laiton à la fois ; **fond « température »** (lever de soleil, rayons gradués, arcs d'isothermes 10° à 40°, ciel étoilé chaud vers froid) dessiné à la taille de la fenêtre et visible dans la bande du haut et les marges ; réglage « Apparence » (Sombre, Clair, Système) dans Paramètres › Poste
### Migration
- Aucune action : les réglages du poste sont repris seuls ; `adresses_outlook.json` se crée au premier import
### À savoir
- Les panneaux et cartes restent pleins : le fond se voit autour d'eux (bande du haut, marges), pas à travers eux ; la bibliothèque d'interface n'a pas de transparence
- Qualification et HVAC : reconnaissance par mots-clés à confirmer avec un export qui en contient ; l'import Excel ne concerne pas le JRI
- Les textes de mail Non COFRAC restent provisoires
- `outils/` : scripts de diagnostic Outlook (lecture seule), à lancer à part

## [1.5.0-beta.2] - 2026-10-09
**Version bêta** (suite de la 1.5.0-beta.1) : intègre les trois projets qui étaient à l'étude. Validation sur poste réel indispensable (tests T81 à T100 de `FICHE_DE_VIE.md`), en particulier le suivi partagé qui n'a pas pu être essayé avec OneDrive / Teams.
### Nouvelles fonctionnalités
- D-016 : **suivi partagé**. Un dossier synchronisé (bibliothèque Teams via OneDrive) est choisi dans Paramètres › Poste. Le suivi y est stocké sous forme de petits fichiers « événement » horodatés et signés, jamais modifiés ensuite (pas de conflit de synchronisation) ; l'état est reconstitué en les rejouant. Actualisation automatique toutes les 45 s (onglet Suivi affiché) et à chaque ouverture de l'onglet. **Sans dossier partagé, le fonctionnement reste exactement celui d'avant** (`suivi.json` local)
- D-016 : **reprise du suivi local** à l'activation du partage (avec confirmation) : les cartes sont copiées dans le suivi partagé, le fichier local reste intact et une copie datée `suivi_avant_partage_*.json` est conservée
- D-016 : **vue sélectionnable** COFRAC / Non COFRAC / JRI / Tous (par poste) : filtre le Suivi, limite le compteur « à relancer », et détermine l'onglet affiché au démarrage ; les onglets de planification restent tous visibles
- D-016 : **relance depuis la boîte partagée** : le mail initial est cherché d'abord dans les éléments envoyés de `planning@group-mms.com` (réglable), puis dans la boîte par défaut ; réglages « boîte du mail initial » et « expéditeur » propres à chaque poste
- D-017 : **trigramme** de l'utilisateur, proposé d'après le nom d'affichage Windows (« Nicolas WURTZ (NWU) » → NWU), à défaut les 3 premières lettres de la session ; confirmé ou corrigé au premier lancement ; **pastille ronde** en haut à droite (menu : vue, correction du trigramme, réglages du poste)
- D-017 : **« En charge : NWU »** sur chaque carte du Suivi, modifiable par tous (menu des trigrammes connus ou « Autre trigramme… ») ; renseigné automatiquement avec le trigramme de l'utilisateur à « Placer dans suivi » ; trouvable par la recherche du Suivi
- D-021 : bouton **Importer depuis Outlook** (Paramètres › Carnet) : ajoute au carnet les destinataires des 300 derniers mails envoyés (boîte partagée et boîte par défaut, adresses Exchange internes converties) et les contacts SMTP ; l'annuaire complet de l'entreprise n'est pas importé
### Améliorations
- Plafond du carnet relevé de 300 à 2000 adresses (import)
- Erreurs d'enregistrement du suivi (dossier partagé indisponible…) signalées par un message au lieu d'une erreur silencieuse
### Correctifs
- Aucun
### Nouveau fichier
- `partage.py` : réglages du poste et stockage du suivi (local ou partagé). Réglages personnels dans `%APPDATA%\PlanifIntervention\reglages.json` (propres à chaque session Windows, hors du dossier de l'application)
- `tests/test_logique.py` : 48 contrôles (suivi partagé, simulation de deux utilisateurs, trigramme, relances, import) exécutables sous Windows sans Outlook : `py tests\test_logique.py`
### À savoir
- **Ce qui est partagé** : uniquement le suivi. Restent propres à chaque poste : planification (COFRAC, Non COFRAC, JRI), carnet, `config.json` (intervenants), modèles de mail, prérequis et copies `envois/`
- Pas de compactage du journal : le nombre de petits fichiers grandit avec l'usage (sans effet sensible sur quelques milliers d'actions)
- Les postes doivent avoir à peu près la même heure (l'ordre des événements en dépend) et un dossier synchronisé en « Toujours conserver sur cet appareil »
- Vue : seul le Suivi est filtré ; les onglets de planification ne sont pas masqués (le composant d'onglets ne permet pas de masquer un onglet sans le détruire)
- Les textes de mail Non COFRAC restent provisoires (voir 1.5.0-beta.1)

## [1.5.0-beta.1] - 2026-10-09
**Version bêta** : à valider sur poste réel (tests T61 à T80 de `FICHE_DE_VIE.md`) avant de devenir la 1.5.0. Chaque ligne porte son numéro de demande (D-xxx, registre §14 de la fiche de vie).
### Nouvelles fonctionnalités
- D-023 : onglet **Non COFRAC**, construit comme l'onglet COFRAC, avec les types Métrologie non COFRAC, Caractérisation non COFRAC, Qualification et HVAC (clé `types_nc` de `config.json`) ; fiches enregistrées dans `campagne_nc.json` ; origine « Non COFRAC » dans le Suivi. **Les textes de mail sont provisoires** (`templates/nc_*.html`, repérés en rouge dans le brouillon) et ces types n'ont pas de pièce jointe : en attente de vos modèles
- D-022 : option **Link WIFI** en Cloud et en Serveur (deux fichiers de prérequis ajoutés à `modeles/prerequis/`) ; le mail liste « Link Nano Wifi » (et non « Ethernet ») pour cette variante ; flux réseau inchangés (TCP 13251)
### Améliorations
- D-024 : l'onglet « Métrologie sur site » est renommé **COFRAC** (onglet et origine affichée sur les cartes du Suivi) ; aucune migration de données
- D-019 : nouveau modèle de mail Métrologie COFRAC (V2) : sous-points MySirius qualifié / export Serveur / contact du support et images retirés ; ajout de « S'ils ne sont pas à jour, nous effectuerons les étalonnages sans possibilité de mise à disposition de modélisation. »
- D-018 : onglet JRI : « Contenu du mail » à gauche, « Projet et prérequis joints » (avec Nature et MySirius) à droite
- D-020 : suggestions de destinataires pendant la saisie, issues du carnet (insensible aux accents et à la casse ; clic, ↑ ↓ Entrée, Échap) ; le bouton « Carnet ▾ » est conservé
- D-026 : l'étape en cours est mise en avant par la couleur (fiche « À faire » : « Créer et ouvrir tous les brouillons » en bleu vif ; fiche « Brouillon » : « Placer dans suivi » en vert vif) ; **aucun bouton n'est désactivé**, le fonctionnement est inchangé
### Correctifs
- Aucun
### Migration
- `config.json` est migré automatiquement au premier lancement (`version_config` 3) : ajout de `types_nc` et des entrées Link WIFI ; vos intervenants et autres réglages sont conservés
### À savoir
- Non COFRAC : l'entête et le pied du mail sont ceux du COFRAC (« prestation annuelle sur site… vérification ») ; ce texte est sans doute à adapter
- Les images `outils`, `version_soft`, `prerequis` du dossier `modeles/images/` ne sont plus utilisées par aucun modèle (laissées en place) ; la TODO « export.png » disparaît
- Non inclus : D-021 (import d'adresses depuis Outlook), D-016 et D-017 (multi-utilisateurs), toujours à l'étude

## [1.4.0] - 2026-10-09
Les entrées sont désormais classées en **Correctifs** et **Améliorations / nouvelles fonctionnalités** ; chaque ligne porte le numéro de demande (D-xxx) du registre de `FICHE_DE_VIE.md` §14.
### Correctifs
- D-011 : le message d'état du bas (« 3 brouillon(s) créé(s)… ») n'est plus conservé à tort ; il est effacé dès qu'on change d'intervention ou qu'on modifie une fiche, et remplacé par « Intervention placée dans le suivi » / « Remis à faire » selon l'action
### Améliorations / nouvelles fonctionnalités
- Planification (Métrologie et JRI)
  - D-004 : bandeau fixe sous le formulaire (objet, statut, message, alerte), toujours visible sans défiler
  - D-012 : liste de gauche sur deux lignes (client · commande ; types ou nature + hébergement), plus de titre coupé
  - D-013 : les fiches complètement vides sont supprimées automatiquement (au changement de fiche, à l'ouverture et à la fermeture de l'application) ; une fiche reste toujours disponible
  - D-009 : avertissement (bandeau + confirmation avant création des brouillons) si l'intervenant à mettre en copie n'a pas d'adresse e-mail
- Métrologie sur site
  - D-014 : mise en page sur deux colonnes (client / commande et début / fin côte à côte ; types à gauche, fichiers N-1 à droite)
  - D-015 : zones de dépôt compactes sur une ligne (« Métrologie : glisser ici le fichier N-1 », puis nom du fichier déposé)
- JRI
  - D-003 : mise en page sur deux colonnes (projet et prérequis à gauche, contenu du mail à droite)
  - D-002 : le corps du mail parle toujours de « déploiement » (« Un déploiement le… », « du futur déploiement ») ; l'objet, le choix Installation / Extension et la « visite de pré-installation » sont inchangés
- Suivi
  - D-005 : cartes sur trois lignes (client ; commande · type ; dates) adaptées à la largeur de la colonne
  - D-006 : recherche par client ou n° de commande (insensible aux accents), filtre « À relancer seulement », bouton Actualiser, compteur « ● n à relancer »
- Paramètres
  - D-007 : trois sous-onglets (Intervenants, Fichiers, Carnet) ; nom du fichier et bouton « Remplacer… » côte à côte ; recherche dans le carnet
- Application
  - D-008 : emplacement réservé en haut à droite pour la future pastille de l'utilisateur (vide dans cette version)
  - Taille minimale de la fenêtre (1100 × 700) pour préserver les mises en page à deux colonnes
  - D-010 : fiche de vie : colonne « Type » dans l'historique des versions, registre des demandes numérotées
### À savoir
- Modifications de présentation non testables en dehors de Windows : valider les cas T44 à T60 de la fiche de vie avec l'interface réelle
- Mode multi-utilisateurs (suivi partagé, vues, trigramme, « En charge ») : à l'étude (D-016, D-017), non inclus

## [1.3.1] - 2026-10-09
### Corrigé
- JRI : l'option Gateway « 4G + ETH » n'est plus proposée en mode Serveur (aucun prérequis n'existe) ; en passant de Cloud à Serveur, une sélection « 4G + ETH » revient à « ETH ». Les boutons ne sont reconstruits que si la liste change
### Note
- Version régénérée à partir du zip 1.3.0 validé sur poste ; seuls `core.py` (fonction `modes_prerequis`) et `app.py` (onglet JRI) diffèrent de la 1.3.0

## [1.3.0] - 2026-10-08
### Ajouté
- Mail JRI dynamique d'après `Modele_Mail_JRI.msg` : points numérotés selon les sections cochées, liste des prérequis jointe, tableau des flux (Cloud ou Serveur, lignes Link / Gateway selon la sélection), fin de mail
- Onglet JRI réorganisé : réunion Teams (date + heure de début, 1h), visite de pré-installation (date, heure, participants), déploiement (date de début / fin), formation (date) ; chaque bloc n'apparaît que si sa coche est active
- Suivi : relance dans la même conversation Outlook (réponse au mail initial), dates du premier mail et des relances, pastille rouge après 7 jours, orange après relance puis rouge 7 jours plus tard ; section masquée (hors dernière relance) une fois « Validée »
- Suivi : tri du plus proche au plus lointain (date de début) ; ✕ remet l'intervention « à planifier » dans son onglet
- Calendrier intégré sous le champ (plus de fenêtre séparée), 6 semaines toujours visibles
- Contrôle : la date de fin ne peut pas précéder la date de début (correction automatique + message)
- Recherche des fichiers tolérante aux accents (ex. `Caractérisation` / `Caracterisation`)
### Modifié
- Objet : `Type / N° de commande / Client` ; JRI : `EXTENSION MYSIRIUS CLOUD / CC… / Client` (sans « Prérequis »)
- Boutons : « Valider la planification » devient « Placer dans suivi » (l'intervention quitte l'onglet de planification) ; ordre Remettre à faire / Créer et ouvrir tous les brouillons / Placer dans suivi
- Après création des brouillons, l'icône passe en ✔ (validé)
- Dates et intervenant en gras dans les mails
- Mail Métrologie COFRAC : ajout de « Cordialement. » (nouveau modèle) ; Caractérisation inchangée
- Fichiers Link Serveur : POE / VDC corrigés (migration automatique de `config.json`, `version_config` = 2)
- Revue technique Caractérisation remplacée (ancienne version archivée dans `modeles/_archives/`)
### À savoir
- Image « Et cliquer sur exporter » toujours absente des modèles fournis : déposer `export.png` dans `modeles/images/`
### Outillage (conditionnement du 2026-10-09, sans changement fonctionnel)
- Ajout de `README.md`, `installer.ps1`, `lancer.bat`, `requirements-build.txt`, `.gitignore`, `tests/` (`verif_statique.py`, `smoke_test.py`) et `docs/` (résumé du projet, modèles de mail .msg d'origine)
- `requirements.txt` : `pywin32` limité à Windows ; PyInstaller déplacé dans `requirements-build.txt`
- `build.bat` : utilise `py -m` et se place dans son dossier

## [1.2.0] - 2026-10-08
### Ajouté
- Onglet **JRI** : même fonctionnement que « Métrologie sur site », types remplacés par prérequis (Installation / Extension, Cloud / Serveur, Gateway ETH ou 4G + ETH, Link POE ou VDC, Prérequis MySirius Serveur) ; pièces jointes précises selon le choix (8 fichiers dans `modeles/prerequis/`)
- Coches JRI : visite de préinstallation, réunion Teams, formation ; chaque coche inclut ou non sa section dans le corps du mail
- Objet JRI : `Prérequis installation|extension / Client / Commande`
- Bouton « Valider la planification » : statut Planifié, ajout à l'onglet Suivi
- Onglet **Suivi** : cartes avec titre de l'intervention + dates, workflow Planifié → Date validée → Validée (glisser-déposer ou ◀ ▶), couleurs rouge / gris / orange doux
- Onglet **Paramètres** : création, modification, suppression des intervenants ; remplacement des fichiers de prérequis et des revues techniques (ancienne version archivée dans `_archives/`) ; gestion du carnet de destinataires
- Calendrier sur tous les champs date (date du jour par défaut)
- Carnet de destinataires mémorisés (liste « Carnet » proposée dans chaque intervention)
- Accents : noms de fichiers retrouvés quelle que soit la forme d'encodage de l'accent (é composé / décomposé)
### Modifié
- Onglets renommés : « Campagne » → « Métrologie sur site », « Historique » → « Suivi »
- Code réparti en `core.py` (logique), `widgets.py` (composants), `app.py` (écrans)
- `config.json` : nouvelle clé `prerequis` (ajoutée automatiquement si absente)
### Supprimé
- Bouton « Envoyer tout » (brouillons uniquement) ; ancien onglet Historique (le journal reste dans `historique.json`)

## [1.1.1] - 2026-10-07
### Corrigé
- « Envoyer tout » : erreur « Paramètre incorrect » non expliquée. Contrôle préalable du destinataire, résolution des adresses par Outlook, message d'erreur explicite si l'envoi échoue (expéditeur / destinataires)

## [1.1.0] - 2026-10-07
### Ajouté
- Tableau de bord de campagne : plusieurs interventions (multi client / multi commande), statuts À faire / Brouillon / Envoyé / Erreur, sauvegarde automatique (`campagne.json`)
- Ajouter, dupliquer, supprimer, vider ; « Remettre à faire »
- « Créer et ouvrir tous les brouillons » et « Envoyer tout » (confirmation), gestion des erreurs par intervention
- Pièces jointes nommées `Revue technique COFRAC_<Client>_<Année en cours>` (copie dans `envois/<année>/<client>_<commande>/`)
- Glisser-déposer (ou Parcourir) du fichier de l'année précédente, par type ; à défaut, modèle vierge
- Modèles de mail repris des .msg réels (entête commune, bloc par type, pied), images inline (prérequis, Outlook onglet Outils, tuile Version Soft)
- Expéditeur (`expediteur`) et civilité du technicien (`civilite`) configurables
### Modifié
- `config.json` : nouvelles clés par type (`modele`, `nom_pj`, `prestation`) ; `pieces_jointes` supprimée
- Multisélection : un seul mail avec entête commune et un bloc par type
- Le corps est inséré avant la signature Outlook (HTML propre)
### Connu
- Image « Et cliquer sur exporter » absente : déposer `export.png` dans `modeles/images/`

## [1.0.0] - 2026-10-07
### Ajouté
- Formulaire : client, commande, dates début/fin, technicien, type (multisélection)
- Objet généré : `Type / Client / Commande`
- Pièces jointes et corps de mail selon le type (modèles HTML dans `templates/`)
- Création via Outlook classique (brouillon ou envoi), signature conservée
- Historique des interventions avec rechargement dans le formulaire
- Configuration externe (`config.json`)
