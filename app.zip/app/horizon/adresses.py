"""Base d'adresses issue d'Outlook (distincte du carnet) : sources, lecture par tranches, stockage et recherche.

Sources : mails envoyés (boîte partagée puis boîte par défaut), « Recipient Cache », « Contacts suggérés » et
contacts SMTP d'Outlook. La lecture se fait par petites tranches de temps pour que l'interface reste utilisable ;
un indicateur de progression est alimenté par `ImportAdresses.etapes()`.

La base est enregistrée dans `adresses_outlook.json` (propre au poste) et n'est interrogée que par les suggestions de
saisie : le carnet reste la liste des adresses réellement utilisées.
"""
import json
import os
import queue
import re
import sys
import threading
import time
import types
import unicodedata
from datetime import datetime, timedelta
from pathlib import Path

BASE = Path(sys.executable).parent if getattr(sys, "frozen", False) else Path(__file__).parent
FICHIER = BASE / "adresses_outlook.json"
LIMITE_ENVOYES = 1500            # derniers mails envoyés lus, par boîte
JOURS_CONTACTS_SUGGERES = 7      # les contacts suggérés ne sont relus qu'au bout d'une semaine (ou à la demande)
LIMITE_BASE = 40000
PAUSE_REPOS = 0.2                # repos laissé à Outlook entre deux tranches de lecture (import en arrière-plan)
NOMS_ENVOYES = {"elements envoyes", "sent items", "sent", "envoyes"}   # noms exacts de dossiers (sans accents)
NOMS_SUGGERES = {"contacts suggeres", "suggested contacts"}
NOM_CACHE = "recipient cache"
PR_SMTP = "http://schemas.microsoft.com/mapi/proptag/0x39FE001E"


def _urn(propriete):
    return f"http://schemas.microsoft.com/mapi/id/{{00062004-0000-0000-C000-000000000046}}/{propriete}001F"


# (adresse, type) de Email1, Email2, Email3
COLONNES_EMAIL = [(_urn("8083"), _urn("8082")), (_urn("8093"), _urn("8092")), (_urn("80A3"), _urn("80A2"))]


def _norm(texte):
    texte = "".join(c for c in unicodedata.normalize("NFD", str(texte or "")) if not unicodedata.combining(c))
    return re.sub(r"\s+", " ", texte).strip().casefold()


# ---------- stockage ----------
def _vide():
    return {"version": 1, "adresses": [], "cache_ex": {}, "dernier_import": {}, "contacts_suggeres_le": "",
            "contacts_le": ""}


def charger_base():
    donnees = _vide()
    try:
        lues = json.loads(FICHIER.read_text(encoding="utf-8"))
        if isinstance(lues, dict):
            donnees.update(lues)
    except (OSError, ValueError):
        pass
    return donnees


def ecrire_base(donnees):
    """Écriture atomique (fichier temporaire puis remplacement) : une lecture simultanée ne voit jamais un fichier tronqué."""
    temporaire = FICHIER.with_name(FICHIER.name + ".tmp")
    temporaire.write_text(json.dumps(donnees, ensure_ascii=False), encoding="utf-8")
    os.replace(temporaire, FICHIER)
    _cache.update(cle=None)


# ---------- recherche (suggestions de saisie) ----------
_cache = {"cle": None, "liste": [], "norm": []}


def _charger_cache():
    try:
        cle = FICHIER.stat().st_mtime_ns
    except OSError:
        _cache.update(cle=None, liste=[], norm=[])
        return
    if _cache["cle"] != cle:
        liste = charger_base()["adresses"]
        _cache.update(cle=cle, liste=liste, norm=[_norm(a) for a in liste])


def nombre_adresses():
    _charger_cache()
    return len(_cache["liste"])


def rechercher_base(mot, exclus=(), maxi=6):
    """Adresses de la base contenant `mot` (sans accents ni casse), hors adresses déjà proposées ou saisies."""
    mot = _norm(mot)
    if not mot or maxi <= 0:
        return []
    _charger_cache()
    exclus = {_norm(a) for a in exclus}
    res = []
    for adr, n in zip(_cache["liste"], _cache["norm"]):
        if mot in n and n not in exclus:
            res.append(adr)
            if len(res) >= maxi:
                break
    return res


# ---------- localisation des dossiers Outlook ----------
# ---------- lecture robuste d'Outlook (une boîte défaillante ne bloque plus les autres) ----------
def lire_collection(collection):
    """(éléments, erreurs) : lit une collection d'Outlook élément par élément. Une erreur sur l'un n'empêche pas de lire
    les suivants ; si le nombre d'éléments est illisible, repli sur le parcours simple."""
    elements, erreurs = [], []
    total, lire = None, None
    try:
        total, lire = int(collection.Count), collection.Item
    except Exception as exc:  # noqa: BLE001
        erreurs.append(f"nombre d'éléments illisible : {exc}")
    if total is not None:
        for i in range(1, total + 1):
            try:
                elements.append(lire(i))
            except Exception as exc:  # noqa: BLE001
                erreurs.append(f"élément {i} illisible : {exc}")
        return elements, erreurs
    try:
        for objet in collection:
            elements.append(objet)
    except Exception as exc:  # noqa: BLE001
        erreurs.append(f"lecture interrompue : {exc}")
    return elements, erreurs


def nom_de(objet):
    """Nom affiché d'une boîte (DisplayName) ou d'un dossier (Name) ; chaîne vide si illisible."""
    for attribut in ("DisplayName", "Name"):
        try:
            valeur = getattr(objet, attribut)
            if valeur:
                return str(valeur)
        except Exception:  # noqa: BLE001
            continue
    return ""


def noms_candidats(boite):
    """Noms sous lesquels une boîte partagée peut s'afficher dans Outlook, du plus sûr au moins sûr. Jamais de
    correspondance partielle : « Archive en ligne - planning@… » est une autre boîte, qui ne doit pas être lue."""
    court = boite.split("@")[0]
    return list(dict.fromkeys(n for n in (boite, court, court.capitalize(), f"Boîte aux lettres - {court}",
                                          f"Boîte aux lettres - {boite}", f"Mailbox - {court}",
                                          f"Mailbox - {boite}") if n))


def _rang_nom(nom, boite):
    """Position du nom dans la liste des noms admis (0 = adresse exacte), ou None."""
    normalises = [_norm(n) for n in noms_candidats(boite)]
    return normalises.index(_norm(nom)) if _norm(nom) in normalises else None


def _meilleur(objets, boite):
    """(rang, objet, nom) du meilleur candidat parmi des boîtes ou dossiers racines, ou None."""
    trouves = []
    for objet in objets:
        nom = nom_de(objet)
        rang = _rang_nom(nom, boite) if nom else None
        if rang is not None:
            trouves.append((rang, objet, nom))
    return min(trouves, key=lambda t: t[0]) if trouves else None


def chercher_boite(ns, boite):
    """Trouve une boîte partagée sans dépendre d'une liste entière : boîtes lues une par une (Stores), à défaut dossiers
    racines (Folders), puis accès direct par le nom. Renvoie (objet, nom, via, erreurs, vues)."""
    erreurs, vues = [], []
    for via, attribut in (("boîte ouverte", "Stores"), ("racine", "Folders")):
        try:
            collection = getattr(ns, attribut)
        except Exception as exc:  # noqa: BLE001
            erreurs.append(f"{attribut} : {exc}")
            continue
        elements, errs = lire_collection(collection)
        erreurs += [f"{'liste des boîtes' if attribut == 'Stores' else 'dossiers racines'} : {e}" for e in errs]
        vues += [n for n in (nom_de(e) for e in elements) if n and n not in vues]
        meilleur = _meilleur(elements, boite)
        if meilleur:
            return meilleur[1], meilleur[2], via, erreurs, vues
    for nom in noms_candidats(boite):  # accès direct : ne nécessite aucune liste
        try:
            return ns.Folders.Item(nom), nom, "accès direct", erreurs, vues
        except Exception as exc:  # noqa: BLE001
            if nom == boite:
                erreurs.append(f"accès direct par le nom : {exc}")
    return None, "", "", erreurs, vues


def _magasin(ns, nom):
    """Boîte (magasin) dont le nom affiché est exactement `nom` ; une boîte illisible est ignorée."""
    elements, _ = lire_collection(ns.Stores)
    return next((m for m in elements if _norm(nom_de(m)) == _norm(nom)), None)


def _dossier_envoyes(conteneur, erreurs):
    """(dossier, méthode) « Éléments envoyés » d'une boîte ou d'un dossier racine : dossier spécial d'abord, puis nom exact
    à la racine (jamais un sous-dossier qui contiendrait « envoyés »)."""
    racine = conteneur
    if hasattr(conteneur, "GetSpecialFolder"):  # boîte (magasin)
        try:
            return conteneur.GetSpecialFolder(5), "boîte ouverte"
        except Exception as exc:  # noqa: BLE001
            erreurs.append(f"dossier spécial : {exc}")
        try:
            racine = conteneur.GetRootFolder()
        except Exception as exc:  # noqa: BLE001
            erreurs.append(f"racine de la boîte : {exc}")
            return None, ""
    else:  # dossier racine : le dossier spécial s'obtient par sa boîte
        try:
            return conteneur.Store.GetSpecialFolder(5), "boîte ouverte"
        except Exception as exc:  # noqa: BLE001
            erreurs.append(f"dossier spécial : {exc}")
    sous, errs = lire_collection(racine.Folders)
    erreurs += [f"parcours des dossiers : {e}" for e in errs]
    for dossier in sous:
        if _norm(nom_de(dossier)) in NOMS_ENVOYES:
            return dossier, "dossier trouvé par son nom"
    erreurs.append("aucun dossier d'envois à la racine")
    return None, ""


def _envoyes_defaut(ns):
    try:
        return {"cle": "defaut", "libelle": "Votre boîte", "dossier": ns.GetDefaultFolder(5), "methode": "boîte par défaut",
                "erreur": "", "tentatives": [("✓", "boîte par défaut")], "vues": []}
    except Exception as exc:  # noqa: BLE001
        return {"cle": "defaut", "libelle": "Votre boîte", "dossier": None, "methode": "", "erreur": str(exc),
                "tentatives": [("✗", f"boîte par défaut : {exc}")], "vues": []}


def _envoyes_partage(ns, boite, memorise=None):
    """Éléments envoyés d'une boîte partagée. Méthodes essayées dans l'ordre : dossier mémorisé par l'utilisateur (ouvert
    directement par son identifiant, sans aucune liste), raccourci d'Outlook, puis recherche de la boîte (lecture une par
    une, dossiers racines, accès direct par le nom)."""
    erreurs, tentatives, vues = [], [], []
    libelle = boite or "Dossier mémorisé"
    cle = _norm(boite) or "memorise"

    def ok(dossier, methode):
        tentatives.append(("✓", methode))
        return {"cle": cle, "libelle": libelle, "dossier": dossier, "methode": methode, "erreur": "",
                "tentatives": tentatives, "vues": vues}

    def echec(texte):
        erreurs.append(texte)
        tentatives.append(("✗", texte))

    if memorise and memorise.get("entry_id"):
        try:
            if memorise.get("store_id"):
                dossier = ns.GetFolderFromID(memorise["entry_id"], memorise["store_id"])
            else:
                dossier = ns.GetFolderFromID(memorise["entry_id"])
            return ok(dossier, "dossier mémorisé")
        except Exception as exc:  # noqa: BLE001
            echec(f"dossier mémorisé : {exc}")
    if boite:
        try:
            destinataire = ns.CreateRecipient(boite)
            destinataire.Resolve()
            if destinataire.Resolved:
                return ok(ns.GetSharedDefaultFolder(destinataire, 5), "raccourci Outlook")  # 5 = éléments envoyés
            echec("raccourci Outlook : adresse non résolue")
        except Exception as exc:  # noqa: BLE001
            echec(f"raccourci : {exc}")
        conteneur, nom, via, errs_boite, vues = chercher_boite(ns, boite)
        for e in errs_boite:
            echec(e)
        if conteneur is None:
            echec("boîte non ouverte dans Outlook")
        else:
            errs_dossier = []
            dossier, methode = _dossier_envoyes(conteneur, errs_dossier)
            for e in errs_dossier:
                echec(e)
            if dossier is not None:
                return ok(dossier, methode if via != "accès direct" else f"{methode} (accès direct)")
    return {"cle": cle, "libelle": libelle, "dossier": None, "methode": "", "erreur": " ; ".join(erreurs),
            "tentatives": tentatives, "vues": vues}


def localiser_envoyes(outlook, boite="", memorise=None):
    """[{cle, libelle, dossier|None, methode, erreur, tentatives, vues}] : boîte partagée (si indiquée ou mémorisée) puis
    boîte par défaut. `memorise` : {entry_id, store_id, …} du dossier choisi par l'utilisateur."""
    ns = outlook.GetNamespace("MAPI")
    res = []
    if boite or memorise:
        res.append(_envoyes_partage(ns, boite, memorise))
    res.append(_envoyes_defaut(ns))
    return res


def compter(dossier, limite=None):
    try:
        n = int(dossier.Items.Count)
    except Exception:  # noqa: BLE001
        n = 0
    return min(n, limite) if limite else n


def capturer_dossier_selectionne(outlook):
    """Dossier actuellement affiché dans Outlook, pour le mémoriser : {entry_id, store_id, chemin, nom, nombre, courrier}.
    Lève ValueError avec un message clair si Outlook n'a aucune fenêtre ouverte."""
    try:
        explorateur = outlook.ActiveExplorer()
    except Exception as exc:  # noqa: BLE001
        raise ValueError(f"Outlook ne répond pas : {exc}") from None
    if explorateur is None:
        raise ValueError("Aucune fenêtre Outlook n'est ouverte. Ouvrez Outlook classique, sélectionnez le dossier « Éléments "
                         "envoyés » de la boîte partagée, puis recommencez.")
    dossier = explorateur.CurrentFolder
    try:
        courrier = int(dossier.DefaultItemType) == 0  # 0 = dossier de courrier
    except Exception:  # noqa: BLE001
        courrier = True
    return {"entry_id": dossier.EntryID, "store_id": getattr(dossier, "StoreID", ""), "chemin": str(dossier.FolderPath),
            "nom": str(dossier.Name), "nombre": compter(dossier), "courrier": courrier}


def tester_acces(outlook, boite="", memorise=None):
    """Compte rendu ligne à ligne de l'accès à la boîte partagée et à la boîte par défaut : ce qui marche, ce qui échoue."""
    lignes = []
    for src in localiser_envoyes(outlook, boite, memorise):
        lignes.append("Votre boîte" if src["cle"] == "defaut" else f"Boîte partagée « {src['libelle']} »")
        for marque, texte in src.get("tentatives", []):
            lignes.append(f"   {marque} {texte}")
        if src["dossier"] is not None:
            lignes.append(f"   ✓ utilisé : {src['methode']} · dossier « {nom_de(src['dossier'])} » · "
                          f"{compter(src['dossier'])} élément(s)")
        else:
            lignes.append("   ✗ inaccessible")
            if src.get("vues"):
                lignes.append("   boîtes vues par Outlook : " + ", ".join(src["vues"][:12]))
    return lignes


def _dossiers_contacts(magasin):
    """Dossiers « Contacts suggérés » et « Contacts › Recipient Cache » d'une boîte (noms exacts, à la racine)."""
    res = {"suggeres": None, "cache": None}
    try:
        for dossier in magasin.GetRootFolder().Folders:
            nom = _norm(dossier.Name)
            if nom in NOMS_SUGGERES:
                res["suggeres"] = dossier
            elif nom == "contacts":
                for sous in dossier.Folders:
                    if _norm(sous.Name) == NOM_CACHE:
                        res["cache"] = sous
    except Exception:  # noqa: BLE001
        pass
    return res


def outlook_deja_ouvert():
    """Application Outlook en cours d'exécution, sans la lancer ; None si Outlook est fermé."""
    try:
        import win32com.client
        return win32com.client.GetActiveObject("Outlook.Application")
    except Exception:  # noqa: BLE001
        return None


def ouvrir_outlook():
    """Application Outlook (la lance si elle est fermée). À appeler dans le fil qui l'utilise."""
    import win32com.client
    return win32com.client.Dispatch("Outlook.Application")


def _classer(adresse, type_):
    adresse, type_ = (adresse or "").strip(), (type_ or "").upper()
    if not adresse or type_ == "EX" or adresse.upper().startswith("/O="):
        return ""
    return adresse if re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", adresse) else ""


def _date(texte):
    try:
        return datetime.fromisoformat(texte) if texte else None
    except ValueError:
        return None


def _date_envoi(item):
    try:
        s = item.SentOn
        return datetime(s.year, s.month, s.day, getattr(s, "hour", 0), getattr(s, "minute", 0), getattr(s, "second", 0))
    except Exception:  # noqa: BLE001
        return None


# ---------- import par tranches ----------
class ImportAdresses:
    """Lecture des adresses d'Outlook. `etapes()` est un générateur : chaque valeur produite est
    (texte d'avancement, éléments traités, total estimé) ; l'interface le fait avancer par petites tranches."""

    def __init__(self, outlook, boite="", complet=True, limite=LIMITE_ENVOYES, tranche=0.12, memorise=None):
        self.outlook, self.boite, self.complet, self.limite, self.tranche = outlook, boite, complet, limite, tranche
        self.memorise = memorise
        self.base = charger_base()
        self.rapport, self.avertissements = [], []
        self.ajoutees = self.lus = self.erreurs = self.fait = 0
        self.total = 1
        self._connues = {a.casefold() for a in self.base["adresses"]}
        self._recentes, self._autres = [], []

    @property
    def resume(self):
        return f"{self.ajoutees} adresse(s) ajoutée(s) · {len(self.base['adresses'])} en base"

    def executer(self):
        """Exécute tout l'import d'un bloc (tests, ou usage sans interface)."""
        for _ in self.etapes():
            pass
        return self.resume

    def _etat(self, texte):
        return texte, min(self.fait, self.total), self.total

    def _ajouter(self, adresse, liste):
        cle = adresse.casefold()
        if cle in self._connues:
            return
        self._connues.add(cle)
        liste.append(adresse)
        self.ajoutees += 1

    def _enregistrer(self):
        adresses = self._recentes + self.base["adresses"] + self._autres
        self._recentes, self._autres = [], []
        self.base["adresses"] = adresses[:LIMITE_BASE]
        ecrire_base(self.base)

    def _smtp(self, destinataire):
        """Adresse SMTP d'un destinataire (les adresses Exchange internes sont converties, avec un cache)."""
        try:
            entree = destinataire.AddressEntry
            type_ = (entree.Type or "").upper()
        except Exception:  # noqa: BLE001
            entree, type_ = None, ""
        try:
            brute = destinataire.Address or ""
        except Exception:  # noqa: BLE001
            brute = ""
        if type_ == "EX" or brute.upper().startswith("/O="):
            cache = self.base["cache_ex"]
            if brute in cache:
                return cache[brute]
            smtp = ""
            try:
                utilisateur = entree.GetExchangeUser()
                smtp = (utilisateur.PrimarySmtpAddress if utilisateur is not None else "") or ""
            except Exception:  # noqa: BLE001
                pass
            if not smtp:
                try:
                    smtp = destinataire.PropertyAccessor.GetProperty(PR_SMTP) or ""
                except Exception:  # noqa: BLE001
                    pass
            if len(cache) < 20000:
                cache[brute] = smtp
            return smtp
        return brute

    def etapes(self):
        ns = self.outlook.GetNamespace("MAPI")
        envoyes = localiser_envoyes(self.outlook, self.boite, self.memorise)
        contacts = self._sources_contacts(ns, envoyes)
        self.total = 0
        for src in envoyes:
            if src["dossier"] is not None:
                src["n"] = self._compter(src["dossier"], self.limite)
                self.total += src["n"]
        for src in contacts:
            src["n"] = self._compter(src["dossier"])
            self.total += src["n"]
        self.total = max(self.total, 1)
        yield self._etat("Préparation…")
        for src in envoyes:
            if src["dossier"] is None:
                vues = f" ; boîtes vues : {', '.join(src['vues'][:8])}" if src.get("vues") else ""
                self.avertissements.append(f"{src['libelle']} : inaccessible ({src['erreur']}{vues})")
                self.rapport.append(f"{src['libelle']} : inaccessible")
                if src["cle"] != "defaut" and not any(a.startswith("Astuce") for a in self.avertissements):
                    self.avertissements.append("Astuce : dans Outlook, sélectionnez le dossier « Éléments envoyés » de la boîte "
                                               "partagée, puis Paramètres › Poste › « Utiliser le dossier sélectionné dans Outlook ».")
                continue
            yield from self._lire_envoyes(src)
            self._enregistrer()
        for src in contacts:
            yield from self._lire_contacts(src)
            self._enregistrer()
        self._enregistrer()

    def _clore(self, debut_fait, src, lus):
        """Fin d'une source : l'avancement ne recule jamais, le total est relevé si l'estimation était trop basse."""
        prevu = src.get("n", 0)
        if lus > prevu:
            self.total += lus - prevu
        self.fait = max(self.fait, debut_fait + max(lus, prevu))

    @staticmethod
    def _compter(dossier, limite=None):
        return compter(dossier, limite)

    def _sources_contacts(self, ns, envoyes):
        """Dossiers de contacts à lire : caches de destinataires (toujours), contacts suggérés (au plus une fois par
        semaine, sauf import complet) et contacts SMTP d'Outlook (premier import ou import complet)."""
        res, magasins = [], []
        try:
            magasins.append(("Votre boîte", ns.DefaultStore))
        except Exception:  # noqa: BLE001
            pass
        if self.boite:
            try:
                magasin = _magasin(ns, self.boite)
                if magasin is not None:
                    magasins.append((self.boite, magasin))
            except Exception:  # noqa: BLE001
                pass
        suggeres_recents = False
        derniere = _date(self.base.get("contacts_suggeres_le"))
        if derniere and datetime.now() - derniere < timedelta(days=JOURS_CONTACTS_SUGGERES):
            suggeres_recents = True
        for nom, magasin in magasins:
            dossiers = _dossiers_contacts(magasin)
            if dossiers["cache"] is not None:
                res.append({"libelle": f"Cache des destinataires ({nom})", "dossier": dossiers["cache"],
                            "genre": "cache", "nb": 1})
            if dossiers["suggeres"] is not None and (self.complet or not suggeres_recents):
                res.append({"libelle": f"Contacts suggérés ({nom})", "dossier": dossiers["suggeres"],
                            "genre": "suggeres", "nb": 1})
        if self.complet or not self.base.get("contacts_le"):
            try:
                res.append({"libelle": "Contacts Outlook", "dossier": ns.GetDefaultFolder(10), "genre": "contacts",
                            "nb": 3})  # 10 = contacts
            except Exception:  # noqa: BLE001
                pass
        return res

    def _lire_envoyes(self, src):
        dossier, cle, libelle = src["dossier"], src["cle"], src["libelle"]
        depuis = None if self.complet else _date(self.base["dernier_import"].get(cle))
        debut_fait, lus, plus_recent = self.fait, 0, None
        try:
            items = dossier.Items
            items.Sort("[SentOn]", True)
        except Exception as exc:  # noqa: BLE001
            self.avertissements.append(f"{libelle} : lecture impossible ({exc})")
            self.rapport.append(f"{libelle} : lecture impossible")
            return
        t0 = time.perf_counter()
        for i, item in enumerate(items):
            if i >= self.limite:
                break
            date = _date_envoi(item)
            if depuis and date and date <= depuis:
                break
            if date and (plus_recent is None or date > plus_recent):
                plus_recent = date
            lus += 1
            self.fait = debut_fait + lus
            try:
                for destinataire in item.Recipients:
                    adresse = _classer(self._smtp(destinataire), "")
                    if adresse:
                        self._ajouter(adresse, self._recentes)
            except Exception:  # noqa: BLE001
                self.erreurs += 1
            if time.perf_counter() - t0 > self.tranche:
                yield self._etat(f"{libelle} : {lus} mails lus")
                t0 = time.perf_counter()
        self._clore(debut_fait, src, lus)
        self.lus += lus
        if plus_recent:
            self.base["dernier_import"][cle] = plus_recent.isoformat()
        self.rapport.append(f"{libelle} : {lus} mail(s) lu(s) ({src['methode']})")

    def _lignes(self, dossier, nb):
        """Lignes (adresse, type) d'un dossier de contacts : par table (rapide), à défaut élément par élément.
        Produit None à chaque fin de tranche de temps."""
        t0 = time.perf_counter()
        try:
            table = dossier.GetTable()
            table.Columns.RemoveAll()
            for adresse, type_ in COLONNES_EMAIL[:nb]:
                table.Columns.Add(adresse)
                table.Columns.Add(type_)
            en_table = True
        except Exception:  # noqa: BLE001
            en_table = False
        if en_table:
            while not table.EndOfTable:
                ligne = table.GetNextRow()
                yield tuple((ligne.Item(2 * k + 1), ligne.Item(2 * k + 2)) for k in range(nb))
                if time.perf_counter() - t0 > self.tranche:
                    yield None
                    t0 = time.perf_counter()
            return
        for item in dossier.Items:
            yield tuple((getattr(item, f"Email{k}Address", ""), getattr(item, f"Email{k}AddressType", ""))
                        for k in range(1, nb + 1))
            if time.perf_counter() - t0 > self.tranche:
                yield None
                t0 = time.perf_counter()

    def _lire_contacts(self, src):
        libelle, genre = src["libelle"], src["genre"]
        debut_fait, lus = self.fait, 0
        try:
            for ligne in self._lignes(src["dossier"], src["nb"]):
                if ligne is None:
                    yield self._etat(f"{libelle} : {lus} lus")
                    continue
                lus += 1
                self.fait = debut_fait + lus
                for adresse, type_ in ligne:
                    adresse = _classer(adresse, type_)
                    if adresse:
                        self._ajouter(adresse, self._autres)
        except Exception as exc:  # noqa: BLE001
            self.erreurs += 1
            self.avertissements.append(f"{libelle} : lecture interrompue ({exc})")
        self._clore(debut_fait, src, lus)
        self.lus += lus
        if genre == "suggeres":
            self.base["contacts_suggeres_le"] = datetime.now().isoformat(timespec="seconds")
        elif genre == "contacts":
            self.base["contacts_le"] = datetime.now().isoformat(timespec="seconds")
        self.rapport.append(f"{libelle} : {lus} lu(s)")


class ImportEnArrierePlan:
    """Exécute `ImportAdresses` dans un fil séparé : la fenêtre ne peut plus être bloquée par un appel lent à Outlook.
    Le fil initialise COM, obtient lui-même l'objet Outlook (`fabrique`), laisse un temps de repos à Outlook entre deux
    tranches et peut être interrompu. L'interface lit les messages avec `lire()` :
    ("etat", (texte, fait, total)) · ("fin" | "annule", résultat) · ("ignore", texte) · ("erreur", texte)."""

    def __init__(self, fabrique, boite="", complet=True, limite=LIMITE_ENVOYES, pause=None, tranche=0.12, memorise=None):
        self.fabrique, self.boite, self.complet, self.limite, self.memorise = fabrique, boite, complet, limite, memorise
        self.pause, self.tranche = (PAUSE_REPOS if pause is None else pause), tranche
        self._messages = queue.Queue()
        self._arret = threading.Event()
        self._fil = threading.Thread(target=self._executer, daemon=True, name="import-adresses")

    def demarrer(self):
        self._fil.start()

    def arreter(self):
        self._arret.set()

    def lire(self):
        """Messages reçus depuis le dernier appel (sans attendre)."""
        res = []
        while True:
            try:
                res.append(self._messages.get_nowait())
            except queue.Empty:
                return res

    def _executer(self):
        com = False
        try:
            import pythoncom
            pythoncom.CoInitialize()
            com = True
        except Exception:  # noqa: BLE001 - hors Windows ou pywin32 absent : tests
            pass
        try:
            outlook = self.fabrique()
            if outlook is None:
                self._messages.put(("ignore", "Outlook n'est pas ouvert."))
                return
            imp = ImportAdresses(outlook, self.boite, complet=self.complet, limite=self.limite, tranche=self.tranche,
                                 memorise=self.memorise)
            interrompu = False
            for etat in imp.etapes():
                if self._arret.is_set():
                    interrompu = True
                    break
                self._messages.put(("etat", etat))
                if self.pause:
                    time.sleep(self.pause)  # repos laissé à Outlook entre deux tranches
            if interrompu:
                imp._enregistrer()  # ce qui a été lu est conservé
            resultat = types.SimpleNamespace(resume=imp.resume, rapport=list(imp.rapport),
                                             avertissements=list(imp.avertissements))
            imp.outlook = None
            del imp, outlook
            self._messages.put(("annule" if interrompu else "fin", resultat))
        except Exception as exc:  # noqa: BLE001
            self._messages.put(("erreur", f"{type(exc).__name__} : {exc}"))
        finally:
            if com:
                try:
                    import pythoncom
                    pythoncom.CoUninitialize()
                except Exception:  # noqa: BLE001
                    pass


class TravailEnArrierePlan:
    """Exécute une fonction `fonction(outlook)` dans un fil séparé (COM initialisé dans ce fil) : la fenêtre reste utilisable
    même si Outlook tarde à répondre. Messages : ("fin", résultat) ou ("erreur", texte), lus par `lire()`."""

    def __init__(self, fabrique, fonction):
        self.fabrique, self.fonction = fabrique, fonction
        self._messages = queue.Queue()
        self._fil = threading.Thread(target=self._executer, daemon=True, name="travail-outlook")

    def demarrer(self):
        self._fil.start()

    def lire(self):
        res = []
        while True:
            try:
                res.append(self._messages.get_nowait())
            except queue.Empty:
                return res

    def _executer(self):
        com = False
        try:
            import pythoncom
            pythoncom.CoInitialize()
            com = True
        except Exception:  # noqa: BLE001
            pass
        try:
            outlook = self.fabrique()
            if outlook is None:
                self._messages.put(("erreur", "Outlook n'est pas ouvert."))
                return
            resultat = self.fonction(outlook)
            outlook = None
            self._messages.put(("fin", resultat))
        except Exception as exc:  # noqa: BLE001
            self._messages.put(("erreur", str(exc) if isinstance(exc, ValueError) else f"{type(exc).__name__} : {exc}"))
        finally:
            if com:
                try:
                    import pythoncom
                    pythoncom.CoUninitialize()
                except Exception:  # noqa: BLE001
                    pass
