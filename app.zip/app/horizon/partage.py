"""Réglages du poste et stockage du suivi (local ou partagé) — sans interface graphique.

Mode LOCAL (par défaut) : le suivi est le fichier `suivi.json` à côté de l'application, comme avant.

Mode PARTAGÉ : le suivi vit dans un dossier synchronisé (bibliothèque SharePoint / Teams via OneDrive).
Aucun fichier n'y est jamais modifié : chaque action écrit un petit fichier « événement » horodaté et signé
(trigramme de l'auteur) ; l'état de chaque carte est reconstitué en rejouant les événements dans l'ordre.
Deux personnes n'écrivent donc jamais dans le même fichier : pas de conflit de synchronisation.

Les réglages personnels (trigramme, vue, dossier partagé…) sont enregistrés dans `%APPDATA%\\PlanifIntervention`,
propres à chaque session Windows.
"""
import json
import os
import re
import shutil
import sys
import unicodedata
import uuid
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path

BASE = Path(sys.executable).parent if getattr(sys, "frozen", False) else Path(__file__).parent
SUIVI_LOCAL = BASE / "suivi.json"
SCHEMA = 1                          # version du format des fichiers partagés
SOUS_DOSSIER = "PlanifIntervention_suivi"
VUES = ("COFRAC", "Non COFRAC", "JRI", "Tous")
VUE_ORIGINE = {"COFRAC": "metro", "Non COFRAC": "nc", "JRI": "jri"}
REGLAGES_DEFAUT = {"trigramme": "", "trigramme_confirme": False, "vue": "Tous",
                   "dossier_partage": "", "migre_vers": "", "expediteur": "",
                   "import_auto": True, "apparence": "dark", "fond_actif": True, "mode_securise": False,
                   "arret_propre": True, "pid": 0, "envoyes_planning": None,
                   "securise_auto": False, "fermetures_propres": 0, "securise_leve_auto": False}  # apparence : dark, light ou system
# clé facultative `boite_relance` : absente = boîte de l'expéditeur de config.json ; "" = boîte par défaut seulement


# ---------- réglages personnels ----------
def dossier_reglages():
    """Dossier des réglages du poste : %LOCALAPPDATA% (reste sur la machine, contrairement à %APPDATA% itinérant)."""
    force = os.environ.get("PLANIF_REGLAGES")  # utilisé par les tests
    if force:
        return Path(force)
    racine = os.environ.get("LOCALAPPDATA") or os.environ.get("APPDATA") or str(Path.home() / ".config")
    return Path(racine) / "PlanifIntervention"


def ancien_dossier_reglages():
    """Emplacement de la beta.2 (%APPDATA%), relu une fois pour reprendre les réglages existants."""
    force = os.environ.get("PLANIF_REGLAGES_ANCIEN")
    if force:
        return Path(force)
    racine = os.environ.get("APPDATA")
    return Path(racine) / "PlanifIntervention" if racine else None


def _lire_json(chemin, defaut):
    try:
        return json.loads(Path(chemin).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return defaut


_reglages = None


def reglages():
    global _reglages
    if _reglages is None:
        r = dict(REGLAGES_DEFAUT)
        nouveau = dossier_reglages() / "reglages.json"
        ancien = ancien_dossier_reglages()
        reprise = not nouveau.exists() and ancien is not None and (ancien / "reglages.json").exists() \
            and (ancien / "reglages.json") != nouveau
        donnees = _lire_json((ancien / "reglages.json") if reprise else nouveau, {})
        r.update(donnees if isinstance(donnees, dict) else {})
        if r["vue"] not in VUES:
            r["vue"] = "Tous"
        if r.get("apparence") not in ("dark", "light", "system"):
            r["apparence"] = "dark"
        _reglages = r
        if reprise:  # reprise unique : les réglages sont recopiés dans le nouvel emplacement
            try:
                nouveau.parent.mkdir(parents=True, exist_ok=True)
                nouveau.write_text(json.dumps(r, ensure_ascii=False, indent=1), encoding="utf-8")
            except OSError:
                pass
    return _reglages


def maj_reglages(**valeurs):
    r = reglages()
    r.update(valeurs)
    dossier = dossier_reglages()
    dossier.mkdir(parents=True, exist_ok=True)
    (dossier / "reglages.json").write_text(json.dumps(r, ensure_ascii=False, indent=1), encoding="utf-8")
    return r


def recharger_reglages():
    global _reglages
    _reglages = None


# ---------- identité : trigramme ----------
def nom_affichage_windows():
    """Nom d'affichage du compte Windows (ex. « Nicolas WURTZ (NWU) »), ou « » si indisponible."""
    try:
        import ctypes
        taille = ctypes.c_ulong(256)
        tampon = ctypes.create_unicode_buffer(256)
        if ctypes.windll.secur32.GetUserNameExW(3, tampon, ctypes.byref(taille)):  # 3 = NameDisplay
            return tampon.value
    except Exception:
        pass
    return ""


def _sans_accents(texte):
    return "".join(c for c in unicodedata.normalize("NFD", texte) if not unicodedata.combining(c))


def trigramme_depuis(nom_affichage, session):
    """Trigramme entre parenthèses à la fin du nom d'affichage ; à défaut, 3 premières lettres de la session."""
    m = re.search(r"\(([^()]{2,5})\)\s*$", nom_affichage or "")
    if m:
        tri = re.sub(r"[^A-Za-z0-9]", "", _sans_accents(m.group(1))).upper()
        if len(tri) >= 2:
            return tri
    base = re.sub(r"[^A-Za-z]", "", _sans_accents(session or ""))
    return base[:3].upper()


def detecter_trigramme():
    import getpass
    try:
        session = getpass.getuser()
    except Exception:
        session = ""
    return trigramme_depuis(nom_affichage_windows(), session)


def trigramme_valide(texte):
    return bool(re.fullmatch(r"[A-Za-z0-9]{2,5}", (texte or "").strip()))


def trigramme_courant():
    return reglages().get("trigramme", "")


# ---------- dossier partagé ----------
def dossier_partage():
    d = reglages().get("dossier_partage") or ""
    return Path(d) if d else None


def _dossier_evenements(racine):
    return Path(racine) / SOUS_DOSSIER / "evenements"


def verifier_dossier(racine):
    """Prépare le dossier partagé (crée la structure, vérifie le droit d'écriture, contrôle le format)."""
    racine = Path(racine)
    if not racine.is_dir():
        raise FileNotFoundError(f"Dossier introuvable : {racine}")
    base = racine / SOUS_DOSSIER
    schema = base / "schema.json"
    if schema.exists():
        version = _lire_json(schema, {}).get("schema", 0)
        if isinstance(version, int) and version > SCHEMA:
            raise RuntimeError("Ce suivi partagé a été créé par une version plus récente de l'application.\n"
                               "Mettez l'application à jour avant de l'utiliser.")
    evenements = base / "evenements"
    evenements.mkdir(parents=True, exist_ok=True)
    essai = evenements / f".essai_{uuid.uuid4().hex[:8]}.part"
    try:
        essai.write_text("ok", encoding="utf-8")
        essai.unlink()
    except OSError as exc:
        raise PermissionError(f"Écriture impossible dans le dossier partagé : {exc}") from None
    if not schema.exists():
        schema.write_text(json.dumps({"schema": SCHEMA, "cree_le": datetime.now(timezone.utc).isoformat()}),
                          encoding="utf-8")


def activer(racine):
    verifier_dossier(racine)
    maj_reglages(dossier_partage=str(racine))


def desactiver():
    maj_reglages(dossier_partage="")


# ---------- événements ----------
_cache_evt = {}  # {(dossier, nom): événement} : un fichier événement n'est jamais modifié, on ne le relit pas


def ecrire_evenement(racine, type_, id_, donnees, auteur):
    """Écrit un événement (écriture dans un fichier .part puis renommage : jamais de fichier à moitié écrit)."""
    horodatage = datetime.now(timezone.utc)
    nom = f"{horodatage:%Y%m%dT%H%M%S%f}_{re.sub(r'[^A-Za-z0-9]', '', auteur or '') or 'X'}_{uuid.uuid4().hex[:6]}.json"
    dossier = _dossier_evenements(racine)
    dossier.mkdir(parents=True, exist_ok=True)
    contenu = {"v": SCHEMA, "id": id_, "type": type_, "auteur": auteur or "?",
               "ts": horodatage.isoformat(), "donnees": donnees}
    temporaire = dossier / (nom + ".part")
    temporaire.write_text(json.dumps(contenu, ensure_ascii=False), encoding="utf-8")
    os.replace(temporaire, dossier / nom)


def lire_evenements(racine):
    dossier = _dossier_evenements(racine)
    try:
        noms = sorted(n for n in os.listdir(dossier) if n.endswith(".json"))
    except OSError:
        return []
    evenements = []
    for nom in noms:
        cle = (str(dossier), nom)
        ev = _cache_evt.get(cle)
        if ev is None:
            try:
                ev = json.loads((dossier / nom).read_text(encoding="utf-8"))
            except (OSError, ValueError):
                continue  # fichier en cours de synchronisation : relu au prochain rafraîchissement
            if not isinstance(ev, dict) or "id" not in ev or "type" not in ev:
                continue
            _cache_evt[cle] = ev
        evenements.append(ev)
    return evenements


def reconstruire(evenements):
    """État du suivi = rejeu des événements, dans l'ordre des noms de fichiers (horodatage UTC)."""
    etat = {}
    for ev in evenements:
        type_, id_, donnees = ev.get("type"), ev.get("id"), ev.get("donnees") or {}
        if type_ == "creation":
            carte = deepcopy(donnees)
            carte.setdefault("relances", [])
            carte["id"] = id_
            etat[id_] = carte
        elif type_ == "maj" and id_ in etat:
            etat[id_].update(deepcopy(donnees))
        elif type_ == "relance" and id_ in etat:
            relances = etat[id_].setdefault("relances", [])
            if donnees.get("date") and donnees["date"] not in relances:
                relances.append(donnees["date"])
                relances.sort()
        elif type_ == "suppression":
            etat.pop(id_, None)
    return list(etat.values())


def auteurs():
    """Trigrammes ayant écrit dans le suivi partagé (vide en mode local)."""
    racine = dossier_partage()
    return {ev.get("auteur") for ev in lire_evenements(racine) if ev.get("auteur")} if racine else set()


def empreinte():
    """Valeur qui change dès que le suivi a changé (sert à n'actualiser l'écran que si nécessaire)."""
    racine = dossier_partage()
    if racine is None:
        try:
            return str(SUIVI_LOCAL.stat().st_mtime_ns)
        except OSError:
            return ""
    try:
        noms = sorted(n for n in os.listdir(_dossier_evenements(racine)) if n.endswith(".json"))
    except OSError:
        return ""
    return f"{len(noms)}:{noms[-1] if noms else ''}"


# ---------- liste du suivi avec sa base de comparaison ----------
class ListeSuivi(list):
    """Liste de cartes qui garde l'état au moment du chargement : on n'enregistre que ce qui a changé."""
    base = None


def figer(liste):
    liste.base = {e["id"]: deepcopy(e) for e in liste}
    return liste


def lire_brut():
    racine = dossier_partage()
    if racine is None:
        donnees = _lire_json(SUIVI_LOCAL, [])
        return donnees if isinstance(donnees, list) else []
    return reconstruire(lire_evenements(racine))


def differences(base, liste):
    """Événements à écrire pour passer de `base` (état chargé) à `liste` (état modifié)."""
    res, vus = [], set()
    for e in liste:
        id_ = e["id"]
        vus.add(id_)
        if id_ not in base:
            res.append(("creation", id_, deepcopy(e)))
            continue
        avant = base[id_]
        changes = {k: deepcopy(v) for k, v in e.items() if k != "relances" and avant.get(k) != v}
        if changes:
            res.append(("maj", id_, changes))
        for date_ in e.get("relances", []):
            if date_ not in avant.get("relances", []):
                res.append(("relance", id_, {"date": date_}))
    res += [("suppression", id_, {}) for id_ in base if id_ not in vus]
    return res


def sauver(liste, auteur=None):
    """Enregistre le suivi : fichier local en mode local, événements en mode partagé."""
    racine = dossier_partage()
    if racine is None:
        SUIVI_LOCAL.write_text(json.dumps(list(liste), ensure_ascii=False, indent=1), encoding="utf-8")
    else:
        if getattr(liste, "base", None) is None:
            raise ValueError("Liste de suivi non chargée par charger_suivi() : enregistrement refusé.")
        auteur = auteur or trigramme_courant() or "?"
        for type_, id_, donnees in differences(liste.base, liste):
            ecrire_evenement(racine, type_, id_, donnees, auteur)
    figer(liste)


# ---------- passage du suivi local au suivi partagé ----------
def cartes_locales_a_migrer(racine):
    if reglages().get("migre_vers") == str(Path(racine)):
        return []  # déjà repris : ne jamais ressusciter des cartes supprimées depuis
    locales = _lire_json(SUIVI_LOCAL, [])
    if not isinstance(locales, list):
        return []
    deja = {e["id"] for e in reconstruire(lire_evenements(racine))}
    return [e for e in locales if isinstance(e, dict) and e.get("id") and e["id"] not in deja]


def migrer_local_vers_partage(racine, auteur):
    """Copie les cartes du suivi local dans le dossier partagé (« En charge » = l'utilisateur). Le fichier local
    reste intact et une copie datée est conservée à côté. Renvoie le nombre de cartes reprises."""
    a_migrer = cartes_locales_a_migrer(racine)
    if a_migrer and SUIVI_LOCAL.exists():
        shutil.copy2(SUIVI_LOCAL, SUIVI_LOCAL.with_name(f"suivi_avant_partage_{datetime.now():%Y%m%d-%H%M%S}.json"))
    for e in a_migrer:
        carte = deepcopy(e)
        if isinstance(carte.get("iv"), dict):
            carte["iv"]["fichiers_prec"] = {}  # D-028 : aucun chemin de fichier dans le suivi
        carte.setdefault("relances", [])
        if not carte.get("en_charge"):
            carte["en_charge"] = auteur
        ecrire_evenement(racine, "creation", carte["id"], carte, auteur)
    maj_reglages(migre_vers=str(Path(racine)))
    return len(a_migrer)


def processus_actif(pid):
    """True si le processus `pid` existe encore (sert à ne pas prendre une seconde fenêtre pour un arrêt anormal)."""
    if not pid:
        return False
    try:
        if os.name == "nt":
            import ctypes
            handle = ctypes.windll.kernel32.OpenProcess(0x1000, False, int(pid))  # PROCESS_QUERY_LIMITED_INFORMATION
            if not handle:
                return False
            code = ctypes.c_ulong()
            ctypes.windll.kernel32.GetExitCodeProcess(handle, ctypes.byref(code))
            ctypes.windll.kernel32.CloseHandle(handle)
            return code.value == 259  # STILL_ACTIVE
        os.kill(int(pid), 0)
        return True
    except Exception:  # noqa: BLE001
        return False


def debut_session():
    """À appeler au démarrage. Renvoie True si la session précédente ne s'est pas terminée normalement (fenêtre fermée de
    force, blocage…) ; marque ensuite la session courante comme « en cours »."""
    r = reglages()
    plantage = not r.get("arret_propre", True) and not processus_actif(r.get("pid"))
    maj_reglages(arret_propre=False, pid=os.getpid())
    return plantage


FERMETURES_PROPRES_REQUISES = 3  # D-044 : retour automatique à la normale après ce nombre de fermetures normales de suite


def declencher_mode_securise_auto():
    """Mode sécurisé enclenché par un arrêt anormal : enregistré, avec un compteur de fermetures normales à zéro."""
    maj_reglages(mode_securise=True, securise_auto=True, fermetures_propres=0)


def quitter_mode_securise():
    """Sortie du mode sécurisé, demandée par l'utilisateur : il ne se rétablit pas de lui-même."""
    maj_reglages(mode_securise=False, securise_auto=False, fermetures_propres=0)


def fin_session():
    """Fermeture normale. Un mode sécurisé déclenché automatiquement est levé après 3 fermetures normales de suite ; un mode
    sécurisé coché par l'utilisateur reste actif jusqu'à ce qu'il le décoche."""
    r = reglages()
    maj_reglages(arret_propre=True)
    if r.get("mode_securise") and r.get("securise_auto"):
        n = int(r.get("fermetures_propres") or 0) + 1
        if n >= FERMETURES_PROPRES_REQUISES:
            maj_reglages(mode_securise=False, securise_auto=False, fermetures_propres=0, securise_leve_auto=True)
        else:
            maj_reglages(fermetures_propres=n)
