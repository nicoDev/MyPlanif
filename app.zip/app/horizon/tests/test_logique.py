"""Tests de la logique (sans interface ni Outlook réel) : suivi partagé, trigramme, relances, import d'adresses.

Usage :  py tests\\test_logique.py
Les fichiers de données sont redirigés vers un dossier temporaire : rien n'est écrit dans le dossier du projet.
"""
import json
import os
import sys
import tempfile
import types
from pathlib import Path

RACINE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(RACINE))

TMP = Path(tempfile.mkdtemp(prefix="planif_test_"))
os.environ["PLANIF_REGLAGES"] = str(TMP / "reglages")
os.environ["PLANIF_REGLAGES_ANCIEN"] = str(TMP / "reglages_beta2")

import adresses  # noqa: E402
import core  # noqa: E402
import import_excel  # noqa: E402
import partage  # noqa: E402

# --- redirection des fichiers de données vers le dossier temporaire
partage.SUIVI_LOCAL = TMP / "suivi.json"
core.SUIVI = partage.SUIVI_LOCAL
core.CARNET = TMP / "destinataires.json"
adresses.FICHIER = TMP / "adresses_outlook.json"
core.JOURNAL = TMP / "historique.json"
core.CAMPAGNES = {k: TMP / f"campagne_{k}.json" for k in ("metro", "nc", "jri")}
partage.recharger_reglages()

OK = []


def verifier(condition, message):
    assert condition, message
    OK.append(message)


def en_tant_que(tri):
    partage.maj_reglages(trigramme=tri)


def carte(**k):
    base = {"id": "c1", "onglet": "metro", "iv_id": "i1", "etat": "Planifié", "relances": [], "titre": "CHU · CC1 · Métrologie",
            "objet": "Métrologie COFRAC / CC1 / CHU", "debut": "01/11/2026", "fin": "02/11/2026",
            "premier_mail": "2026-10-01", "premier_mail_estime": False,
            "iv": {"client": "CHU", "commande": "CC1", "types": ["Métrologie COFRAC"]}}
    base.update(k)
    return base


# ================= trigramme =================
verifier(partage.trigramme_depuis("Nicolas WURTZ (NWU)", "nwurtz") == "NWU", "trigramme lu dans le nom d'affichage")
verifier(partage.trigramme_depuis("", "nwurtz") == "NWU", "repli : 3 premières lettres de la session")
verifier(partage.trigramme_depuis("Jean Dupont", "j.dupont") == "JDU", "repli sans parenthèses, ponctuation ignorée")
verifier(partage.trigramme_depuis("Éric Martin (ÉMA)", "emartin") == "EMA", "accents retirés du trigramme")
verifier(partage.trigramme_depuis("", "") == "", "aucune source : chaîne vide")
verifier(partage.trigramme_valide("NWU") and not partage.trigramme_valide("N") and not partage.trigramme_valide("NW U"),
         "validation du trigramme")

# ================= mode local (comme avant) =================
suivi = core.charger_suivi()
verifier(suivi == [], "suivi local vide au départ")
suivi.append(carte())
core.sauver_suivi(suivi)
verifier(json.loads(partage.SUIVI_LOCAL.read_text(encoding="utf-8"))[0]["id"] == "c1", "mode local : suivi.json écrit")
verifier(core.charger_suivi()[0]["titre"].startswith("CHU"), "mode local : relecture")

# ================= activation du partage + reprise des cartes locales =================
partage_dir = TMP / "OneDrive" / "Equipe"
partage_dir.mkdir(parents=True)
en_tant_que("NWU")
partage.activer(partage_dir)
verifier((partage_dir / partage.SOUS_DOSSIER / "schema.json").exists(), "structure du dossier partagé créée")
verifier(len(partage.cartes_locales_a_migrer(partage_dir)) == 1, "1 carte locale à reprendre")
verifier(partage.migrer_local_vers_partage(partage_dir, "NWU") == 1, "reprise de la carte locale")
verifier(partage.cartes_locales_a_migrer(partage_dir) == [], "pas de seconde reprise")
verifier(list(TMP.glob("suivi_avant_partage_*.json")) != [], "copie de sauvegarde datée créée")
verifier(partage.SUIVI_LOCAL.exists(), "suivi.json local conservé")
suivi = core.charger_suivi()
verifier(len(suivi) == 1 and suivi[0]["en_charge"] == "NWU", "carte reprise avec « En charge » = utilisateur")

# ================= deux utilisateurs sur le même dossier =================
en_tant_que("ABC")
b = core.charger_suivi()
verifier(len(b) == 1, "l'utilisateur B voit la carte de A")
en_tant_que("NWU")
a = core.charger_suivi()
# modifications simultanées de champs différents, à partir du même état de départ
a[0]["en_charge"] = "ABC"
b[0]["etat"] = "Date validée"
en_tant_que("NWU"); core.sauver_suivi(a)
en_tant_que("ABC"); core.sauver_suivi(b)
final = core.charger_suivi()
verifier(final[0]["en_charge"] == "ABC" and final[0]["etat"] == "Date validée", "modifications de champs différents fusionnées")
# relances simultanées
a, b = core.charger_suivi(), core.charger_suivi()
a[0]["relances"].append("2026-10-08"); b[0]["relances"].append("2026-10-09")
en_tant_que("NWU"); core.sauver_suivi(a); en_tant_que("ABC"); core.sauver_suivi(b)
verifier(core.charger_suivi()[0]["relances"] == ["2026-10-08", "2026-10-09"], "deux relances simultanées conservées")
a, b = core.charger_suivi(), core.charger_suivi()
a[0]["relances"].append("2026-10-10"); b[0]["relances"].append("2026-10-10")
core.sauver_suivi(a); core.sauver_suivi(b)
verifier(core.charger_suivi()[0]["relances"].count("2026-10-10") == 1, "relance identique non dupliquée")
# création par B, suppression par A, modification tardive de B ignorée
en_tant_que("ABC")
suivi, nouvelle = core.ajouter_suivi({"id": "i2", "debut": "05/11/2026", "fin": "06/11/2026", "client": "ACME"}, "jri", "ACME · CC2",
                                     "EXTENSION MYSIRIUS CLOUD / CC2 / ACME", en_charge="ABC")
core.sauver_suivi(suivi)
en_tant_que("NWU")
a = core.charger_suivi(); b_vue = core.charger_suivi()
verifier(len(a) == 2 and a[1]["en_charge"] == "ABC", "nouvelle carte créée par B visible par A, avec son auteur")
a.remove(next(x for x in a if x["id"] == nouvelle["id"])); core.sauver_suivi(a)
en_tant_que("ABC")
tardive = next(x for x in b_vue if x["id"] == nouvelle["id"]); tardive["etat"] = "Validée"; core.sauver_suivi(b_vue)
verifier([x["id"] for x in core.charger_suivi()] == ["c1"], "carte supprimée : modification tardive ignorée")
verifier(partage.auteurs() == {"NWU", "ABC"}, "auteurs connus")
verifier(core.trigrammes_connus(core.charger_suivi(), "NWU") == ["ABC", "NWU"], "trigrammes proposés pour « En charge »")
# jamais de modification d'un fichier existant : tous les événements portent un nom unique
noms = [p.name for p in (partage_dir / partage.SOUS_DOSSIER / "evenements").glob("*.json")]
verifier(len(noms) == len(set(noms)) and len(noms) >= 8, "un fichier distinct par événement")

# ================= robustesse =================
ev_dir = partage_dir / partage.SOUS_DOSSIER / "evenements"
(ev_dir / "20990101T000000000000_X_aaaaaa.json").write_text("{ pas du json", encoding="utf-8")
(ev_dir / "autre.json").write_text(json.dumps({"hello": 1}), encoding="utf-8")
(ev_dir / "20990101T000000000001_X_bbbbbb.json.part").write_text("{}", encoding="utf-8")
verifier(len(core.charger_suivi()) == 1, "fichiers corrompus, étrangers ou .part ignorés")
avant = partage.empreinte()
en_tant_que("NWU"); s = core.charger_suivi(); s[0]["maj"] = "x"; core.sauver_suivi(s)
verifier(partage.empreinte() != avant, "l'empreinte change après une écriture")
nulle = partage.ListeSuivi([carte(id="zz")])
try:
    partage.sauver(nulle)
    verifier(False, "liste non chargée refusée")
except ValueError:
    verifier(True, "liste non chargée refusée en mode partagé")
schema = partage_dir / partage.SOUS_DOSSIER / "schema.json"
schema.write_text(json.dumps({"schema": 99}), encoding="utf-8")
try:
    partage.verifier_dossier(partage_dir)
    verifier(False, "schéma trop récent refusé")
except RuntimeError:
    verifier(True, "schéma trop récent refusé")
schema.write_text(json.dumps({"schema": 1}), encoding="utf-8")
try:
    partage.activer(TMP / "inexistant")
    verifier(False, "dossier introuvable refusé")
except FileNotFoundError:
    verifier(True, "dossier introuvable refusé")

# ================= retour au mode local =================
partage.desactiver()
verifier(partage.dossier_partage() is None and core.charger_suivi()[0]["id"] == "c1", "retour au suivi local")

# ================= recherche et « En charge » =================
verifier(core.correspond_suivi({"titre": "x", "en_charge": "NWU"}, "nwu"), "recherche par « En charge »")

# ================= réglages du poste =================
partage.maj_reglages(expediteur="")
verifier(core.expediteur_effectif({"expediteur": "planning@group-mms.com"}) == "planning@group-mms.com", "expéditeur : config.json par défaut")
partage.maj_reglages(expediteur="moi@group-mms.com")
verifier(core.expediteur_effectif({"expediteur": "planning@group-mms.com"}) == "moi@group-mms.com", "expéditeur : réglage du poste prioritaire")
partage.maj_reglages(expediteur="")
verifier(core.boite_mail_initial({"expediteur": "planning@group-mms.com"}) == "planning@group-mms.com", "boîte du mail initial : expéditeur par défaut")
partage.maj_reglages(boite_relance="")
verifier(core.boite_mail_initial({"expediteur": "planning@group-mms.com"}) == "", "boîte du mail initial : vide = boîte par défaut")
partage.recharger_reglages()
verifier(partage.reglages()["boite_relance"] == "" and partage.reglages()["vue"] == "Tous", "réglages relus depuis le fichier")


# ================= faux Outlook : boîte partagée, relance, import =================
class Mail:
    def __init__(s, objet, dest=(), entry="E1"):
        s.Subject, s.EntryID, s.Recipients, s.To, s.CC = objet, entry, list(dest), "a@b.fr", ""
        s.SentOn = types.SimpleNamespace(year=2026, month=10, day=1)
        s.rep = types.SimpleNamespace(To="", CC="", HTMLBody="<html><body></body></html>", SentOnBehalfOfName="", Display=lambda *_: None)
    def ReplyAll(s): return s.rep


class Items(list):
    def Sort(s, *_): pass


class Dest:
    def __init__(s, adresse, type_="SMTP", smtp=""):
        s.Address = adresse
        s.AddressEntry = types.SimpleNamespace(Type=type_, GetExchangeUser=lambda: types.SimpleNamespace(PrimarySmtpAddress=smtp) if smtp else None)
        s.PropertyAccessor = types.SimpleNamespace(GetProperty=lambda *_: "")


class Contact:
    def __init__(s, adr, type_="SMTP"):
        s.Email1Address, s.Email1AddressType = adr, type_


class Ns:
    def __init__(s, partage_ok, envoyes_partage, envoyes_defaut, contacts=()):
        s.ok, s.p, s.d, s.c = partage_ok, envoyes_partage, envoyes_defaut, contacts
    def CreateRecipient(s, nom):
        return types.SimpleNamespace(Resolve=lambda: None, Resolved=s.ok)
    def GetSharedDefaultFolder(s, r, n): return types.SimpleNamespace(Items=Items(s.p))
    def GetDefaultFolder(s, n):
        return types.SimpleNamespace(Items=Items(s.c if n == 10 else s.d))
    def GetItemFromID(s, i): raise RuntimeError("inaccessible depuis cette boîte")


class Outlook:
    def __init__(s, ns): s.ns = ns
    def GetNamespace(s, _): return s.ns


objet = "Métrologie COFRAC / CC1 / CHU"
o = Outlook(Ns(True, [Mail(objet, entry="PARTAGE")], [Mail(objet, entry="DEFAUT")]))
verifier(core.retrouver_mail_envoye(o, objet, boite="planning@group-mms.com").EntryID == "PARTAGE", "mail initial cherché d'abord dans la boîte partagée")
o = Outlook(Ns(False, [Mail(objet, entry="PARTAGE")], [Mail(objet, entry="DEFAUT")]))
verifier(core.retrouver_mail_envoye(o, objet, boite="planning@group-mms.com").EntryID == "DEFAUT", "boîte partagée inaccessible : repli sur la boîte par défaut")
o = Outlook(Ns(True, [], [Mail(objet, entry="DEFAUT")]))
verifier(core.retrouver_mail_envoye(o, objet, boite="planning@group-mms.com").EntryID == "DEFAUT", "mail absent de la boîte partagée : trouvé dans la boîte par défaut")
verifier(core.retrouver_mail_envoye(o, "inconnu", boite="planning@group-mms.com") is None, "mail introuvable : None")
cfg = {"techniciens": [{"nom": "T", "email": "t@x.fr"}], "expediteur": "planning@group-mms.com"}
e = carte(entry_id="HORS_BOITE"); e["iv"].update(destinataires="d@x.fr", technicien="T", cc_tech=True)
o = Outlook(Ns(True, [Mail(objet, entry="PARTAGE")], []))
(TMP / "templates").mkdir(exist_ok=True)
core.BASE = RACINE  # les modèles de mail restent ceux du projet
core.creer_relance(o, cfg, e, boite="planning@group-mms.com")
verifier(e["entry_id"] == "PARTAGE", "relance : entry_id d'une autre boîte ignoré, mail retrouvé par l'objet")

c, n = core.fusionner_carnet(["a@x.fr"], ["A@X.fr", "b@x.fr", "pas-une-adresse"])
verifier(c == ["a@x.fr", "b@x.fr"] and n == 1, "fusion du carnet")


# ================= D-029 : réglages dans %LOCALAPPDATA% avec reprise de l'ancien emplacement =================
ancien = TMP / "reglages_beta2"
ancien.mkdir()
(ancien / "reglages.json").write_text(json.dumps({"trigramme": "ZZZ", "trigramme_confirme": True, "vue": "JRI"}), encoding="utf-8")
nouveau_fichier = TMP / "reglages_neuf" / "reglages.json"
os.environ["PLANIF_REGLAGES"] = str(nouveau_fichier.parent)
partage.recharger_reglages()
r = partage.reglages()
verifier(r["trigramme"] == "ZZZ" and r["vue"] == "JRI" and r["trigramme_confirme"] is True, "réglages repris depuis l'ancien emplacement")
verifier(nouveau_fichier.exists() and r["import_auto"] is True and r["apparence"] == "dark", "réglages recopiés dans le nouvel emplacement, valeurs par défaut ajoutées")
nouveau_fichier.write_text(json.dumps({"trigramme": "NEW"}), encoding="utf-8")
partage.recharger_reglages()
verifier(partage.reglages()["trigramme"] == "NEW", "le nouvel emplacement est prioritaire une fois créé")
os.environ["PLANIF_REGLAGES"] = str(TMP / "reglages")
partage.recharger_reglages()

# ================= D-028 : aucun chemin de fichier N-1 dans les cartes du suivi =================
cfg28 = core.charger_config()
iv28 = core.nouvelle_intervention("metro", cfg28)
iv28.update(client="X", commande="C28", types=["Métrologie COFRAC"], fichiers_prec={"Métrologie COFRAC": r"C:\Users\nwurtz\Doc\revue.xlsx"})
partage.desactiver()
suivi28, carte28 = core.ajouter_suivi(iv28, "metro", "t", "o")
verifier(carte28["iv"]["fichiers_prec"] == {}, "carte du suivi sans chemin de fichier N-1")
verifier(iv28["fichiers_prec"] != {}, "la fiche de planification garde son fichier N-1")
local28 = partage.SUIVI_LOCAL
local28.write_text(json.dumps([dict(carte28, iv=dict(carte28["iv"], fichiers_prec={"Métrologie COFRAC": r"C:\x.xlsx"}))]), encoding="utf-8")
dossier28 = TMP / "OneDrive" / "Equipe28"
dossier28.mkdir(parents=True)
partage.activer(dossier28)
partage.migrer_local_vers_partage(dossier28, "NWU")
verifier(core.charger_suivi()[0]["iv"]["fichiers_prec"] == {}, "reprise du suivi local : chemin de fichier retiré")
partage.desactiver()
local28.write_text("[]", encoding="utf-8")

# ================= D-032 à D-034 : base d'adresses Outlook =================
class Dest:
    def __init__(s, adresse, type_="SMTP", smtp=""):
        s.Address = adresse
        s.AddressEntry = types.SimpleNamespace(Type=type_, GetExchangeUser=(lambda: types.SimpleNamespace(PrimarySmtpAddress=smtp)) if smtp else (lambda: None))
        s.PropertyAccessor = types.SimpleNamespace(GetProperty=lambda *_: "")


class MailEnvoye:
    def __init__(s, jours, dests):
        s.SentOn = datetime.datetime(2026, 10, 12, 9, 0, 0) - datetime.timedelta(days=jours)
        s.Recipients = list(dests)


class Coll(list):
    def Sort(s, *_): pass
    @property
    def Count(s): return len(s)


class Rangee:
    def __init__(s, valeurs): s.v = valeurs
    def Item(s, k): return s.v[k - 1]


class Tab:
    def __init__(s, lignes): s.l, s.i = lignes, 0; s.Columns = types.SimpleNamespace(RemoveAll=lambda: None, Add=lambda u: None)
    @property
    def EndOfTable(s): return s.i >= len(s.l)
    def GetNextRow(s): s.i += 1; return Rangee([x for couple in s.l[s.i - 1] for x in couple])  # colonnes à plat, comme la vraie table


class Rep:
    def __init__(s, nom, items=(), enfants=(), lignes=None):
        s.Name, s.Items, s.Folders, s._lignes = nom, Coll(items), list(enfants), lignes
    def GetTable(s):
        if s._lignes is None: raise RuntimeError("pas de table")
        return Tab(s._lignes)


class Magasin:
    def __init__(s, nom, racine, special_ok=False, defaut=None):
        s.DisplayName, s._racine, s._ok, s._defaut = nom, racine, special_ok, defaut
    def GetRootFolder(s): return s._racine
    def GetSpecialFolder(s, n):
        if s._ok: return s._defaut
        raise RuntimeError("Paramètre incorrect.")


def monter_outlook(planning_envoyes, suggeres):
    """Outlook comme chez l'utilisateur : le raccourci et GetSpecialFolder échouent, planning@ n'est lisible que par le nom."""
    envoyes_moi = Rep("Éléments envoyés", [MailEnvoye(1, [Dest("client@hopital.fr")]), MailEnvoye(2, [Dest("/O=EXCH/CN=ABC", "EX", "collegue@group-mms.com")])])
    cache_moi = Rep("Recipient Cache", lignes=[[("cache1@x.fr", "SMTP"), ], [("cache2@x.fr", "SMTP")]])
    racine_moi = Rep("racine", enfants=[Rep("Contacts", enfants=[cache_moi])])
    moi = Magasin("nicolas.wurtz@group-mms.com", racine_moi)
    piege = Rep("Archive_Planning", enfants=[Rep("BLI / BLM ENVOYES AUX DEPLOYEURS")])
    sug = Rep("Contacts suggérés", suggeres, lignes=[[(a, "SMTP")] for a in suggeres] if suggeres else [])
    racine_pl = Rep("racine", enfants=[piege, Rep("Éléments envoyés", planning_envoyes), sug, Rep("Contacts", enfants=[Rep("Recipient Cache", lignes=[[("equipe@group-mms.com", "SMTP")]])])])
    pl = Magasin("planning@group-mms.com", racine_pl)
    archive = Magasin("Archive en ligne - planning@group-mms.com", Rep("racine", enfants=[Rep("Éléments envoyés", [MailEnvoye(0, [Dest("archive@x.fr")])])]))
    contacts = Rep("Contacts", lignes=[[("ctc@societe.fr", "SMTP"), ("ctc2@societe.fr", "SMTP"), ("", "SMTP")]])

    class Espace:
        Stores = [moi, archive, pl]
        DefaultStore = moi
        def CreateRecipient(s, n): return types.SimpleNamespace(Resolve=lambda: None, Resolved=True)
        def GetSharedDefaultFolder(s, r, n): raise RuntimeError("Paramètre incorrect.")
        def GetDefaultFolder(s, n): return contacts if n == 10 else envoyes_moi
    class Appli:
        def GetNamespace(s, _): return Espace()
    return Appli()


import datetime
planning_envoyes = [MailEnvoye(0, [Dest("tech@hopital.fr"), Dest("client@hopital.fr"), Dest("/O=EXCH/CN=ABC", "EX", "collegue@group-mms.com")]),
                    MailEnvoye(3, [Dest("autre@labo.fr")])]
suggeres = ["sug1@mcdo.fr", "sug2@aphp.fr", "client@hopital.fr", "SUG1@mcdo.fr"]
trouvees = adresses.localiser_envoyes(monter_outlook(planning_envoyes, suggeres), "planning@group-mms.com")
verifier(trouvees[0]["dossier"] is not None and trouvees[0]["methode"] == "dossier trouvé par son nom", "planning@ lu par le nom du dossier quand le raccourci échoue")
verifier(trouvees[0]["dossier"].Name == "Éléments envoyés" and len(trouvees[0]["dossier"].Items) == 2, "dossier d'envois racine choisi (pas le sous-dossier BLI / BLM)")
verifier(trouvees[1]["libelle"] == "Votre boîte" and len(trouvees[1]["dossier"].Items) == 2, "boîte par défaut lue aussi")
verifier(len(core.dossiers_envoyes(monter_outlook(planning_envoyes, suggeres), "planning@group-mms.com")) == 2, "les relances cherchent dans planning@ puis dans la boîte par défaut")
inconnue = adresses.localiser_envoyes(monter_outlook(planning_envoyes, suggeres), "absente@group-mms.com")
verifier(inconnue[0]["dossier"] is None and "non ouverte" in inconnue[0]["erreur"], "boîte absente : erreur explicite, pas de lecture silencieuse")

imp = adresses.ImportAdresses(monter_outlook(planning_envoyes, suggeres), "planning@group-mms.com", complet=True, tranche=0.0)
valeurs = list(imp.etapes())
verifier(len(valeurs) > 5 and all(0 <= f <= t for _, f, t in valeurs), "progression par tranches : valeurs cohérentes")
verifier([f for _, f, _ in valeurs] == sorted(f for _, f, _ in valeurs), "progression croissante")
base = adresses.charger_base()["adresses"]
verifier({"tech@hopital.fr", "client@hopital.fr", "collegue@group-mms.com", "autre@labo.fr", "sug1@mcdo.fr", "sug2@aphp.fr", "cache1@x.fr", "cache2@x.fr", "equipe@group-mms.com", "ctc@societe.fr", "ctc2@societe.fr"} <= set(base), "toutes les sources lues : envoyés, suggérés, caches, contacts")
verifier("archive@x.fr" not in base, "l'archive en ligne n'est pas lue (nom de boîte exact)")
verifier(len(base) == len({a.lower() for a in base}) == 11, "aucun doublon (casse ignorée)")
verifier(any("planning@group-mms.com" in r and "dossier trouvé par son nom" in r for r in imp.rapport), "compte rendu : boîte lue et méthode")
verifier(adresses.charger_base()["cache_ex"].get("/O=EXCH/CN=ABC") == "collegue@group-mms.com", "adresse interne convertie et mise en cache")
verifier(base.index("tech@hopital.fr") < base.index("sug1@mcdo.fr"), "adresses des mails envoyés avant les autres sources")
# import incrémental : rien de nouveau, suggérés non relus
imp2 = adresses.ImportAdresses(monter_outlook(planning_envoyes, suggeres), "planning@group-mms.com", complet=False)
imp2.executer()
verifier(imp2.ajoutees == 0 and not any("suggérés" in r for r in imp2.rapport), "démarrage : rien de nouveau, contacts suggérés non relus (< 7 jours)")
verifier(any("0 mail(s) lu(s)" in r for r in imp2.rapport), "démarrage : seuls les mails récents sont relus")
nouveaux_mails = [MailEnvoye(-1, [Dest("nouveau@client.fr")])] + planning_envoyes
imp3 = adresses.ImportAdresses(monter_outlook(nouveaux_mails, suggeres), "planning@group-mms.com", complet=False)
imp3.executer()
verifier(imp3.ajoutees == 1 and "nouveau@client.fr" in adresses.charger_base()["adresses"][:3], "démarrage : un nouveau mail ajoute son destinataire en tête")
imp4 = adresses.ImportAdresses(monter_outlook(planning_envoyes, suggeres), "planning@group-mms.com", complet=True)
imp4.executer()
verifier(any("Contacts suggérés" in r for r in imp4.rapport), "import complet : contacts suggérés relus à la demande")
# boîte inaccessible : avertissement visible
imp5 = adresses.ImportAdresses(monter_outlook(planning_envoyes, suggeres), "absente@group-mms.com", complet=False)
imp5.executer()
verifier(any("absente@group-mms.com" in a and "inaccessible" in a for a in imp5.avertissements), "boîte inaccessible : avertissement dans le compte rendu")
# limite de mails lus
imp6 = adresses.ImportAdresses(monter_outlook(planning_envoyes, suggeres), "planning@group-mms.com", complet=True, limite=1)
imp6.executer()
verifier(any("planning@group-mms.com : 1 mail(s) lu(s)" in r for r in imp6.rapport), "limite du nombre de mails lus respectée")
# suggestions : carnet d'abord, puis base d'Outlook
core.ecrire_json(core.CARNET, ["sug1@perso.fr"])
sug = core.suggestions_carnet(core.charger_carnet(), "sug")
verifier(sug[0] == "sug1@perso.fr" and "sug1@mcdo.fr" in sug and "sug2@aphp.fr" in sug, "suggestions : carnet en premier, puis base d'Outlook")
verifier(core.suggestions_carnet([], "mcdo", avec_base=False) == [] and core.suggestions_carnet([], "mcdo") == ["sug1@mcdo.fr"], "suggestions : base d'Outlook activable")
verifier(core.suggestions_carnet([], "sug1@mcdo.fr; sug1") == [] or "sug1@mcdo.fr" not in core.suggestions_carnet([], "sug1@mcdo.fr; sug1"), "suggestions : adresse déjà saisie exclue")
# repli : lecture élément par élément quand la table est indisponible
class Rep2(Rep):
    def GetTable(s): raise RuntimeError("pas de table")
class It:
    def __init__(s, a): s.Email1Address, s.Email1AddressType = a, "SMTP"
alt = Rep2("Contacts suggérés"); alt.Items = Coll([It("repli1@x.fr"), It("repli2@x.fr")])
imp7 = adresses.ImportAdresses(monter_outlook([], []), "", complet=True)
lues = [l for l in imp7._lignes(alt, 1) if l is not None]
verifier(lues == [(("repli1@x.fr", "SMTP"),), (("repli2@x.fr", "SMTP"),)], "repli élément par élément quand la lecture par table échoue")

# ================= D-030 : import Excel =================
try:
    import openpyxl
except ImportError:
    openpyxl = None
if openpyxl is None:
    print("(openpyxl absent : tests de l'import Excel ignorés)")
else:
    classeur = openpyxl.Workbook()
    f = classeur.active
    f.append(["ACTIVITE", "(Tous)"]); f.append([]); f.append([])
    f.append(["DATE DE SAISIE", "N° COMMANDE", "ÉTAT COMMANDE", "VOTRE RÉFÉRENCE", "COMMERCIAL PRINCIPAL", "NOM SITE", "CODE POSTAL SITE", "VILLE SITE", "GROUPE", "REFERENCE ARTICLE", "DESIGNATION ARTICLE", "QUANTITE"])
    f.append([None, "CC1", "ACTIVE", "r", "DBU", "CHU A", 1, "V", "METROLOGIE COFRAC SUR SITE", 1, "x", 2])
    f.append([None, None, None, None, None, None, None, None, "METROLOGIE NON COFRAC SUR SITE", 2, "y", 3])
    f.append([None, None, None, None, None, None, None, None, None, None, None, 5])           # sous-total
    f.append([None, "CC2", "SUSPENDUE", "r", "JCR", "ROQUETTE VIC/AISNE", 1, "V", "CARACTERISATION NON COFRAC", 3, "z", 1])
    f.append([None, "CC3", "ACTIVE", "r", "LCA", "SOCIETE B", 1, "V", "QUALIFICATION", 4, "q", 1])
    f.append([None, None, None, None, None, None, None, None, "HVAC", 5, "h", 1])
    f.append([None, "CC4", "ACTIVE", "r", "LCA", "SOCIETE C", 1, "V", "LOGICIEL DIVERS", 6, "l", 1])
    f.append(["Total général"])
    chemin = TMP / "export.xlsx"
    classeur.save(chemin)
    cfg30 = core.charger_config()
    res = import_excel.lire_export(chemin, cfg30)
    P = res["propositions"]
    verifier(res["commandes"] == 4 and len(P) == 5, "export lu : 4 commandes, 5 fiches (CC1 se répartit sur deux onglets)")
    cc1 = [p for p in P if p["commande"] == "CC1"]
    verifier({(p["kind"], tuple(p["types"])) for p in cc1} == {("metro", ("Métrologie COFRAC",)), ("nc", ("Métrologie non COFRAC",))}, "commande mixte : une fiche COFRAC et une fiche Non COFRAC")
    cc3 = next(p for p in P if p["commande"] == "CC3")
    verifier(cc3["kind"] == "nc" and cc3["types"] == ["Qualification", "HVAC"], "Qualification et HVAC reconnus par mots-clés")
    verifier(next(p for p in P if p["commande"] == "CC2")["cocher"] is False and "suspendue" in next(p for p in P if p["commande"] == "CC2")["remarque"], "commande suspendue : proposée mais décochée")
    cc4 = next(p for p in P if p["commande"] == "CC4")
    verifier(cc4["types"] == [] and "LOGICIEL DIVERS" in cc4["remarque"] and not cc4["cocher"], "groupe inconnu signalé, rien d'importé")
    verifier(next(p for p in P if p["commande"] == "CC2")["client"] == "ROQUETTE VIC/AISNE", "nom de client conservé tel quel (« / » et « & »)")
    import_excel.marquer_doublons(P, {("nc", import_excel.cle_commande(" cc3 "))})
    verifier(cc3["doublon"] and not cc3["cocher"] and "déjà présente" in cc3["remarque"], "doublon détecté (casse et espaces ignorés), décoché")
    verifier(import_excel.type_pour_groupe("METROLOGIE NON COFRAC SUR SITE", cfg30) == ("nc", "Métrologie non COFRAC"), "groupe -> onglet et type")
    verifier(import_excel.type_pour_groupe("AUTRE", cfg30) is None, "groupe inconnu -> aucun type")
    mauvais = openpyxl.Workbook(); mauvais.active.append(["a", "b"]); mauvais.save(TMP / "mauvais.xlsx")
    try:
        import_excel.lire_export(TMP / "mauvais.xlsx", cfg30)
        verifier(False, "fichier sans colonnes attendues refusé")
    except ValueError:
        verifier(True, "fichier sans colonnes attendues refusé avec un message clair")


# ================= D-037 : pastille ronde et fond (Pillow) ; D-039 : aucune couleur bleue ou grise en dur =================
import re
for fichier in ("app.py", "widgets.py"):
    source = (RACINE / fichier).read_text(encoding="utf-8")
    verifier(not re.search(r"#1f6aa5|#3B8ED0|#2e7d32|#b71c1c|gray\d", source), fichier + " : aucune couleur bleue ou grise en dur")
try:
    import PIL
except ImportError:
    PIL = None
if PIL is None:
    print("(Pillow absent : tests du fond et de la pastille ignorés)")
else:
    import fond
    image = fond.dessiner(400, 300, "dark")
    verifier(image.size == (400, 300) and image.mode == "RGB", "fond dessiné à la taille demandée")
    for mode in ("dark", "light"):
        arriere = fond.dessiner(400, 300, mode).crop((300, 16, 340, 56))
        pastille = fond.pastille(arriere, "NWU", mode)
        verifier(pastille.size == (40, 40), f"pastille {mode} : 40 × 40")
        verifier(pastille.getpixel((0, 0)) == arriere.getpixel((0, 0)), f"pastille {mode} : coins = fond (aucun carré visible)")
        verifier(pastille.getpixel((20, 5)) == fond.PALETTES[mode]["laiton"], f"pastille {mode} : disque plein couleur laiton")
    verifier(fond.pastille(fond.dessiner(400, 300, "dark").crop((300, 16, 340, 56)), "?", "dark").size == (40, 40), "pastille sans trigramme")


# ================= D-040 / D-041 : import JRI, texte collé depuis Excel =================
import datetime as _dt
verifier(import_excel.lire_date(_dt.datetime(2026, 10, 3)) == _dt.date(2026, 10, 3), "date : cellule Excel")
verifier(import_excel.lire_date("03/10/2026") == import_excel.lire_date("2026-10-03") == import_excel.lire_date("2026-10-03 00:00:00") == _dt.date(2026, 10, 3), "date : JJ/MM/AAAA, AAAA-MM-JJ, avec heure")
verifier(import_excel.lire_date("n'importe quoi") is None and import_excel.lire_date("") is None and import_excel.lire_date(None) is None, "date illisible ou absente : None")
cfg40 = core.charger_config()
passee, future = "01/01/2020", "01/01/2099"
tableau = [["N° COMMANDE", "VOTRE RÉFÉRENCE", "NOM SITE", "ÉTAT COMMANDE", "DELAI REPORTE", "DATE D'INTER"],
           ["CC1", "ref", "CHU A", "ACTIVE", _dt.datetime(2020, 1, 1), passee],
           ["CC2", "ref", "CHU B", "ACTIVE", _dt.datetime(2020, 1, 1), future],
           ["CC3", "ref", "CHU C", "SUSPENDUE", None, _dt.datetime(2099, 2, 2)],
           ["CC4", "ref", "CHU D", "ACTIVE", None, ""],
           ["CC5", "ref", "CHU E", "ACTIVE", None, "pas une date"],
           [None, None, None, None, None, None],
           ["Total général"]]
res40 = import_excel.proposer(tableau, cfg40, "jri")
P40 = {p["commande"]: p for p in res40["propositions"]}
verifier(res40["commandes"] == 5 and all(p["kind"] == "jri" for p in P40.values()), "JRI : une fiche par ligne, lignes vides et total ignorés")
verifier(P40["CC1"]["date_debut"] == passee and "date passée" in P40["CC1"]["remarque"], "JRI : date d'intervention passée signalée")
verifier(P40["CC2"]["date_debut"] == future and P40["CC2"]["remarque"] == "" and P40["CC2"]["cocher"], "JRI : date future, cochée d'office")
verifier(P40["CC3"]["date_debut"] == "02/02/2099" and not P40["CC3"]["cocher"] and "suspendue" in P40["CC3"]["remarque"], "JRI : commande suspendue décochée")
verifier("date d'intervention absente" in P40["CC4"]["remarque"] and "date illisible" in P40["CC5"]["remarque"], "JRI : date absente ou illisible signalée")
verifier(all("DELAI" not in str(v) and "delai" not in str(v).lower() for p in P40.values() for v in p.values()), "JRI : DELAI REPORTE ignoré")
try:
    import_excel.proposer([["N° COMMANDE", "GROUPE"], ["CC1", "x"]], cfg40, "jri")
    verifier(False, "JRI : NOM SITE obligatoire")
except ValueError as exc:
    verifier("NOM SITE" in str(exc), "JRI : colonne NOM SITE manquante -> message clair")
# colonnes facultatives NATURE et HÉBERGEMENT
res_nh = import_excel.proposer([["N° COMMANDE", "NOM SITE", "NATURE", "HÉBERGEMENT"], ["CC9", "X", "Extension", "serveur"], ["CC8", "Y", "", ""]], cfg40, "jri")
verifier(res_nh["propositions"][0]["nature"] == "extension" and res_nh["propositions"][0]["hebergement"] == "Serveur", "JRI : colonnes NATURE et HÉBERGEMENT lues")
# fiche JRI d'après une ligne importée
iv40 = core.nouvelle_intervention("jri", cfg40)
core.appliquer_import_jri(iv40, P40["CC2"])
iv40["technicien"] = cfg40["techniciens"][0]["nom"]  # l'intervenant n'est plus choisi d'office (D-055)
verifier(iv40["client"] == "CHU B" and iv40["commande"] == "CC2" and iv40["deploiement_debut"] == iv40["deploiement_fin"] == future, "fiche JRI : client, commande, début = fin = date d'intervention")
verifier(iv40["debut"] == iv40["fin"] == future and iv40["a_verifier"] is True, "fiche JRI : début / fin calculés, « à vérifier » par défaut")
core.valider(cfg40, iv40, "jri")
verifier(core.construire_objet(cfg40, iv40, "jri") == "INSTALLATION MYSIRIUS CLOUD / CC2 / CHU B", "fiche JRI importée : objet cohérent avec les valeurs par défaut")
iv41 = core.nouvelle_intervention("jri", cfg40); core.appliquer_import_jri(iv41, res_nh["propositions"][0])
verifier(iv41["a_verifier"] is False and iv41["nature"] == "extension" and iv41["hebergement"] == "Serveur", "fiche JRI : nature et hébergement du fichier -> plus à vérifier")
# texte collé depuis Excel
colle = "N° COMMANDE\tNOM SITE\tÉTAT COMMANDE\tDATE D'INTER\nCC10\t\"CHU, avec « virgule »\"\tACTIVE\t03/10/2099\nCC11\tCHU\tACTIVE\t\n"
lignes = import_excel.lire_presse_papiers(colle)
verifier(lignes[1][1] == "CHU, avec « virgule »" and len(lignes) == 3, "texte collé : tabulations et guillemets de cellule")
pc = import_excel.proposer(lignes, cfg40, "jri")["propositions"]
verifier([p["commande"] for p in pc] == ["CC10", "CC11"] and pc[0]["date_debut"] == "03/10/2099" and pc[1]["date_absente"], "texte collé : propositions JRI")
verifier(import_excel.lire_presse_papiers("N° COMMANDE;NOM SITE\nCC1;CHU\n")[1] == ["CC1", "CHU"], "texte collé : séparateur « ; » accepté à défaut")
verifier(import_excel.lire_presse_papiers("\r\nN° COMMANDE\tNOM SITE\r\nCC1\tCHU\r\n")[1] == ["CC1", "CHU"], "texte collé : fins de ligne Windows et lignes vides en tête")
colle_cofrac = "N° COMMANDE\tÉTAT COMMANDE\tNOM SITE\tGROUPE\tREFERENCE ARTICLE\nCC20\tACTIVE\tCHU Z\tMETROLOGIE COFRAC SUR SITE\tA1\n\t\t\tHVAC\tA2\n\t\t\t\t\n"
pcof = import_excel.proposer(import_excel.lire_presse_papiers(colle_cofrac), cfg40, "types")["propositions"]
verifier({(p["kind"], tuple(p["types"])) for p in pcof} == {("metro", ("Métrologie COFRAC",)), ("nc", ("HVAC",))}, "texte collé COFRAC / Non COFRAC : mêmes règles que le fichier")
try:
    import_excel.proposer(import_excel.lire_presse_papiers("CC1\tCHU\nCC2\tCHU2\n"), cfg40, "jri")
    verifier(False, "texte collé sans titres refusé")
except ValueError as exc:
    verifier("première ligne" in str(exc), "texte collé sans titres : message qui demande la ligne des titres")

verifier("GROUPE" in import_excel.proposer([["N° COMMANDE", "NOM SITE", "GROUPE"], ["CC1", "X", "HVAC"]], cfg40, "jri")["avertissement"], "JRI : colonne GROUPE présente -> avertissement (export COFRAC ?)")
verifier(import_excel.proposer(tableau, cfg40, "jri")["avertissement"] == "", "JRI : pas d'avertissement sur un tableau JRI")


# ================= D-042 : journal, détection de blocage, arrêt anormal, import en arrière-plan =================
import time as _time
import diagnostic
adresses.PAUSE_REPOS = 0.0
diagnostic.journal("essai")
verifier("essai" in diagnostic.fichier_journal().read_text(encoding="utf-8"), "journal : ligne horodatée écrite")
gros = diagnostic.fichier_journal(); gros.write_text("x" * (diagnostic.TAILLE_MAX + 10), encoding="utf-8"); diagnostic.journal("après rotation")
verifier(gros.with_suffix(".old").exists() and gros.read_text(encoding="utf-8").count("après rotation") == 1, "journal : rotation au-delà de la taille maximale")
gros.unlink(); gros.with_suffix(".old").unlink()


def fonction_bloquante():
    _time.sleep(0.9)


veille = diagnostic.Surveillance(seuil=0.3, periode=0.1)
veille.demarrer(); veille.battre()
fonction_bloquante()
_time.sleep(0.2)
texte_journal = diagnostic.fichier_journal().read_text(encoding="utf-8")
verifier("BLOCAGE" in texte_journal and "fonction_bloquante" in texte_journal, "surveillance : un blocage est journalisé avec la pile du fil principal")
verifier(veille.blocages == 1, "surveillance : un seul signalement par épisode de blocage")
veille.battre()
verifier("La fenêtre répond de nouveau" in diagnostic.fichier_journal().read_text(encoding="utf-8"), "surveillance : retour à la normale journalisé")
veille.arreter()
calme = diagnostic.Surveillance(seuil=0.5, periode=0.05); calme.demarrer()
for _ in range(10):
    _time.sleep(0.05); calme.battre()
calme.arreter()
verifier(calme.blocages == 0, "surveillance : aucun faux signalement quand la fenêtre répond")

verifier(partage.processus_actif(os.getpid()) and not partage.processus_actif(0) and not partage.processus_actif(99999999), "processus : actif / inexistant")
partage.maj_reglages(arret_propre=True, pid=0)
verifier(partage.debut_session() is False, "session : démarrage normal, pas d'arrêt anormal")
verifier(partage.debut_session() is False, "session : une seconde fenêtre ouverte n'est pas prise pour un arrêt anormal")
partage.maj_reglages(arret_propre=False, pid=99999999)
verifier(partage.debut_session() is True, "session : arrêt anormal détecté (processus précédent disparu)")
partage.fin_session()
verifier(partage.reglages()["arret_propre"] is True and partage.reglages()["mode_securise"] is False and partage.reglages()["fond_actif"] is True, "session : arrêt propre enregistré, réglages de dépannage par défaut")


def attendre(import_, delai=10):
    messages, debut = [], _time.monotonic()
    while _time.monotonic() - debut < delai:
        messages += import_.lire()
        if any(g in ("fin", "annule", "ignore", "erreur") for g, _ in messages):
            return messages
        _time.sleep(0.01)
    return messages


fil = adresses.ImportEnArrierePlan(lambda: monter_outlook(planning_envoyes, suggeres), "planning@group-mms.com", complet=True, pause=0.0, tranche=0.0)
fil.demarrer(); msgs_fil = attendre(fil)
genres = [g for g, _ in msgs_fil]
verifier(genres[-1] == "fin" and genres.count("etat") > 3 and "ajoutée" in msgs_fil[-1][1].resume, "import en arrière-plan : progression puis fin avec résumé")
verifier(any("dossier trouvé par son nom" in r for r in msgs_fil[-1][1].rapport) and not (adresses.FICHIER.with_name(adresses.FICHIER.name + ".tmp")).exists(), "import en arrière-plan : compte rendu, aucun fichier temporaire laissé")
fil2 = adresses.ImportEnArrierePlan(lambda: monter_outlook(planning_envoyes, suggeres), "planning@group-mms.com", complet=True, pause=0.05, tranche=0.0)
fil2.demarrer(); fil2.arreter(); msgs2 = attendre(fil2)
verifier(msgs2[-1][0] == "annule", "import en arrière-plan : annulation prise en compte")
fil3 = adresses.ImportEnArrierePlan(lambda: None, "x", pause=0.0); fil3.demarrer()
verifier(attendre(fil3)[-1][0] == "ignore", "import en arrière-plan : Outlook fermé -> ignoré sans erreur")
def casse(): raise RuntimeError("Outlook ne répond pas")
fil4 = adresses.ImportEnArrierePlan(casse, "x", pause=0.0); fil4.demarrer()
m4 = attendre(fil4)[-1]
verifier(m4[0] == "erreur" and "Outlook ne répond pas" in m4[1], "import en arrière-plan : erreur d'Outlook rapportée, jamais de blocage")
# lecture et écriture simultanées de la base : jamais de fichier tronqué
import threading
erreurs_lecture = []
def lire_en_boucle():
    for _ in range(200):
        try:
            json.loads(adresses.FICHIER.read_text(encoding="utf-8"))
        except Exception as exc:  # noqa: BLE001
            erreurs_lecture.append(exc)
lecteur = threading.Thread(target=lire_en_boucle); lecteur.start()
for _ in range(40):
    adresses.ecrire_base(adresses.charger_base())
lecteur.join()
verifier(erreurs_lecture == [], "base d'adresses : écriture atomique (aucune lecture tronquée)")


# ================= D-043 : seules les opérations lentes sont journalisées =================
with diagnostic.chrono("opération rapide", seuil=0.5):
    pass
with diagnostic.chrono("opération lente d'essai", seuil=0.05):
    _time.sleep(0.12)
texte_lenteur = diagnostic.fichier_journal().read_text(encoding="utf-8")
verifier("LENTEUR : opération lente d'essai" in texte_lenteur and "opération rapide" not in texte_lenteur, "chrono : seule l'opération lente est journalisée")
try:
    with diagnostic.chrono("opération en erreur", seuil=0.0):
        raise ValueError("x")
except ValueError:
    verifier("LENTEUR : opération en erreur" in diagnostic.fichier_journal().read_text(encoding="utf-8"), "chrono : mesure aussi les opérations qui échouent, sans masquer l'erreur")


# ================= D-045 : kit d'installeur (construction, script Inno Setup, lanceur) =================
import importlib.util, shutil as _shutil, tempfile as _tempfile
_spec = importlib.util.spec_from_file_location("construire", RACINE / "installeur" / "construire.py")
construire = importlib.util.module_from_spec(_spec); _spec.loader.exec_module(construire)
verifier(construire.lire_version(RACINE) == core.VERSION, "installeur : la version est lue dans core.py")
fichiers = construire.fichiers_application(RACINE)
noms = {str(p).replace("\\", "/") for p in fichiers}
verifier(all(m in noms for m in construire.MODULES) and "config.json" in noms and "requirements.txt" in noms, "installeur : modules et fichiers de base embarqués")
verifier(any(n.startswith("templates/") for n in noms) and any(n.startswith("modeles/") for n in noms) and any(n.startswith("outils/") for n in noms), "installeur : modèles de mail, revues techniques et outils embarqués")
verifier(not any(set(n.split("/")) & {"__pycache__", "_archives", ".venv", "tests"} for n in noms), "installeur : ni caches, ni archives, ni tests, ni .venv")
verifier(not any(n.split("/")[-1] in ("campagne.json", "campagne_nc.json", "campagne_jri.json", "suivi.json", "destinataires.json", "historique.json", "adresses_outlook.json", "reglages.json") for n in noms), "installeur : aucune donnée d'exploitation embarquée")
# Python allégé : copie d'un faux Python
faux = Path(_tempfile.mkdtemp()) / "py"
for chemin in ("python.exe", "pythonw.exe", "Lib/os.py", "Lib/tkinter/__init__.py", "DLLs/_tkinter.pyd", "DLLs/outil.pdb", "tcl/tcl8.6/init.tcl",
               "Doc/a.html", "include/b.h", "libs/c.lib", "Tools/d.py", "Scripts/pip.exe", "Lib/test/test_x.py", "Lib/idlelib/i.py",
               "Lib/site-packages/autre/z.py", "Lib/__pycache__/q.pyc", "Lib/tkinter/__pycache__/r.pyc", "Lib/json/__init__.py"):
    (faux / chemin).parent.mkdir(parents=True, exist_ok=True); (faux / chemin).write_text("x")
construire.verifier_runtime(faux)
copie = faux.parent / "copie"
_shutil.copytree(faux, copie, ignore=construire.ignorer_runtime(faux))
gardes = {str(p.relative_to(copie)).replace("\\", "/") for p in copie.rglob("*") if p.is_file()}
verifier({"python.exe", "pythonw.exe", "Lib/os.py", "Lib/tkinter/__init__.py", "Lib/json/__init__.py", "DLLs/_tkinter.pyd", "tcl/tcl8.6/init.tcl"} <= gardes, "Python allégé : l'essentiel est conservé (exécutables, bibliothèque standard, Tk, Tcl)")
verifier(not any(g.startswith(("Doc/", "include/", "libs/", "Tools/", "Scripts/", "Lib/test/", "Lib/idlelib/", "Lib/site-packages/")) or "__pycache__" in g or g.endswith(".pdb") for g in gardes), "Python allégé : documentation, tests, IDLE, caches et bibliothèques tierces retirés")
(faux / "tcl" / "tcl8.6" / "init.tcl").unlink(); _shutil.rmtree(faux / "tcl")
try:
    construire.verifier_runtime(faux)
    verifier(False, "Python incomplet refusé")
except ValueError as exc:
    verifier("tcl" in str(exc), "Python sans Tcl/Tk refusé avec un message clair")
_shutil.rmtree(faux.parent, ignore_errors=True)
verifier(construire.trouver_iscc() is None or construire.trouver_iscc().name.lower() == "iscc.exe", "installeur : recherche d'Inno Setup sans erreur")
# script Inno Setup
iss = (RACINE / "installeur" / "Horizon.iss").read_text(encoding="utf-8-sig")
verifier("AppId={{89079A4C-AC50-4D39-9033-915AF28D6BEB}" in iss, "Inno : identifiant d'application fixe (les mises à jour remplacent l'installation)")
verifier("PrivilegesRequired=lowest" in iss and "{localappdata}\\PlanifIntervention" in iss, "Inno : installation sans droits d'administrateur, dans un dossier local")
verifier("CloseApplications=yes" in iss and '{app}\\python' in iss and "{app}\\app" in iss, "Inno : fermeture de l'application ouverte, Python et application installés séparément")
verifier("config.json\"; DestDir" in iss and "onlyifdoesntexist" in iss.split("config.json\"; DestDir")[1].split("\n")[0], "Inno : config.json existant jamais écrasé")
verifier("modeles\\*\"; DestDir" in iss and "onlyifdoesntexist" in iss.split("modeles\\*\"; DestDir")[1].split("\n")[0], "Inno : revues techniques et prérequis remplacés par l'utilisateur jamais écrasés")
verifier("-s -E" in iss and "--securise" in iss and "pythonw.exe" in iss, "Inno : raccourcis sans console, un raccourci en mode sécurisé")
verifier("onedrive" in iss.lower() and "DelTree" in iss, "Inno : avertissement OneDrive, suppression des données facultative à la désinstallation")
verifier((RACINE / "installeur" / "apres_installation.txt").is_file() and "InfoAfterFile=apres_installation.txt" in iss, "Inno : texte de fin d'installation présent")
verifier(not any(m in iss for m in ("campagne.json", "suivi.json", "destinataires.json")), "Inno : aucune donnée d'exploitation dans l'installeur")
lanceur = (RACINE / "construire_installeur.bat").read_bytes()
verifier(lanceur.isascii() and b"\r\n" in lanceur and b"installeur\\construire.py" in lanceur, "construire_installeur.bat : ASCII, fins de ligne Windows, appelle construire.py")


# ================= D-046 : nom Horizon et nouvelle icône =================
from PIL import Image as _Image
ico = _Image.open(RACINE / "assets" / "horizon.ico")
verifier({(16, 16), (32, 32), (48, 48), (256, 256)} <= set(ico.info["sizes"]), "icône Horizon : plusieurs tailles (16 à 256) pour la barre des tâches et les raccourcis")
logo_png = _Image.open(RACINE / "assets" / "horizon.png")
verifier(logo_png.size == (512, 512) and logo_png.mode == "RGBA", "logo Horizon : 512 x 512 avec transparence")
verifier(all((RACINE / r).is_file() for r in construire.RESSOURCES), "installeur : toutes les ressources déclarées existent")
verifier({"assets/horizon.ico", "assets/horizon.png"} <= {str(p).replace("\\", "/") for p in construire.fichiers_application(RACINE)}, "installeur : l'icône et le logo sont embarqués avec l'application")
iss = (RACINE / "installeur" / "Horizon.iss").read_text(encoding="utf-8-sig")
verifier('#define NomAppli "Horizon"' in iss and "OutputBaseFilename=Setup_Horizon_" in iss, "Inno : nom Horizon et installeur Setup_Horizon_<version>.exe")
verifier("SetupIconFile=..\\assets\\horizon.ico" in iss and iss.count("assets\\horizon.ico") >= 5, "Inno : icône Horizon pour l'installeur, le désinstalleur et les trois raccourcis")
verifier("planif.ico" not in iss, "Inno : plus de référence à l'ancienne icône")
verifier(all(c in iss for c in ('{autoprograms}\\Planif Intervention.lnk', '{autoprograms}\\Planif Intervention (mode sécurisé).lnk', '{autodesktop}\\Planif Intervention.lnk')), "Inno : les anciens raccourcis « Planif Intervention » sont retirés à la mise à jour")
verifier("#if FileExists(" in iss and "wizard_grand.bmp" in iss and "wizard_petit.bmp" in iss, "Inno : images de l'assistant utilisées seulement si elles existent")
verifier('AppId={{89079A4C-AC50-4D39-9033-915AF28D6BEB}' in iss and "DefaultDirName={localappdata}\\PlanifIntervention" in iss, "Inno : identifiant et dossier technique conservés (données et mises à jour préservées)")
source_app = (RACINE / "app.py").read_text(encoding="utf-8")
verifier('self.title(f"Horizon v{VERSION}"' in source_app and "Planif Intervention" not in source_app, "application : titre « Horizon vX » et plus aucun message « Planif Intervention »")
verifier((RACINE / "installeur" / "apres_installation.txt").read_text(encoding="utf-8-sig").startswith("Horizon est installé."), "installeur : texte de fin d'installation au nom d'Horizon")
verifier(all("Planif Intervention" not in (RACINE / b).read_text(encoding="utf-8", errors="replace") for b in ("lancer_securise.bat", "creer_environnement.bat", "verifier_installation.bat")), "fichiers .bat : nom Horizon")
sombre_sans = fond.dessiner(500, 300, "dark", logo=None)
sombre_avec = fond.dessiner(500, 300, "dark", logo=_Image.open(RACINE / "assets" / "horizon.png"))
verifier(sombre_avec.size == (500, 300) and sombre_sans.crop((24, 14, 68, 58)).tobytes() != sombre_avec.crop((24, 14, 68, 58)).tobytes(), "fond : l'icône Horizon est dessinée en haut à gauche")
verifier(fond.dessiner(500, 300, "light").tobytes() == fond.dessiner(500, 300, "light", marque="Horizon").tobytes(), "fond : le nom affiché par défaut est Horizon")
sortie_images = Path(_tempfile.mkdtemp())
verifier(construire.generer_images_assistant(sys.executable, RACINE / "assets" / "horizon.png", sortie_images), "installeur : images de l'assistant créées à partir de l'icône")
verifier(_Image.open(sortie_images / "wizard_grand.bmp").size == (164, 314) and _Image.open(sortie_images / "wizard_petit.bmp").size == (55, 55), "installeur : images de l'assistant aux bonnes dimensions (164 x 314 et 55 x 55)")
_shutil.rmtree(sortie_images, ignore_errors=True)
if construire.JOURNAL.exists():
    construire.JOURNAL.unlink()


# ================= D-047 : accès à la boîte partagée quand la liste des boîtes d'Outlook est illisible =================
class ErrCOM(Exception):
    pass


class ColCOM:
    """Collection d'Outlook : Count / Item (par numéro ou par nom) ; erreurs paramétrables comme chez le collègue."""
    def __init__(s, elements, count_err=None, item_err=()):
        s.e, s.count_err, s.item_err = list(elements), count_err, set(item_err)
    @property
    def Count(s):
        if s.count_err: raise ErrCOM(s.count_err)
        return len(s.e)
    def Item(s, i):
        if isinstance(i, str):
            for x in s.e:
                if adresses.nom_de(x) == i: return x
            raise ErrCOM("introuvable : " + i)
        if i in s.item_err: raise ErrCOM(f"OLE error 0x94740111 sur l'élément {i}")
        return s.e[i - 1]
    def __iter__(s):
        if s.count_err: raise ErrCOM(s.count_err)
        return iter(s.e)


class NSFaux:
    def __init__(s, stores=(), racines=(), par_id=None, defaut=None):
        s.Stores, s.Folders, s._par_id, s._defaut = stores, racines, par_id or {}, defaut
    def CreateRecipient(s, n): return types.SimpleNamespace(Resolve=lambda: None, Resolved=True)
    def GetSharedDefaultFolder(s, r, n): raise ErrCOM("Paramètre incorrect.")
    def GetFolderFromID(s, e, st=None):
        if e in s._par_id: return s._par_id[e]
        raise ErrCOM("identifiant de dossier invalide")
    def GetDefaultFolder(s, n): return s._defaut


class OutlookFaux:
    def __init__(s, ns, explorateur=None): s._ns, s._exp = ns, explorateur
    def GetNamespace(s, _): return s._ns
    def ActiveExplorer(s):
        if isinstance(s._exp, Exception): raise s._exp
        return s._exp


class MailSujet:
    def __init__(s, sujet, jours=0, dests=()):
        s.Subject, s.SentOn, s.Recipients = sujet, datetime.datetime(2026, 10, 12, 9, 0, 0) - datetime.timedelta(days=jours), list(dests)


envoyes_pl = Rep("Éléments envoyés", [MailSujet("Métrologie COFRAC / CC1 / CHU A", 1, [Dest("a@x.fr")])])
racine_pl = Rep("racine", enfants=[Rep("BLI envoyés aux déployeurs"), envoyes_pl])
moi_envoyes = Rep("Éléments envoyés", [MailSujet("Autre mail", 2), MailSujet("Métrologie COFRAC / CC2 / CHU B", 3, [Dest("b@x.fr")])])
magasin_moi = Magasin("nicolas.normand@group-mms.com", Rep("racine"))
magasin_pl = Magasin("planning@group-mms.com", racine_pl)
archive_pl = Magasin("Archive en ligne - planning@group-mms.com", Rep("racine", enfants=[Rep("Éléments envoyés", [MailSujet("archive")])]))
BOITE = "planning@group-mms.com"

# liste entière illisible (cas du collègue) : le raccourci échoue, Stores et Folders aussi -> accès direct par le nom
ns_a = NSFaux(ColCOM([], count_err="OLE error 0x94740111"), ColCOM([Rep("planning@group-mms.com", enfants=[envoyes_pl])], count_err="OLE error 0x94740111"), defaut=moi_envoyes)
res_a = adresses.localiser_envoyes(OutlookFaux(ns_a), BOITE)
verifier(res_a[0]["dossier"] is envoyes_pl and "accès direct" in res_a[0]["methode"], "liste des boîtes et des racines illisibles : la boîte est atteinte par son nom")
verifier(any("liste des boîtes" in t and "0x94740111" in t for _, t in res_a[0]["tentatives"]), "le compte rendu garde l'erreur d'Outlook de la liste des boîtes")
verifier(res_a[1]["libelle"] == "Votre boîte" and res_a[1]["dossier"] is moi_envoyes, "la boîte par défaut reste lue")
# une boîte défaillante au milieu de la liste ne bloque plus les suivantes
ns_b = NSFaux(ColCOM([magasin_moi, archive_pl, magasin_pl], item_err={2}), defaut=moi_envoyes)
res_b = adresses.localiser_envoyes(OutlookFaux(ns_b), BOITE)
verifier(res_b[0]["dossier"] is envoyes_pl and res_b[0]["methode"] == "dossier trouvé par son nom", "une boîte illisible est ignorée, planning@ est lue")
# liste des boîtes illisible mais dossiers racines lisibles : nom court
ns_c = NSFaux(ColCOM([], count_err="OLE error 0x94740111"), ColCOM([Rep("nicolas", enfants=[]), Rep("Planning", enfants=[envoyes_pl])]), defaut=moi_envoyes)
res_c = adresses.localiser_envoyes(OutlookFaux(ns_c), BOITE)
verifier(res_c[0]["dossier"] is envoyes_pl, "dossiers racines : la boîte s'affichant « Planning » est reconnue")
# aucun nom approché : l'archive en ligne n'est jamais lue
ns_d = NSFaux(ColCOM([magasin_moi, archive_pl]), ColCOM([]), defaut=moi_envoyes)
res_d = adresses.localiser_envoyes(OutlookFaux(ns_d), BOITE)
verifier(res_d[0]["dossier"] is None and "non ouverte" in res_d[0]["erreur"], "« Archive en ligne - planning@… » n'est pas prise pour la boîte partagée")
verifier("Archive en ligne - planning@group-mms.com" in res_d[0]["vues"], "les boîtes vues par Outlook sont indiquées")
verifier(adresses.noms_candidats(BOITE)[:3] == [BOITE, "planning", "Planning"], "noms admis : adresse, nom court, nom court capitalisé")
# dossier mémorisé : ouvert par son identifiant, sans aucune liste, et essayé en premier
memo = {"entry_id": "E1", "store_id": "S1", "chemin": "\\\\planning\\Éléments envoyés", "nom": "Éléments envoyés"}
ns_e = NSFaux(ColCOM([], count_err="OLE error 0x94740111"), ColCOM([], count_err="OLE error 0x94740111"), par_id={"E1": envoyes_pl}, defaut=moi_envoyes)
res_e = adresses.localiser_envoyes(OutlookFaux(ns_e), BOITE, memo)
verifier(res_e[0]["dossier"] is envoyes_pl and res_e[0]["methode"] == "dossier mémorisé" and res_e[0]["tentatives"] == [("✓", "dossier mémorisé")], "dossier mémorisé : ouvert par son identifiant, rien d'autre n'est essayé")
res_e2 = adresses.localiser_envoyes(OutlookFaux(ns_e), "", memo)
verifier(res_e2[0]["libelle"] == "Dossier mémorisé" and res_e2[0]["cle"] == "memorise" and res_e2[0]["dossier"] is envoyes_pl, "dossier mémorisé sans nom de boîte : utilisé quand même")
mauvais = dict(memo, entry_id="PERIME")
res_e3 = adresses.localiser_envoyes(OutlookFaux(NSFaux(ColCOM([magasin_moi, magasin_pl]), defaut=moi_envoyes)), BOITE, mauvais)
verifier(res_e3[0]["dossier"] is envoyes_pl and res_e3[0]["tentatives"][0][0] == "✗" and "dossier mémorisé" in res_e3[0]["tentatives"][0][1], "identifiant périmé : échec noté, les autres méthodes prennent le relais")
verifier(len(adresses.localiser_envoyes(OutlookFaux(ns_e), "", None)) == 1, "ni boîte ni dossier mémorisé : seule la boîte par défaut")
# compte rendu du test d'accès
lignes = adresses.tester_acces(OutlookFaux(ns_a), BOITE)
verifier(lignes[0].startswith("Boîte partagée") and any(l.strip().startswith("✓ utilisé") and "1 élément" in l for l in lignes), "test d'accès : méthode utilisée, dossier et nombre d'éléments")
lignes_ko = adresses.tester_acces(OutlookFaux(ns_d), BOITE)
verifier(any("✗ inaccessible" in l for l in lignes_ko) and any("boîtes vues par Outlook" in l for l in lignes_ko) and any(l.strip().startswith("✓ utilisé") for l in lignes_ko), "test d'accès : échec détaillé avec les boîtes vues, la boîte par défaut reste utilisable")
# import des adresses avec le dossier mémorisé
base_avant = len(adresses.charger_base()["adresses"])
imp_m = adresses.ImportAdresses(OutlookFaux(NSFaux(ColCOM([], count_err="x"), ColCOM([], count_err="x"), par_id={"E1": envoyes_pl}, defaut=moi_envoyes)), BOITE, complet=True, tranche=0.0, memorise=memo)
imp_m.executer()
verifier(any("dossier mémorisé" in r for r in imp_m.rapport) and "a@x.fr" in adresses.charger_base()["adresses"], "import : la boîte partagée est lue par le dossier mémorisé")
imp_k = adresses.ImportAdresses(OutlookFaux(ns_d), BOITE, complet=True, tranche=0.0)
imp_k.executer()
verifier(any(a.startswith("Astuce") and "Utiliser le dossier sélectionné dans Outlook" in a for a in imp_k.avertissements) and any("boîtes vues" in a for a in imp_k.avertissements), "import : boîte inaccessible -> astuce et boîtes vues dans le compte rendu")
# recherche du mail initial et message d'échec de la relance
sujet_b = "Métrologie COFRAC / CC2 / CHU B"
rap = []
trouve = core.retrouver_mail_envoye(OutlookFaux(NSFaux(ColCOM([magasin_moi]), ColCOM([]), defaut=moi_envoyes)), sujet_b, boite=BOITE, rapport=rap)
verifier(trouve is not None and trouve.Subject == sujet_b and rap and "inaccessible" in rap[0], "relance : planning@ inaccessible, le mail est retrouvé dans la boîte de l'utilisateur")
rap2 = []
verifier(core.retrouver_mail_envoye(OutlookFaux(NSFaux(ColCOM([magasin_moi]), ColCOM([]), defaut=moi_envoyes)), "Objet inexistant", boite=BOITE, rapport=rap2) is None and any("2 mail(s) examiné(s)" in l for l in rap2), "relance : le nombre de mails examinés est indiqué")
try:
    core.creer_relance(OutlookFaux(NSFaux(ColCOM([magasin_moi]), ColCOM([]), defaut=moi_envoyes)), {}, {"objet": "Objet inexistant / CC9 / X", "debut": "01/01/2099", "fin": "01/01/2099"}, boite=BOITE)
    verifier(False, "relance sans mail initial : erreur attendue")
except LookupError as exc:
    texte_exc = str(exc)
    verifier("Objet cherché" in texte_exc and "Objet inexistant / CC9 / X" in texte_exc and "Boîtes consultées" in texte_exc, "relance introuvable : l'objet cherché et les boîtes consultées sont indiqués")
    verifier("inaccessible" in texte_exc and "Utiliser le dossier sélectionné dans Outlook" in texte_exc, "relance introuvable : la marche à suivre est indiquée quand une boîte est inaccessible")
partage.maj_reglages(envoyes_planning=memo)
verifier(core.dossier_memorise() == memo, "réglage : dossier mémorisé relu")
verifier(len(core.dossiers_envoyes(OutlookFaux(ns_e), BOITE)) == 2, "les relances utilisent automatiquement le dossier mémorisé")
partage.maj_reglages(envoyes_planning={"chemin": "sans identifiant"})
verifier(core.dossier_memorise() is None, "réglage incomplet ignoré")
partage.maj_reglages(envoyes_planning=None)
verifier(core.dossier_memorise() is None, "réglage effacé")
# capture du dossier sélectionné dans Outlook
dossier_sel = types.SimpleNamespace(EntryID="E9", StoreID="S9", FolderPath="\\\\planning@group-mms.com\\Éléments envoyés", Name="Éléments envoyés", Items=Coll([1, 2, 3]), DefaultItemType=0)
capt = adresses.capturer_dossier_selectionne(OutlookFaux(None, types.SimpleNamespace(CurrentFolder=dossier_sel)))
verifier(capt["entry_id"] == "E9" and capt["store_id"] == "S9" and capt["nombre"] == 3 and capt["courrier"] is True and capt["chemin"].endswith("Éléments envoyés"), "capture : identifiant, boîte, chemin et nombre d'éléments du dossier sélectionné")
verifier(adresses.capturer_dossier_selectionne(OutlookFaux(None, types.SimpleNamespace(CurrentFolder=types.SimpleNamespace(**dict(vars(dossier_sel), DefaultItemType=1)))))["courrier"] is False, "capture : dossier qui n'est pas du courrier signalé")
for exp, attendu in ((None, "Aucune fenêtre Outlook"), (ErrCOM("boum"), "Outlook ne répond pas")):
    try:
        adresses.capturer_dossier_selectionne(OutlookFaux(None, exp))
        verifier(False, "capture : erreur attendue")
    except ValueError as exc:
        verifier(attendu in str(exc), f"capture : message clair ({attendu})")
# travail en arrière-plan
def attendre_travail(t, delai=10):
    messages, debut = [], _time.monotonic()
    while _time.monotonic() - debut < delai:
        messages += t.lire()
        if messages: return messages
        _time.sleep(0.01)
    return messages
tr = adresses.TravailEnArrierePlan(lambda: OutlookFaux(None, types.SimpleNamespace(CurrentFolder=dossier_sel)), adresses.capturer_dossier_selectionne); tr.demarrer()
verifier(attendre_travail(tr)[0][0] == "fin", "travail en arrière-plan : résultat transmis")
tr2 = adresses.TravailEnArrierePlan(lambda: OutlookFaux(None, None), adresses.capturer_dossier_selectionne); tr2.demarrer()
m_tr2 = attendre_travail(tr2)[0]
verifier(m_tr2[0] == "erreur" and "Aucune fenêtre Outlook" in m_tr2[1], "travail en arrière-plan : erreur d'Outlook rapportée")
tr3 = adresses.TravailEnArrierePlan(lambda: None, adresses.capturer_dossier_selectionne); tr3.demarrer()
verifier(attendre_travail(tr3)[0] == ("erreur", "Outlook n'est pas ouvert."), "travail en arrière-plan : Outlook fermé")


# ================= D-049 à D-055 : mails Non COFRAC, archives, adresse personnelle, techniciens, fichiers, recherche =================
import datetime as _dt2
cfg50 = core.charger_config()
# --- D-053 : liste des techniciens
tech = cfg50["techniciens"]
verifier(len(core.TECHNICIENS_DEFAUT) == 33 and len(tech) == 33, "techniciens : 33 intervenants dans la configuration livrée")
verifier(core.TECHNICIENS_DEFAUT[0] == {"nom": "Ali FAZALDIN", "email": "ali.fazaldin@group-mms.com", "civilite": "M."}, "techniciens : affichage « Prénom NOM »")
noms_t = {t["email"]: t for t in tech}
verifier(noms_t["aurelien.moser@group-mms.com"]["nom"] == "Aurélien MOSER" and noms_t["jean-francois.sulz@group-mms.com"]["nom"] == "Jean-François SULZ" and noms_t["simon-pierre.ndoumbe@group-mms.com"]["nom"] == "Simon-Pierre NDOUMBE", "techniciens : prénoms accentués, prénoms composés")
verifier(noms_t["nicolas.descognier@group-mms.com"]["nom"] == "Nicolas DESCOGNIER" and [t["nom"] for t in tech if t["civilite"] == "Mme"] == ["Marion BASSET"], "techniciens : orthographe de la liste, « Mme » pour Marion seulement")
verifier(len({t["email"].lower() for t in tech}) == 33 and all(t["email"].endswith("@group-mms.com") for t in tech), "techniciens : adresses uniques, domaine group-mms.com")
nv, deja = core.intervenants_depuis_adresses("x.yz@a.fr; X.YZ@A.FR\nmarie-ange.de.la-tour@a.fr  ali.fazaldin@group-mms.com", tech)
verifier([t["email"] for t in nv] == ["x.yz@a.fr", "marie-ange.de.la-tour@a.fr"] and deja == 2, "import d'adresses : séparateurs variés, doublons et adresses présentes ignorés")
verifier(nv[0]["nom"] == "X YZ" and nv[1]["nom"] == "Marie-Ange DE LA-TOUR", "import d'adresses : nom déduit de l'adresse")
# migration : l'intervenant d'exemple est remplacé, de vrais intervenants sont conservés
_cfg_sauve = core.CONFIG.read_text(encoding="utf-8")
try:
    import json as _json
    d = _json.loads(_cfg_sauve); d["techniciens"] = [{"nom": "Intervenant 1", "email": "", "civilite": "M."}]; d["version_config"] = 3
    d["types_nc"]["Métrologie non COFRAC"].pop("modele_comme"); d["types_nc"]["Métrologie non COFRAC"].pop("nom_pj")
    core.CONFIG.write_text(_json.dumps(d, ensure_ascii=False), encoding="utf-8")
    c2 = core.charger_config()
    verifier(len(c2["techniciens"]) == 33 and c2["version_config"] == 5, "migration : l'intervenant d'exemple est remplacé par la liste des techniciens")
    verifier(c2["types_nc"]["Métrologie non COFRAC"]["modele_comme"] == "Métrologie COFRAC" and "non COFRAC" in c2["types_nc"]["Métrologie non COFRAC"]["nom_pj"], "migration : la métrologie non COFRAC reprend la revue technique du COFRAC")
    d["techniciens"] = [{"nom": "Mon Collègue", "email": "mc@x.fr", "civilite": "M."}]
    core.CONFIG.write_text(_json.dumps(d, ensure_ascii=False), encoding="utf-8")
    verifier(core.charger_config()["techniciens"] == [{"nom": "Mon Collègue", "email": "mc@x.fr", "civilite": "M."}], "migration : de vrais intervenants sont conservés")
finally:
    core.CONFIG.write_text(_cfg_sauve, encoding="utf-8")
# --- D-055 : recherche d'intervenant
verifier([t["nom"] for t in core.suggestions_intervenants(tech, "ali")][:1] == ["Ali FAZALDIN"], "recherche d'intervenant : par prénom")
verifier({t["nom"] for t in core.suggestions_intervenants(tech, "AURELIEN moser")} == {"Aurélien MOSER"}, "recherche d'intervenant : sans accents ni casse, plusieurs mots")
verifier([t["nom"] for t in core.suggestions_intervenants(tech, "descogn")] == ["Nicolas DESCOGNIER"] and core.suggestions_intervenants(tech, "nicolas.bou")[0]["nom"] == "Nicolas BOUSSI", "recherche d'intervenant : partie du nom ou de l'adresse")
verifier(len(core.suggestions_intervenants(tech, "")) == 8 and core.suggestions_intervenants(tech, "zzzz") == [] and len(core.suggestions_intervenants(tech, "a", maxi=3)) == 3, "recherche d'intervenant : liste initiale, aucun résultat, limite")
verifier(core.suggestions_intervenants(tech, "fabien")[0]["nom"].startswith("Fabien") and len(core.suggestions_intervenants(tech, "fabien")) == 2, "recherche d'intervenant : deux homonymes de prénom")
iv_nouveau = core.nouvelle_intervention("metro", cfg50)
verifier(iv_nouveau["technicien"] == "" and iv_nouveau["coche"] is True and iv_nouveau["fichiers_sup"] == [], "nouvelle intervention : intervenant à choisir, cochée, sans fichier supplémentaire")
try:
    iv_nouveau.update(client="C", commande="CC1", types=["Métrologie COFRAC"]); core.valider(cfg50, iv_nouveau, "metro")
    verifier(False, "intervenant obligatoire")
except ValueError as exc:
    verifier("Intervenant non sélectionné" in str(exc), "validation : intervenant obligatoire")
# --- D-049 : mail Non COFRAC par défaut, revue technique de la métrologie renommée
class SacMail:
    pass
nc50 = core.nouvelle_intervention("nc", cfg50)
nc50.update(client="CHU TEST", commande="CC77", technicien="Ali FAZALDIN", destinataires="a@b.fr", types=["Métrologie non COFRAC"], debut="14/10/2026", fin="16/10/2026")
core.valider(cfg50, nc50, "nc")
corps_nc = re.sub(r"\s+", " ", re.sub("<[^>]+>", " ", core.construire_corps(cfg50, nc50, "nc")))
verifier("Je vous propose que l’intervention de métrologie non COFRAC ait lieu du 14/10/2026 au 16/10/2026" in corps_nc and "M. Ali FAZALDIN en copie" in corps_nc, "mail Non COFRAC : dates d'intervention et intervenant")
verifier("Merci de nous retourner l’annexe technique à jour." in corps_nc and "prestation annuelle" not in corps_nc and "TEXTE À DÉFINIR" not in corps_nc, "mail Non COFRAC : phrase de la revue technique pour la métrologie, aucun texte provisoire")
pj_nc = core.preparer_pieces_jointes(cfg50, nc50, "nc")
verifier(len(pj_nc) == 1 and pj_nc[0].name == f"Revue technique non COFRAC_CHU TEST_{_dt2.datetime.now().year}.xlsx", "Non COFRAC : la revue technique du COFRAC est jointe, renommée « non COFRAC »")
verifier(core.modele_du_type(cfg50, "nc", "Métrologie non COFRAC") == core.modele_du_type(cfg50, "metro", "Métrologie COFRAC") and core.modele_du_type(cfg50, "nc", "HVAC") == "", "Non COFRAC : même fichier que le COFRAC (non dupliqué), aucun fichier pour les autres types")
nc50b = dict(nc50, types=["HVAC", "Qualification"])
corps_b = re.sub(r"\s+", " ", re.sub("<[^>]+>", " ", core.construire_corps(cfg50, nc50b, "nc")))
verifier("annexe technique" not in corps_b and "<b>HVAC</b>" not in core.construire_corps(cfg50, nc50b, "nc") and core.preparer_pieces_jointes(cfg50, nc50b, "nc") == [], "mail Non COFRAC sans métrologie : ni phrase ni titre vide ni pièce jointe")
nc50c = dict(nc50, types=["Métrologie non COFRAC", "HVAC"])
verifier(core.construire_corps(cfg50, nc50c, "nc").count("<b>Métrologie non COFRAC</b>") == 1 and "<b>HVAC</b>" not in core.construire_corps(cfg50, nc50c, "nc"), "mail Non COFRAC multi-types : titre seulement pour le type qui a du texte")
# --- D-052 : Non COFRAC depuis l'adresse personnelle
class MailFaux:
    def __init__(s): s.Attachments = types.SimpleNamespace(l=[], Add=lambda c: s.Attachments.l.append(c)); s.HTMLBody = "<html><body></body></html>"; s.GetInspector = None; s.Display = lambda *a: None
class OutlookCreation:
    def __init__(s): s.mails = []
    def CreateItem(s, _): m = MailFaux(); s.mails.append(m); return m
oc = OutlookCreation()
core.creer_brouillon(oc, cfg50, nc50, "nc")
verifier(not hasattr(oc.mails[-1], "SentOnBehalfOfName"), "Non COFRAC : brouillon créé dans la boîte de la personne, sans « de la part de »")
metro50 = core.nouvelle_intervention("metro", cfg50); metro50.update(client="C", commande="CC1", technicien="Ali FAZALDIN", destinataires="a@b.fr", types=["Métrologie COFRAC"])
core.creer_brouillon(oc, cfg50, metro50, "metro")
verifier(oc.mails[-1].SentOnBehalfOfName == cfg50["expediteur"], "COFRAC : brouillon toujours au nom de la boîte du planning")
# relance Non COFRAC : boîte personnelle uniquement, réponse sans « de la part de »
class Envoi:
    def __init__(s, sujet): s.Subject, s.SentOn, s.To, s.CC, s.HTMLBody, s.EntryID = sujet, _dt2.datetime(2026, 10, 14, 9), "a@b.fr", "", "<html><body></body></html>", "ID1"; s.reponse = None
    def ReplyAll(s): s.reponse = types.SimpleNamespace(HTMLBody="<html><body></body></html>", Display=lambda *a: None, To="", CC=""); return s.reponse
class RepEnvoi:
    def __init__(s, items): s.Items = ItemsFaux(items)
class ItemsFaux(list):
    Count = property(lambda s: len(s))
    def Sort(s, *a): pass
perso_item = Envoi("Qualification / CC88 / CHU PERSO")
class NSPerso:
    Stores, Folders = [], []
    def GetDefaultFolder(s, n): return RepEnvoi([perso_item])
    def CreateRecipient(s, n): raise ErrCOM("ne doit pas être utilisé pour une carte Non COFRAC")
    def GetItemFromID(s, i): raise ErrCOM("inconnu")
class OutlookPerso:
    def GetNamespace(s, _): return NSPerso()
carte_nc = {"onglet": "nc", "objet": "Qualification / CC88 / CHU PERSO", "debut": "20/10/2026", "fin": "21/10/2026", "iv": {"destinataires": "a@b.fr", "technicien": "Ali FAZALDIN", "cc_tech": True}}
core.creer_relance(OutlookPerso(), cfg50, carte_nc, boite="planning@group-mms.com")
verifier(perso_item.reponse is not None and not hasattr(perso_item.reponse, "SentOnBehalfOfName"), "relance Non COFRAC : boîte personnelle consultée, réponse sans « de la part de » (planning@ ignoré)")
carte_nc_absente = dict(carte_nc, objet="Objet qui n'existe pas")
try:
    core.creer_relance(OutlookPerso(), cfg50, carte_nc_absente, boite="planning@group-mms.com")
    verifier(False, "relance Non COFRAC introuvable")
except LookupError as exc:
    verifier("adresse personnelle" in str(exc) and "En charge" in str(exc), "relance Non COFRAC par un autre collègue : message explicite")
carte_nc_lien = dict(carte_nc)
verifier(core.lier_mail_envoye(OutlookPerso(), carte_nc_lien, boite="planning@group-mms.com") is True and carte_nc_lien["entry_id"] == "ID1", "Non COFRAC : « Placer dans suivi » retrouve le mail dans la boîte personnelle")
# --- D-054 : fichiers supplémentaires de tout format
dossier_sup = Path(_tempfile.mkdtemp())
f_pdf, f_doc = dossier_sup / "Plan d'accès.pdf", dossier_sup / "Note.docx"
f_pdf.write_bytes(b"%PDF"); f_doc.write_bytes(b"PK")
sup50 = dict(metro50, fichiers_sup=[str(f_pdf), str(f_doc)])
pj_sup = core.preparer_pieces_jointes(cfg50, sup50, "metro")
verifier([p.name for p in pj_sup][-2:] == ["Plan d'accès.pdf", "Note.docx"] and len(pj_sup) == 3, "fichiers supplémentaires : joints après la revue technique, noms d'origine conservés")
verifier(core.preparer_pieces_jointes(cfg50, dict(nc50b, fichiers_sup=[str(f_pdf)]), "nc") == [f_pdf], "fichiers supplémentaires : possibles aussi pour les types Non COFRAC sans modèle")
jri50 = core.nouvelle_intervention("jri", cfg50); jri50.update(client="C", commande="CC2", technicien="Ali FAZALDIN", gateway=True, fichiers_sup=[str(f_doc)])
verifier(core.preparer_pieces_jointes(cfg50, jri50, "jri")[-1] == f_doc, "fichiers supplémentaires : possibles dans l'onglet JRI, après les prérequis")
f_doc.unlink()
try:
    core.preparer_pieces_jointes(cfg50, sup50, "metro")
    verifier(False, "fichier supplémentaire disparu")
except FileNotFoundError as exc:
    verifier("Note.docx" in str(exc), "fichier supplémentaire disparu : erreur claire")
suivi_copie, e_sup = core.ajouter_suivi(dict(sup50, id="idsup", debut="01/10/2026", fin="02/10/2026"), "metro", "t", "o")
verifier(e_sup["iv"]["fichiers_sup"] == [] and sup50["fichiers_sup"] != [], "suivi : aucun chemin de fichier dans la copie partagée")
_shutil.rmtree(dossier_sup, ignore_errors=True)
# --- D-051 : archives
verifier(core.ajouter_mois(_dt2.date(2026, 1, 31), 1) == _dt2.date(2026, 2, 28) and core.ajouter_mois(_dt2.date(2026, 12, 14), 1) == _dt2.date(2027, 1, 14) and core.ajouter_mois(_dt2.date(2028, 1, 31), 1) == _dt2.date(2028, 2, 29), "mois suivant : fin de mois, changement d'année, année bissextile")
carte_v = {"etat": "Validée", "fin": "14/10/2026"}
verifier(not core.est_archivee(carte_v, _dt2.date(2026, 11, 13)) and core.est_archivee(carte_v, _dt2.date(2026, 11, 14)) and core.est_archivee(carte_v, _dt2.date(2027, 3, 1)), "archives : un mois jour pour jour après la date de fin")
verifier(not core.est_archivee({"etat": "Planifié", "fin": "01/01/2020"}, _dt2.date(2026, 11, 14)) and not core.est_archivee({"etat": "Date validée", "fin": "01/01/2020"}), "archives : seules les cartes Validée sont archivées")
verifier(not core.est_archivee(dict(carte_v, archive_levee=True), _dt2.date(2027, 1, 1)) and not core.est_archivee({"etat": "Validée", "fin": "n'importe quoi"}) and not core.est_archivee({"etat": "Validée"}), "archives : carte remise dans le suivi, date illisible ou absente : jamais archivée")
arch = core.trier_archives([{"fin": "01/03/2026"}, {"fin": "15/09/2026"}, {"fin": "illisible"}])
verifier([a["fin"] for a in arch] == ["15/09/2026", "01/03/2026", "illisible"], "archives : les plus récentes d'abord")
# nettoyage : les essais de pièces jointes copient des revues techniques dans « envois »
_shutil.rmtree(core.BASE / "envois", ignore_errors=True)


# ================= D-057 : langue du mail (FR / EN) =================
cfg57 = core.charger_config()
verifier(core.fmt_date("14/10/2026", "EN") == "14 October 2026" and core.fmt_date("01/03/2027", "EN") == "1 March 2027" and core.fmt_date("14/10/2026", "FR") == "14/10/2026" and core.fmt_date("n'importe quoi", "EN") == "n'importe quoi", "dates : écrites en anglais, inchangées en français")
verifier(core.fmt_heure("14:00", "EN") == "14:00" and core.fmt_heure("14:00") == "14h00" and core.fmt_heure("09:30", "FR") == "09h30", "heures : 24 h en anglais, « 14h00 » en français")
verifier(core._periode("14/10/2026", "14/10/2026", "EN") == "on 14 October 2026" and core._periode("14/10/2026", "16/10/2026", "EN") == "from 14 October 2026 to 16 October 2026" and core._periode("14/10/2026", "16/10/2026") == "du 14/10/2026 au 16/10/2026", "période : anglais « on / from … to … », français inchangé")
verifier(core.nouvelle_intervention("metro", cfg57)["langue"] == "FR" and core.normaliser_iv("metro", {"langue": "DE"})["langue"] == "FR" and core.normaliser_iv("jri", {})["langue"] == "FR", "langue : français par défaut, valeur inconnue ramenée au français")
def iv_langue(kind, **kw):
    iv = core.nouvelle_intervention(kind, cfg57)
    iv.update(client="CHU TEST", commande="CC1", technicien="Marion BASSET", destinataires="a@b.fr", debut="14/10/2026", fin="16/10/2026"); iv.update(kw)
    return iv
def texte(html): return re.sub(r"\s+([,.;:?!])", r"\1", re.sub(r"\s+", " ", re.sub("<[^>]+>", " ", html))).strip()
m_fr, m_en = iv_langue("metro", types=["Métrologie COFRAC", "Caractérisation COFRAC"]), iv_langue("metro", types=["Métrologie COFRAC", "Caractérisation COFRAC"], langue="EN")
verifier(core.construire_objet(cfg57, m_fr, "metro") == "Métrologie COFRAC + Caractérisation COFRAC / CC1 / CHU TEST", "objet français inchangé")
verifier(core.construire_objet(cfg57, m_en, "metro") == "COFRAC Metrology + COFRAC Characterisation / CC1 / CHU TEST", "objet anglais : types traduits")
corps_en = texte(core.construire_corps(cfg57, m_en, "metro"))
verifier("Hello," in corps_en and "As part of the annual on-site COFRAC metrology and COFRAC characterisation service" in corps_en and "from 14 October 2026 to 16 October 2026" in corps_en, "mail COFRAC anglais : introduction, prestations et dates")
verifier("The technician will be Ms Marion BASSET, in copy of this email." in corps_en and "Could you please confirm the address of the intervention?" in corps_en, "mail COFRAC anglais : intervenant (« Ms » pour « Mme ») et question sur l'adresse")
verifier("Please return the updated technical appendix." in corps_en and "Please return the updated technical review." in corps_en and "Thank you in advance, Kind regards." in corps_en, "mail COFRAC anglais : blocs métrologie et caractérisation, formules de politesse")
verifier(not re.search(r"Bonjour|Merci|Cordialement|intervenant sera|annexe technique|prestation annuelle", corps_en), "mail anglais : aucun mot français")
verifier("COFRAC Metrology" in core.construire_corps(cfg57, m_en, "metro") and "Métrologie COFRAC" not in core.construire_corps(cfg57, m_en, "metro"), "mail anglais multi-types : titres des blocs en anglais")
corps_fr = texte(core.construire_corps(cfg57, m_fr, "metro"))
verifier("Bonjour," in corps_fr and "du 14/10/2026 au 16/10/2026" in corps_fr and "Mme Marion BASSET" in corps_fr, "mail français inchangé")
nc_en = iv_langue("nc", types=["Qualification", "HVAC"], langue="EN")
verifier(core.construire_objet(cfg57, nc_en, "nc") == "Qualification + HVAC / CC1 / CHU TEST" and "the qualification and HVAC intervention takes place from 14 October 2026 to 16 October 2026" in texte(core.construire_corps(cfg57, nc_en, "nc")), "mail Non COFRAC anglais")
nc_met = iv_langue("nc", types=["Métrologie non COFRAC"], langue="EN")
verifier(core.construire_objet(cfg57, nc_met, "nc").startswith("Non-COFRAC Metrology /") and "Please return the updated technical appendix." in texte(core.construire_corps(cfg57, nc_met, "nc")), "mail métrologie non COFRAC anglais : objet et phrase de la revue technique")
j_en = iv_langue("jri", langue="EN", link=True, link_mode="WIFI", gateway=True, mysirius_serveur=True, hebergement="Serveur", gateway_mode="ETH",
                 teams=True, teams_date="20/10/2026", teams_heure="14:00", visite=True, visite_date="21/10/2026", visite_heure="09:30", visite_avec="",
                 deploiement=True, deploiement_debut="22/10/2026", deploiement_fin="23/10/2026", formation=True, formation_date="24/10/2026")
corps_j = texte(core.construire_corps(cfg57, j_en, "jri"))
verifier("1) A Teams call (or other) of 1 hour maximum:" in corps_j and "On 20 October 2026 I am available from 14:00 to 15:00" in corps_j, "JRI anglais : réunion Teams, date écrite et heures sur 24 h")
verifier("2) A pre-installation visit on 21 October 2026 at 09:30 with:" in corps_j and "Ms Marion BASSET" in corps_j, "JRI anglais : visite de pré-installation, participant par défaut avec « Ms »")
verifier("3) A deployment from 22 October 2026 to 23 October 2026" in corps_j and "preferably on 24 October 2026" in corps_j, "JRI anglais : déploiement et formation")
verifier("Source port" in core.construire_corps(cfg57, j_en, "jri") and "Link Nano Wifi" in corps_j and "MySirius Server" in corps_j and "Gateway Lora" in corps_j, "JRI anglais : tableau des flux et libellés des prérequis")
verifier(core.construire_objet(cfg57, j_en, "jri") == "INSTALLATION MYSIRIUS SERVEUR / CC1 / CHU TEST", "objet JRI : inchangé en anglais")
verifier(not re.search(r"Bonjour|Merci|Cordialement|Restant|disponible|Un point|Une visite|déploiement|prérequis", corps_j), "mail JRI anglais : aucun mot français")
j_fr = iv_langue("jri", link=True, link_mode="WIFI", hebergement="Serveur", teams=True, teams_date="20/10/2026", teams_heure="14:00")
verifier("je suis disponible de 14h00 à 15h00" in texte(core.construire_corps(cfg57, j_fr, "jri")), "mail JRI français inchangé (« 14h00 à 15h00 »)")
verifier(sorted(p.name for p in (RACINE / "templates").glob("*.html")) == sorted(p.name for p in (RACINE / "templates" / "en").glob("*")), "modèles : chaque modèle français a son équivalent anglais")
verifier(sum(1 for n in noms if n.startswith("templates/en/")) == 18, "installeur : les 18 modèles anglais sont embarqués avec l'application")
verifier(all(d.get("libelle_en") and d.get("prestation_en") for g in ("types", "types_nc") for d in cfg57[g].values()), "configuration : libellé et prestation anglais pour chaque type")
verifier(core.lignes_carte({"onglet": "metro", "iv": {"client": "X", "commande": "C1", "types": ["Métrologie COFRAC"], "langue": "EN"}}) == ("X", "C1 · Métrologie · EN"), "carte du suivi : repère « EN »")
verifier(core.lignes_carte({"onglet": "metro", "iv": {"client": "X", "commande": "C1", "types": ["Métrologie COFRAC"]}}) == ("X", "C1 · Métrologie"), "carte du suivi : aucun repère en français")
os.environ["PLANIF_TEST_EN"] = "1"
pj_en = core.preparer_pieces_jointes(cfg57, m_en, "metro")
verifier(all(p.name.startswith("Revue technique COFRAC_") for p in pj_en), "pièces jointes : fichiers français même en anglais")
# migration : une configuration d'avant 1.5.0 reçoit les traductions
_cfg57 = core.CONFIG.read_text(encoding="utf-8")
try:
    import json as _json57
    d57 = _json57.loads(_cfg57); d57["version_config"] = 4
    for g in ("types", "types_nc"):
        for t in d57[g].values(): t.pop("libelle_en", None); t.pop("prestation_en", None)
    core.CONFIG.write_text(_json57.dumps(d57, ensure_ascii=False), encoding="utf-8")
    c57 = core.charger_config()
    verifier(c57["version_config"] == 5 and c57["types"]["Métrologie COFRAC"]["libelle_en"] == "COFRAC Metrology" and c57["types_nc"]["HVAC"]["prestation_en"] == "HVAC", "migration : traductions des types ajoutées")
finally:
    core.CONFIG.write_text(_cfg57, encoding="utf-8")
# --- relance en anglais et relance de secours (D-048)
class MailRelance:
    def __init__(s): s.HTMLBody = "<html><body></body></html>"; s.GetInspector = None; s.shown = False; s.Display = lambda *a: setattr(s, "shown", True)
class OutlookSecours:
    def __init__(s): s.mails = []
    def CreateItem(s, _): m = MailRelance(); s.mails.append(m); return m
os57 = OutlookSecours()
carte_s = {"onglet": "metro", "objet": "COFRAC Metrology / CC1 / CHU TEST", "debut": "20/10/2026", "fin": "21/10/2026",
           "iv": {"destinataires": "client@x.fr; autre@x.fr", "technicien": "Ali FAZALDIN", "cc_tech": True, "langue": "EN"}}
core.creer_relance_secours(os57, cfg57, carte_s)
ms = os57.mails[-1]
verifier(ms.Subject == "RE: COFRAC Metrology / CC1 / CHU TEST" and ms.To == "client@x.fr; autre@x.fr" and ms.CC == "ali.fazaldin@group-mms.com" and ms.shown, "relance de secours : objet « RE: », destinataires, copie de l'intervenant, message affiché")
verifier("Having not heard back from you to date" in ms.HTMLBody and "on 20 October" not in ms.HTMLBody and "from 20 October 2026 to 21 October 2026" in ms.HTMLBody, "relance de secours en anglais : texte et dates anglaises")
verifier(ms.SentOnBehalfOfName == cfg57["expediteur"], "relance de secours COFRAC : au nom de la boîte du planning")
core.creer_relance_secours(os57, cfg57, dict(carte_s, onglet="nc", iv=dict(carte_s["iv"], langue="FR")))
verifier(os57.mails[-1].Subject == "RE : COFRAC Metrology / CC1 / CHU TEST" and "Sans retour de votre part" in os57.mails[-1].HTMLBody and not hasattr(os57.mails[-1], "SentOnBehalfOfName"), "relance de secours Non COFRAC en français : « RE : », sans « de la part de »")
try:
    core.creer_relance_secours(os57, cfg57, dict(carte_s, iv={"destinataires": "", "technicien": "Ali FAZALDIN"}))
    verifier(False, "relance de secours sans destinataire")
except ValueError as exc:
    verifier("Aucun destinataire" in str(exc), "relance de secours sans destinataire : message clair")
# --- D-044 : mode sécurisé, sortie et retour automatique
partage.maj_reglages(mode_securise=False, securise_auto=False, fermetures_propres=0, securise_leve_auto=False)
partage.declencher_mode_securise_auto()
r44 = partage.reglages(); verifier(r44["mode_securise"] and r44["securise_auto"] and r44["fermetures_propres"] == 0, "mode sécurisé automatique : enregistré, compteur à zéro")
partage.fin_session(); partage.fin_session()
verifier(partage.reglages()["mode_securise"] and partage.reglages()["fermetures_propres"] == 2, "mode sécurisé automatique : encore actif après 2 fermetures normales")
partage.fin_session()
r44 = partage.reglages(); verifier(not r44["mode_securise"] and not r44["securise_auto"] and r44["fermetures_propres"] == 0 and r44["securise_leve_auto"] is True, "mode sécurisé automatique : levé après 3 fermetures normales de suite")
partage.maj_reglages(securise_leve_auto=False)
partage.declencher_mode_securise_auto(); partage.fin_session(); partage.declencher_mode_securise_auto()
verifier(partage.reglages()["fermetures_propres"] == 0, "un nouvel arrêt anormal remet le compteur à zéro (3 fermetures « de suite »)")
partage.quitter_mode_securise()
verifier(not partage.reglages()["mode_securise"] and not partage.reglages()["securise_auto"], "sortie demandée par l'utilisateur : mode sécurisé levé")
partage.maj_reglages(mode_securise=True, securise_auto=False, fermetures_propres=0)
for _ in range(6): partage.fin_session()
verifier(partage.reglages()["mode_securise"] is True, "mode sécurisé coché par l'utilisateur : reste actif jusqu'à ce qu'il le décoche")
partage.maj_reglages(mode_securise=False, securise_auto=False, fermetures_propres=0, securise_leve_auto=False)
partage.fin_session()
verifier(partage.reglages()["mode_securise"] is False and partage.reglages()["arret_propre"] is True, "fermeture normale sans mode sécurisé : rien ne change")
# --- D-056 : barre des tâches, raccourcis de l'installeur
iss56 = (RACINE / "installeur" / "Horizon.iss").read_text(encoding="utf-8-sig")
verifier(iss56.count('AppUserModelID: "JRI.Horizon"') == 3, "installeur : identifiant d'application sur les trois raccourcis (une seule icône dans la barre des tâches)")
src56 = (RACINE / "app.py").read_text(encoding="utf-8")
verifier('ID_APPLICATION = "JRI.Horizon"' in src56 and "SetCurrentProcessExplicitAppUserModelID(ID_APPLICATION)" in src56 and "PKEY_AppUserModel_RelaunchCommand" in src56 and "RelaunchIconResource" in src56 and "RelaunchDisplayNameResource" in src56, "application : même identifiant que les raccourcis, propriétés de relance (commande, icône, nom)")

print(f"\n{len(OK)} contrôles réussis.")
