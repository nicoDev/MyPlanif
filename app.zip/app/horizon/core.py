"""Logique métier de Horizon, anciennement PlanifIntervention (sans interface graphique)."""
import calendar
import json
import re
import shutil
import sys
import unicodedata
import uuid
from collections import Counter
from copy import deepcopy
from datetime import date, datetime, timedelta
from html import escape
from pathlib import Path

import adresses
import partage
from partage import ListeSuivi  # noqa: F401  (réexporté pour l'interface)

VERSION = "1.5.0"
BASE = Path(sys.executable).parent if getattr(sys, "frozen", False) else Path(__file__).parent
CONFIG = BASE / "config.json"
JOURNAL = BASE / "historique.json"
CARNET = BASE / "destinataires.json"
SUIVI = BASE / "suivi.json"
CAMPAGNES = {"metro": BASE / "campagne.json", "nc": BASE / "campagne_nc.json", "jri": BASE / "campagne_jri.json"}
KINDS_TYPES = ("metro", "nc")  # onglets à types d'intervention (COFRAC, Non COFRAC) ; JRI a ses propres options
DATE_FMT = "%d/%m/%Y"
ICONES = {"À faire": "○", "Brouillon": "✔", "Erreur": "✖"}
DELAI_RELANCE = 7  # jours
SECTIONS_JRI = ("teams", "visite", "deploiement", "formation")
ETATS = ["Planifié", "Date validée", "Validée"]
ORIGINES = {"metro": "COFRAC", "nc": "Non COFRAC", "jri": "JRI"}

PREREQUIS_DEFAUT = {
    "Link": {
        "Cloud": {"POE": "PREREQUIS_LINK_NANO_ETHERNET_MYSIRIUS_CLOUD_POE_-_20251229.doc",
                  "VDC": "PREREQUIS_LINK_NANO_ETHERNET_MYSIRIUS_CLOUD_VDC_-_20251229.doc",
                  "WIFI": "PREREQUIS_LINK_NANO_WIFI_MYSIRIUS_CLOUD_-20251229.doc"},
        "Serveur": {"POE": "PREREQUIS_LINK_NANO_ETHERNET_MYSIRIUS_SERVEUR_POE_-20251229.doc",
                    "VDC": "PREREQUIS_LINK_NANO_ETHERNET_MYSIRIUS_SERVEUR_-_20251229.doc",
                    "WIFI": "PREREQUIS_LINK_NANO_WIFI_MYSIRIUS_SERVEUR_-20251229.doc"},
    },
    "Gateway": {
        "Cloud": {"ETH": "PREREQUIS_GATEWAY_PRIVEE_LORA_ETHERNET_MYSIRIUS_CLOUD_-20251229.doc",
                  "4G + ETH": "PREREQUIS_GATEWAY_PRIVEE_LORA_ETHERNET-4G_MYSIRIUS_CLOUD_20251229.doc"},
        "Serveur": {"ETH": "PREREQUIS_GATEWAY_PRIVEE_LORA_ETHERNET_MYSIRIUS_SERVEUR_13252_-2021229.doc"},
    },
    "MySirius Serveur": "PREREQUIS_MYSIRIUS_SERVEUR_MONO_SERVEUR_-F.doc",
}

# Onglet Non COFRAC (D-049) : mail par défaut (dates + intervenant) ; la métrologie non COFRAC joint la revue technique du COFRAC
# renommée « non COFRAC » (`modele_comme` : même fichier que le type COFRAC indiqué, jamais dupliqué)
TYPES_NC_DEFAUT = {
    "Métrologie non COFRAC": {"template": "nc_metrologie.html", "modele_comme": "Métrologie COFRAC",
                              "nom_pj": "Revue technique non COFRAC_{client}_{annee}",
                              "prestation": "de métrologie non COFRAC", "pied": "pied.html"},
    "Caractérisation non COFRAC": {"template": "nc_caracterisation.html", "prestation": "de caractérisation non COFRAC", "pied": "pied.html"},
    "Qualification": {"template": "nc_qualification.html", "prestation": "de qualification", "pied": "pied.html"},
    "HVAC": {"template": "nc_hvac.html", "prestation": "HVAC", "pied": "pied.html"},
}

# Techniciens (D-053) : liste fournie par adresse ; nom = « Prénom NOM », accents rendus aux prénoms usuels
PRENOMS_ACCENTUES = {"aurelien": "Aurélien", "eric": "Éric", "herve": "Hervé", "joel": "Joël", "remi": "Rémi", "jeremy": "Jérémy",
                     "jean-francois": "Jean-François", "stephane": "Stéphane", "frederic": "Frédéric", "cedric": "Cédric",
                     "remy": "Rémy", "gerard": "Gérard", "jerome": "Jérôme", "andre": "André", "rene": "René", "noel": "Noël",
                     "clement": "Clément", "emilie": "Émilie", "amelie": "Amélie", "helene": "Hélène", "celine": "Céline",
                     "benedicte": "Bénédicte", "mederic": "Médéric", "theo": "Théo", "loic": "Loïc", "gael": "Gaël"}
PRENOMS_FEMININS = {"marion"}  # rendus « Mme » à l'import ; la civilité se corrige dans Paramètres › Intervenants
TECHNICIENS_ADRESSES = """ali.fazaldin@group-mms.com aurelien.moser@group-mms.com benjamin.schoucair@group-mms.com
christophe.brissot@group-mms.com eric.guillemier@group-mms.com fabien.mestre@group-mms.com fabrice.leyaouanc@group-mms.com
franck.gallifet@group-mms.com herve.stelmach@group-mms.com jean-francois.sulz@group-mms.com joel.maillard@group-mms.com
mathieu.gomes@group-mms.com mbark.iaich@group-mms.com nicolas.boussi@group-mms.com othmane.tazi@group-mms.com
remi.puget@group-mms.com tony.roumier@group-mms.com abdoul.thiaw@group-mms.com alexandre.nondedeo@group-mms.com
anthony.galard@group-mms.com dorian.bizouard@group-mms.com fabien.delaunay@group-mms.com florian.millard@group-mms.com
issam.mebitil@group-mms.com jeremy.bolou@group-mms.com kevin.fourcade@group-mms.com marion.basset@group-mms.com
nicolas.descognier@group-mms.com pierre.calvosa@group-mms.com redzy.leveille@group-mms.com simon-pierre.ndoumbe@group-mms.com
serge.nkemi@group-mms.com dimitri.bue@group-mms.com""".split()

LINK_SERVEUR_V12 = {"POE": "PREREQUIS_LINK_NANO_ETHERNET_MYSIRIUS_SERVEUR_-_20251229.doc",
                    "VDC": "PREREQUIS_LINK_NANO_ETHERNET_MYSIRIUS_SERVEUR_POE_-20251229.doc"}
LIBELLES_MAIL = {"Link": "Link Nano Ethernet", "Gateway": "Gateway Lora", "MySirius Serveur": "MySirius Serveur"}

# Langue du mail (D-057) : français par défaut, anglais au choix, intervention par intervention. L'application reste en français ;
# les pièces jointes (revues techniques, prérequis) restent en français.
LANGUES = ("FR", "EN")
MOIS_EN = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
CIVILITES_EN = {"M.": "Mr", "Mme": "Ms"}
LIBELLES_MAIL_EN = {"Link": "Link Nano Ethernet", "Gateway": "Gateway Lora", "MySirius Serveur": "MySirius Server"}
TRADUCTIONS_TYPES = {  # libellé (objet du mail) et prestation (corps) en anglais, par type d'intervention
    "Métrologie COFRAC": ("COFRAC Metrology", "COFRAC metrology"),
    "Caractérisation COFRAC": ("COFRAC Characterisation", "COFRAC characterisation"),
    "Métrologie non COFRAC": ("Non-COFRAC Metrology", "non-COFRAC metrology"),
    "Caractérisation non COFRAC": ("Non-COFRAC Characterisation", "non-COFRAC characterisation"),
    "Qualification": ("Qualification", "qualification"),
    "HVAC": ("HVAC", "HVAC"),
}


# ---------- réglages du poste (expéditeur, boîte du mail initial) ----------
def expediteur_effectif(cfg):
    """Expéditeur « de la part de » : réglage du poste s'il existe, sinon config.json."""
    return (partage.reglages().get("expediteur") or "").strip() or cfg.get("expediteur", "")


def boite_mail_initial(cfg):
    """Boîte où chercher le mail initial d'une relance (par défaut : celle de l'expéditeur, ex. planning@)."""
    boite = partage.reglages().get("boite_relance")
    return (cfg.get("expediteur", "") if boite is None else boite).strip()


# ---------- fichiers JSON, configuration ----------
def charger_json(chemin, defaut):
    chemin = Path(chemin)
    return json.loads(chemin.read_text(encoding="utf-8")) if chemin.exists() else defaut


def ecrire_json(chemin, data):
    Path(chemin).write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")


# ---------- techniciens : import d'une liste d'adresses (D-053) ----------
def _sans_accents_nom(texte):
    return "".join(c for c in unicodedata.normalize("NFD", texte) if not unicodedata.combining(c))


def nom_depuis_adresse(adresse):
    """« jean-francois.sulz@group-mms.com » -> « Jean-François SULZ » (prénom accentué s'il est usuel, nom en capitales)."""
    parties = [p for p in re.split(r"[._]", adresse.strip().split("@")[0]) if p]
    if len(parties) < 2:
        return (parties[0] if parties else adresse).capitalize()
    prenom = PRENOMS_ACCENTUES.get(_sans_accents_nom(parties[0]).lower()) or "-".join(p.capitalize() for p in parties[0].split("-"))
    return f"{prenom} {' '.join(parties[1:]).upper()}"


def civilite_depuis_adresse(adresse):
    return "Mme" if _sans_accents_nom(re.split(r"[._]", adresse.strip())[0]).lower() in PRENOMS_FEMININS else "M."


def intervenants_depuis_adresses(texte, existants=()):
    """(nouveaux, deja_presents) : intervenants créés d'après des adresses e-mail séparées par des espaces, retours à la ligne,
    « ; » ou « , ». Une adresse déjà présente (comparaison sans casse) n'est pas dupliquée."""
    connus = {(t.get("email") or "").strip().lower() for t in existants}
    nouveaux, deja = [], 0
    for adresse in re.findall(r"[\w.+'-]+@[\w.-]+\.\w+", texte or ""):
        cle = adresse.lower()
        if cle in connus:
            deja += 1
            continue
        connus.add(cle)
        nouveaux.append({"nom": nom_depuis_adresse(adresse), "email": adresse, "civilite": civilite_depuis_adresse(adresse)})
    return nouveaux, deja


TECHNICIENS_DEFAUT = intervenants_depuis_adresses(" ".join(TECHNICIENS_ADRESSES))[0]


def _intervenant_exemple(techniciens):
    """True pour la liste d'origine : le seul intervenant d'exemple « Intervenant 1 », sans e-mail."""
    return len(techniciens) == 1 and techniciens[0].get("nom") == "Intervenant 1" and not (techniciens[0].get("email") or "").strip()


def charger_config():
    cfg = charger_json(CONFIG, {})
    modifie = False
    if "prerequis" not in cfg:
        cfg["prerequis"] = deepcopy(PREREQUIS_DEFAUT)
        modifie = True
    if "techniciens" not in cfg or _intervenant_exemple(cfg["techniciens"]):  # D-053 : liste des techniciens
        cfg["techniciens"] = deepcopy(TECHNICIENS_DEFAUT)
        modifie = True
    if cfg.get("version_config", 1) < 2:  # v1.3 : correction de l'inversion Link Serveur POE / VDC
        if cfg["prerequis"].get("Link", {}).get("Serveur") == LINK_SERVEUR_V12:
            cfg["prerequis"]["Link"]["Serveur"] = deepcopy(PREREQUIS_DEFAUT["Link"]["Serveur"])
        cfg["version_config"] = 2
        modifie = True
    if "types_nc" not in cfg:  # v1.5 : onglet Non COFRAC
        cfg["types_nc"] = deepcopy(TYPES_NC_DEFAUT)
        modifie = True
    for h, nom in (("Cloud", PREREQUIS_DEFAUT["Link"]["Cloud"]["WIFI"]),
                   ("Serveur", PREREQUIS_DEFAUT["Link"]["Serveur"]["WIFI"])):  # v1.5 : Link WIFI
        modes = cfg["prerequis"].setdefault("Link", {}).setdefault(h, {})
        if "WIFI" not in modes:
            modes["WIFI"] = nom
            modifie = True
    if cfg.get("version_config", 1) < 3:
        cfg["version_config"] = 3
        modifie = True
    if cfg.get("version_config", 1) < 4:  # v1.5.0-beta.11 : la métrologie non COFRAC reprend la revue technique du COFRAC
        d = cfg.get("types_nc", {}).get("Métrologie non COFRAC")
        if d is not None:
            d.setdefault("modele_comme", "Métrologie COFRAC")
            d.setdefault("nom_pj", "Revue technique non COFRAC_{client}_{annee}")
        cfg["version_config"] = 4
        modifie = True
    if cfg.get("version_config", 1) < 5:  # 1.5.0 : langue du mail (libellé et prestation en anglais de chaque type)
        for groupe in ("types", "types_nc"):
            for nom, d in cfg.get(groupe, {}).items():
                libelle, prestation = TRADUCTIONS_TYPES.get(nom, (nom, d.get("prestation", nom)))
                d.setdefault("libelle_en", libelle)
                d.setdefault("prestation_en", prestation)
        cfg["version_config"] = 5
        modifie = True
    for nom, d in cfg.get("types", {}).items():
        if "pied" not in d:
            d["pied"] = "pied_caracterisation.html" if "caract" in nom.lower() else "pied.html"
            modifie = True
    if modifie and CONFIG.exists():
        sauver_config(cfg)
    return cfg


def sauver_config(cfg):
    CONFIG.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")


# ---------- accents et noms de fichiers ----------
def nfc(texte):
    """Forme normalisée : un 'é' composé ou décomposé (e + accent) devient identique."""
    return unicodedata.normalize("NFC", texte)


def nettoyer(nom):
    return re.sub(r'[\\/:*?"<>|]+', "-", nfc(nom)).strip().rstrip(".")


def sans_accents(texte):
    return "".join(c for c in unicodedata.normalize("NFD", texte) if not unicodedata.combining(c))


def trouver_fichier(dossier, nom):
    """Retrouve un fichier malgré les différences d'accents (é composé / décomposé, ou absent)."""
    d = Path(dossier)
    direct = d / nom
    if direct.exists():
        return direct
    if d.exists():
        fichiers = [f for f in d.iterdir() if f.is_file()]
        for cle in (lambda t: nfc(t).casefold(), lambda t: sans_accents(nfc(t)).casefold()):
            trouves = [f for f in fichiers if cle(f.name) == cle(nom)]
            if trouves:
                return max(trouves, key=lambda f: f.stat().st_mtime)
    return direct


def corriger_chemin(chemin):
    p = Path(chemin)
    if p.exists():
        return p
    for forme in ("NFC", "NFD"):
        q = Path(unicodedata.normalize(forme, str(p)))
        if q.exists():
            return q
    return trouver_fichier(p.parent, p.name)


def remplacer_fichier(dossier, ancien_nom, source):
    """Archive l'ancienne version (_archives, horodatée) puis installe la nouvelle. Renvoie son nom."""
    dossier, source = Path(dossier), Path(source)
    archives = dossier / "_archives"
    archives.mkdir(parents=True, exist_ok=True)
    temp = dossier / (".tmp_" + uuid.uuid4().hex[:6])
    shutil.copy2(source, temp)
    ancien = trouver_fichier(dossier, ancien_nom)
    if ancien.exists():
        shutil.move(str(ancien), str(archives / f"{datetime.now():%Y%m%d-%H%M%S}_{ancien.name}"))
    dest = dossier / nettoyer(source.name)
    if dest.exists():
        shutil.move(str(dest), str(archives / f"{datetime.now():%Y%m%d-%H%M%S}_{dest.name}"))
    temp.rename(dest)
    return dest.name


# ---------- interventions ----------
def aujourdhui():
    return datetime.now().strftime(DATE_FMT)


def lire_date(texte, nom):
    try:
        return datetime.strptime(texte.strip(), DATE_FMT)
    except (ValueError, AttributeError):
        raise ValueError(f"Date {nom} invalide (format JJ/MM/AAAA).") from None


def lang(iv):
    """Langue du mail d'une intervention : « FR » ou « EN »."""
    return "EN" if (iv or {}).get("langue") == "EN" else "FR"


def fmt_heure(hhmm, langue="FR"):
    """'14:00' -> '14h00' (français) ou '14:00' (anglais, 24 h)."""
    return hhmm if langue == "EN" else hhmm.replace(":", "h")


def fmt_date(texte, langue="FR"):
    """'14/10/2026' -> '14/10/2026' (français) ou '14 October 2026' (anglais) ; texte illisible : inchangé."""
    if langue != "EN":
        return texte
    try:
        d = datetime.strptime(texte.strip(), DATE_FMT)
    except (ValueError, AttributeError):
        return texte
    return f"{d.day} {MOIS_EN[d.month - 1]} {d.year}"


def libelle_type(cfg, kind, t, langue="FR"):
    """Nom d'un type d'intervention dans l'objet du mail (anglais : `libelle_en`, à défaut le nom français)."""
    return defs_types(cfg, kind)[t].get("libelle_en", t) if langue == "EN" else t


def defauts_jri():
    t = aujourdhui()
    return {"nature": "installation", "hebergement": "Cloud", "gateway": False, "gateway_mode": "ETH",
            "link": False, "link_mode": "POE", "mysirius_serveur": False,
            "teams": False, "teams_date": t, "teams_heure": "14:00",
            "visite": False, "visite_date": t, "visite_heure": "10:00", "visite_avec": "",
            "deploiement": True, "deploiement_debut": t, "deploiement_fin": t,
            "formation": False, "formation_date": t}


def normaliser_iv(kind, iv):
    """Complète une intervention enregistrée par une version précédente."""
    iv.setdefault("debut", aujourdhui())
    iv.setdefault("fin", aujourdhui())
    if iv.get("langue") not in LANGUES:
        iv["langue"] = "FR"              # D-057 : langue du mail
    iv.setdefault("coche", True)         # D-050 : l'intervention est traitée par « Créer et ouvrir les brouillons »
    iv.setdefault("fichiers_sup", [])    # D-054 : fichiers de tout format joints en plus
    if kind in KINDS_TYPES:
        iv.setdefault("types", [])
        iv.setdefault("fichiers_prec", {})
    else:
        if "preinstall" in iv:
            iv["visite"] = iv.pop("preinstall")
        for k, v in defauts_jri().items():
            iv.setdefault(k, v)
    if iv.get("statut") not in ICONES:
        iv["statut"] = "À faire"
    return iv


def nouvelle_intervention(kind, cfg=None):
    iv = {"id": uuid.uuid4().hex[:8], "client": "", "commande": "", "debut": aujourdhui(), "langue": "FR",
          "fin": aujourdhui(), "technicien": "", "destinataires": "", "cc_tech": True,  # intervenant à choisir (D-055)
          "statut": "À faire", "erreur": ""}
    return normaliser_iv(kind, iv)


def bornes_jri(iv):
    """Début / fin d'une intervention JRI = première et dernière date des sections actives."""
    dates = []
    for cle in ("teams_date", "visite_date", "deploiement_debut", "deploiement_fin", "formation_date"):
        section = cle.split("_")[0]
        if iv.get(section):
            try:
                dates.append(datetime.strptime(iv[cle].strip(), DATE_FMT))
            except ValueError:
                pass
    if dates:
        iv["debut"], iv["fin"] = min(dates).strftime(DATE_FMT), max(dates).strftime(DATE_FMT)
    return iv


CLES_A_VERIFIER = ("nature", "hebergement", "gateway", "gateway_mode", "link", "link_mode", "mysirius_serveur")


def appliquer_import_jri(iv, p):
    """Renseigne une fiche JRI d'après une ligne importée : client, commande, date de début du déploiement (la fin est
    identique), nature et hébergement s'ils figurent dans le fichier. La fiche reste « à vérifier » (nature, hébergement,
    prérequis) tant que l'utilisateur n'a pas modifié l'un de ces choix, sauf si nature et hébergement sont fournis."""
    iv.update(client=p["client"], commande=p["commande"])
    if p.get("date_debut"):
        iv["deploiement_debut"] = iv["deploiement_fin"] = p["date_debut"]
    if p.get("nature"):
        iv["nature"] = p["nature"]
    if p.get("hebergement"):
        iv["hebergement"] = p["hebergement"]
    iv["a_verifier"] = not (p.get("nature") and p.get("hebergement"))
    return bornes_jri(iv)


def est_vide(iv, kind):
    """Fiche jamais remplie : aucun client, commande, destinataire, type ni prérequis / section choisis."""
    if iv.get("statut", "À faire") != "À faire":
        return False
    if any(str(iv.get(k, "")).strip() for k in ("client", "commande", "destinataires")):
        return False
    if kind in KINDS_TYPES:
        return not (iv.get("types") or iv.get("fichiers_prec"))
    return not any(iv.get(k) for k in ("gateway", "link", "mysirius_serveur", "teams", "visite", "formation"))


def purger_vides(campagne, kind, garder=None):
    """Liste sans les fiches vides (la fiche `garder`, en cours de saisie, est toujours conservée)."""
    return [iv for iv in campagne if iv is garder or not est_vide(iv, kind)]


def copie_sans_email(cfg, iv):
    """True si l'intervenant doit être mis en copie mais n'a pas d'adresse e-mail dans les paramètres."""
    if not iv.get("cc_tech"):
        return False
    tech = trouver_tech(cfg, iv.get("technicien", ""))
    return bool(tech) and not (tech.get("email") or "").strip()


def defs_types(cfg, kind):
    """Définition des types d'intervention de l'onglet (COFRAC : `types`, Non COFRAC : `types_nc`)."""
    return cfg["types_nc"] if kind == "nc" else cfg["types"]


def modele_du_type(cfg, kind, t):
    """Nom du fichier modèle joint pour un type (chaîne vide : aucune pièce jointe). `modele_comme` : même fichier que le type
    COFRAC indiqué (ex. la métrologie non COFRAC reprend la revue technique de la métrologie COFRAC)."""
    d = defs_types(cfg, kind)[t]
    if d.get("modele_comme"):
        d = cfg["types"].get(d["modele_comme"], {})
    return d.get("modele", "")


def _cle_recherche(texte):
    """Texte comparable pour la recherche : sans accents ni casse, espaces simples."""
    return " ".join(_sans_accents_nom(texte or "").lower().split())


def suggestions_intervenants(techniciens, texte, maxi=8):
    """Intervenants correspondant à ce qui est tapé : tous les mots saisis doivent figurer dans le nom ou l'adresse (sans
    accents ni casse) ; les noms qui commencent par la saisie passent en premier. Texte vide : les premiers de la liste."""
    mots = _cle_recherche(texte).split()
    trouves = []
    for t in techniciens:
        nom, email = _cle_recherche(t.get("nom", "")), _cle_recherche(t.get("email", ""))
        if all(m in nom or m in email for m in mots):
            trouves.append((0 if mots and nom.startswith(" ".join(mots)) else 1, nom, t))
    trouves.sort(key=lambda x: (x[0], x[1]))
    return [t for _, _, t in trouves][:maxi]


def trouver_tech(cfg, nom):
    return next((t for t in cfg["techniciens"] if t["nom"] == nom), None)


def modes_prerequis(cfg, cle, hebergement):
    """Variantes proposées pour Link / Gateway selon l'hébergement (pas de Gateway 4G + ETH en Serveur)."""
    return list(cfg["prerequis"].get(cle, {}).get(hebergement, {}))


def prerequis_selectionnes(cfg, iv):
    """Liste (libellé, nom de fichier, libellé pour le mail) selon les choix JRI."""
    p, h, res = cfg["prerequis"], iv["hebergement"], []
    libelles = LIBELLES_MAIL_EN if lang(iv) == "EN" else LIBELLES_MAIL
    for cle, actif, mode in (("Link", iv["link"], iv["link_mode"]),
                             ("Gateway", iv["gateway"], iv["gateway_mode"])):
        if actif:
            nom = p[cle].get(h, {}).get(mode)
            if not nom:
                raise ValueError(f"Aucun prérequis {cle} « {mode} » en {h} : fichier non défini.")
            libelle = "Link Nano Wifi" if (cle == "Link" and mode == "WIFI") else libelles[cle]
            res.append((f"{cle} {mode} ({h})", nom, libelle))
    if iv["mysirius_serveur"]:
        res.append(("MySirius Serveur", p["MySirius Serveur"], libelles["MySirius Serveur"]))
    return res


def valider(cfg, iv, kind):
    if not (iv["client"].strip() and iv["commande"].strip()):
        raise ValueError("Client et n° de commande sont obligatoires.")
    if not trouver_tech(cfg, iv["technicien"]):
        raise ValueError("Intervenant non sélectionné.")
    if kind in KINDS_TYPES:
        if not iv["types"]:
            raise ValueError("Sélectionner au moins un type d'intervention.")
        d1, d2 = lire_date(iv["debut"], "de début"), lire_date(iv["fin"], "de fin")
        if d2 < d1:
            raise ValueError("La date de fin ne peut pas précéder la date de début.")
        return
    actives = [k for k in SECTIONS_JRI if iv[k]]
    if not (prerequis_selectionnes(cfg, iv) or actives):
        raise ValueError("Sélectionner au moins un prérequis ou une section (Teams, visite, déploiement, formation).")
    for cle, nom in (("teams_date", "de la réunion Teams"), ("visite_date", "de la visite"),
                     ("deploiement_debut", "de début du déploiement"), ("deploiement_fin", "de fin du déploiement"),
                     ("formation_date", "de la formation")):
        if iv[cle.split("_")[0]]:
            lire_date(iv[cle], nom)
    if iv["deploiement"] and lire_date(iv["deploiement_fin"], "") < lire_date(iv["deploiement_debut"], ""):
        raise ValueError("La date de fin du déploiement ne peut pas précéder la date de début.")
    bornes_jri(iv)


def construire_objet(cfg, iv, kind):
    """Type / N° de commande / Client."""
    if kind == "jri":
        type_ = f"{iv['nature']} MySirius {iv['hebergement']}".upper()
    else:
        type_ = cfg["separateur_types"].join(libelle_type(cfg, kind, t, lang(iv)) for t in iv["types"])
    return cfg["separateur_objet"].join([type_, iv["commande"].strip(), iv["client"].strip()])


def _periode(debut, fin, langue="FR"):
    d1, d2 = lire_date(debut, "de début"), lire_date(fin, "de fin")
    if langue == "EN":
        e1, e2 = fmt_date(f"{d1:{DATE_FMT}}", "EN"), fmt_date(f"{d2:{DATE_FMT}}", "EN")
        return f"on {e1}" if d1 == d2 else f"from {e1} to {e2}"
    return f"le {d1:{DATE_FMT}}" if d1 == d2 else f"du {d1:{DATE_FMT}} au {d2:{DATE_FMT}}"


def _valeurs(cfg, iv, kind):
    if kind == "jri":
        bornes_jri(iv)
    tech = trouver_tech(cfg, iv["technicien"])
    civ = tech.get("civilite", "M.")
    if lang(iv) == "EN":
        civ = CIVILITES_EN.get(civ, civ)
    return {"client": escape(iv["client"]), "commande": escape(iv["commande"]),
            "technicien": escape(tech["nom"]), "civilite": escape(civ),
            "intervenant": f"<b>{escape(civ)} {escape(tech['nom'])}</b>",
            "periode": f"<b>{_periode(iv['debut'], iv['fin'], lang(iv))}</b>"}


def _lire(nom, valeurs, langue="FR"):
    """Modèle de mail : `templates/` en français, `templates/en/` en anglais."""
    chemin = BASE / "templates" / ("en" if langue == "EN" else "") / nom
    if not chemin.exists():
        raise FileNotFoundError(f"Modèle de mail introuvable ({'anglais' if langue == 'EN' else 'français'}) : {chemin}")
    return chemin.read_text(encoding="utf-8").format_map(valeurs)


def tableau_reseau(iv, langue="FR"):
    """Tableau des flux à ouvrir (Link Nano / Gateway), Cloud ou Serveur."""
    if not (iv["link"] or iv["gateway"]):
        return ""
    serveur = iv["hebergement"] == "Serveur"
    dest = "@IP_SERVEUR" if serveur else "device.jri-mysirius.com"
    lignes = []
    if iv["link"]:
        lignes.append(("Link Nano", "13251", "13251"))
    if iv["gateway"]:
        ports = "13252" if serveur else "13252<br>8443"
        lignes.append(("Gateway", ports, ports))
    st = 'style="border:1px solid #999;padding:4px 8px;text-align:left"'
    entete = (("Solutions", "Source port", "Source IP", "Protocol", "Destination port", "Destination") if langue == "EN"
              else ("Solutions", "Port source", "IP Source", "Protocole", "Port Destination", "Destination"))
    th = "".join(f"<th {st}>{h}</th>" for h in entete)
    tr = "".join("<tr>" + "".join(f"<td {st}>{c}</td>" for c in (n, ps, "X_IP", "TCP", pd, dest)) + "</tr>"
                 for n, ps, pd in lignes)
    return f'<table style="border-collapse:collapse"><tr>{th}</tr>{tr}</table>'


def _corps_jri(cfg, iv, v):
    L = lang(iv)
    prerequis = prerequis_selectionnes(cfg, iv)
    v.update(nature=iv["nature"], hebergement=iv["hebergement"])
    blocs, n = [_lire("jri_entete.html", v, L)], 0
    if iv["teams"]:
        n += 1
        fin = datetime.strptime(iv["teams_heure"], "%H:%M") + timedelta(hours=1)
        blocs.append(_lire("jri_teams.html", dict(v, n=n, date=fmt_date(iv["teams_date"], L),
                                                   de=fmt_heure(iv["teams_heure"], L),
                                                   a=fmt_heure(fin.strftime("%H:%M"), L)), L))
    if iv["visite"]:
        n += 1
        tech = trouver_tech(cfg, iv["technicien"])
        civ = tech.get("civilite", "M.")
        noms = [x.strip() for x in iv["visite_avec"].split(";") if x.strip()] or [
            f"{CIVILITES_EN.get(civ, civ) if L == 'EN' else civ} {tech['nom']}"]
        liste = "".join(f"<li><b>{escape(x)}</b></li>" for x in noms)
        blocs.append(_lire("jri_visite.html", dict(v, n=n, date=fmt_date(iv["visite_date"], L),
                                                    heure=fmt_heure(iv["visite_heure"], L), liste_participants=liste), L))
    if iv["deploiement"]:
        n += 1
        d1, d2 = fmt_date(iv["deploiement_debut"], L), fmt_date(iv["deploiement_fin"], L)
        if L == "EN":
            periode = f"on <b>{d1}</b>" if d1 == d2 else f"from <b>{d1}</b> to <b>{d2}</b>"
        else:
            periode = f"le <b>{d1}</b>" if d1 == d2 else f"du <b>{d1}</b> au <b>{d2}</b>"
        blocs.append(_lire("jri_deploiement.html", dict(v, n=n, periode_deploiement=periode), L))
    if iv["formation"]:
        blocs.append(_lire("jri_formation.html", dict(v, date=fmt_date(iv["formation_date"], L)), L))
    if prerequis:
        liste = "".join(f"<li>{escape(m)}</li>" for _, _, m in prerequis)
        blocs.append(_lire("jri_prerequis.html", dict(v, liste_prerequis=liste, tableau_reseau=tableau_reseau(iv, L)), L))
    blocs.append(_lire("jri_pied.html", v, L))
    return blocs


def construire_corps(cfg, iv, kind):
    v = _valeurs(cfg, iv, kind)
    if kind in KINDS_TYPES:
        types = defs_types(cfg, kind)
        L = lang(iv)
        if L == "EN":
            v["prestations"] = " and ".join(types[t].get("prestation_en", types[t]["prestation"]) for t in iv["types"])
        else:
            v["prestations"] = " et ".join(types[t]["prestation"] for t in iv["types"])
        blocs = [_lire("nc_entete.html" if kind == "nc" else "entete.html", v, L)]
        for t in iv["types"]:
            bloc = _lire(types[t]["template"], v, L)
            if not bloc.strip():
                continue  # type sans texte propre (Non COFRAC) : ni titre ni bloc vide
            blocs.append(f"<p><b>{escape(libelle_type(cfg, kind, t, L))}</b></p>{bloc}" if len(iv["types"]) > 1 else bloc)
        pied = types[iv["types"][0]].get("pied") or "pied.html" if len(iv["types"]) == 1 else "pied.html"
        blocs.append(_lire(pied, v, L))
    else:
        blocs = _corps_jri(cfg, iv, v)
    return '<div style="font-family:Calibri,Arial,sans-serif;font-size:11pt">' + "".join(blocs) + "</div>"


def _pieces_jointes_base(cfg, iv, kind):
    if kind == "jri":
        res, vus = [], set()
        for _, nom, _m in prerequis_selectionnes(cfg, iv):
            f = trouver_fichier(BASE / "modeles" / "prerequis", nom)
            if not f.exists():
                raise FileNotFoundError(f"Fichier de prérequis introuvable : {f}")
            if f not in vus:
                vus.add(f)
                res.append(f)
        return res
    types = defs_types(cfg, kind)
    avec_pj = [t for t in iv["types"] if modele_du_type(cfg, kind, t)]
    if not avec_pj:
        return []  # types sans pièce jointe (ex. Non COFRAC)
    annee = datetime.now().year
    dossier = BASE / "envois" / str(annee) / nettoyer(f"{iv['client']}_{iv['commande']}")
    dossier.mkdir(parents=True, exist_ok=True)
    sources = {}
    for t in avec_pj:
        prec = iv["fichiers_prec"].get(t)
        source = corriger_chemin(prec) if prec else trouver_fichier(BASE / "modeles", modele_du_type(cfg, kind, t))
        if not source.exists():
            raise FileNotFoundError(f"Fichier introuvable : {source}")
        sources[t] = source
    noms = {t: nettoyer(types[t]["nom_pj"].format(client=iv["client"].strip(), annee=annee))
            for t in avec_pj}
    doublons = {n for n, c in Counter(noms.values()).items() if c > 1}
    sorties = []
    for t, source in sources.items():
        nom = f"{noms[t]} ({t})" if noms[t] in doublons else noms[t]
        dest = dossier / (nom + source.suffix)
        if source.resolve() != dest.resolve():
            shutil.copy2(source, dest)
        sorties.append(dest)
    return sorties


def fichiers_supplementaires(iv):
    """Fichiers de tout format joints en plus (D-054), avec leur nom d'origine ; lève FileNotFoundError s'ils ont disparu."""
    res = []
    for chemin in iv.get("fichiers_sup") or []:
        f = corriger_chemin(chemin)
        if not f.exists():
            raise FileNotFoundError(f"Fichier à joindre introuvable : {chemin}")
        res.append(f)
    return res


def preparer_pieces_jointes(cfg, iv, kind):
    """Pièces jointes d'une intervention : modèles ou prérequis selon l'onglet, puis fichiers supplémentaires."""
    return _pieces_jointes_base(cfg, iv, kind) + fichiers_supplementaires(iv)


def ajouter_images(mail, corps):
    """Images inline (cid:xxx -> modeles/images/xxx.*). Image absente : balise retirée."""
    for cid in set(re.findall(r"cid:([\w-]+)", corps)):
        trouves = list((BASE / "modeles" / "images").glob(cid + ".*"))
        if not trouves:
            corps = re.sub(rf'<img[^>]*cid:{cid}[^>]*>', "", corps)
            continue
        pa = mail.Attachments.Add(str(trouves[0])).PropertyAccessor
        pa.SetProperty("http://schemas.microsoft.com/mapi/proptag/0x3712001F", cid)
        pa.SetProperty("http://schemas.microsoft.com/mapi/proptag/0x7FFE000B", True)
    return corps


def _inserer_corps(base, corps):
    m = re.search(r"<body[^>]*>", base, re.I)
    return base[:m.end()] + corps + base[m.end():] if m else corps + base


def creer_brouillon(outlook, cfg, iv, kind):
    """Crée le mail et l'ouvre dans Outlook (jamais d'envoi automatique)."""
    objet = construire_objet(cfg, iv, kind)
    corps = construire_corps(cfg, iv, kind)
    pj = preparer_pieces_jointes(cfg, iv, kind)
    tech = trouver_tech(cfg, iv["technicien"])
    mail = outlook.CreateItem(0)
    if kind != "nc" and expediteur_effectif(cfg):  # Non COFRAC : adresse personnelle de la personne (D-052)
        mail.SentOnBehalfOfName = expediteur_effectif(cfg)
    mail.Subject = objet
    mail.To = iv["destinataires"].strip()
    mail.CC = tech.get("email", "") if iv.get("cc_tech") else ""
    _ = mail.GetInspector  # charge la signature par défaut
    base = mail.HTMLBody
    corps = ajouter_images(mail, corps)
    mail.HTMLBody = _inserer_corps(base, corps)
    for chemin in pj:
        mail.Attachments.Add(str(chemin))
    mail.Display(False)
    return objet


# ---------- journal, carnet d'adresses ----------
def ajouter_journal(entree):
    data = charger_json(JOURNAL, [])
    data.insert(0, entree)
    ecrire_json(JOURNAL, data[:500])


def charger_carnet():
    return charger_json(CARNET, [])


def memoriser_destinataires(texte):
    carnet = charger_carnet()
    for adr in reversed([a.strip() for a in re.split(r"[;,]", texte) if "@" in a]):
        carnet = [adr] + [c for c in carnet if c.lower() != adr.lower()]
    ecrire_json(CARNET, carnet[:2000])


def fusionner_carnet(carnet, nouvelles):
    """Ajoute à la suite du carnet les adresses nouvelles (sans doublon, sans tenir compte de la casse).
    Renvoie (carnet complété, nombre d'adresses ajoutées)."""
    connues = {a.lower() for a in carnet}
    res, ajoutees = list(carnet), 0
    for adr in nouvelles:
        adr = adr.strip()
        if "@" in adr and adr.lower() not in connues:
            connues.add(adr.lower())
            res.append(adr)
            ajoutees += 1
    return res[:2000], ajoutees


def suggestions_carnet(carnet, texte, maxi=6, avec_base=True):
    """Adresses correspondant au mot en cours de saisie (après le dernier « ; »), insensible aux accents et à la casse.
    Le carnet (adresses utilisées, récentes d'abord) passe avant la base d'Outlook ; les adresses déjà saisies sont exclues."""
    mot = sans_accents(nfc(texte.split(";")[-1])).casefold().strip()
    if not mot:
        return []
    deja = {a.strip().lower() for a in texte.split(";")[:-1]}
    res = [a for a in carnet if mot in sans_accents(nfc(a)).casefold() and a.lower() not in deja][:maxi]
    if avec_base and len(res) < maxi:
        exclus = deja | {a.lower() for a in res}
        res += adresses.rechercher_base(mot, exclus, maxi - len(res))
    return res


def appliquer_suggestion(texte, adresse):
    """Remplace le mot en cours par l'adresse choisie et prépare la saisie suivante (« ; » + espace)."""
    base = texte.rsplit(";", 1)[0].strip() if ";" in texte else ""
    return (base + "; " if base else "") + adresse + "; "


def retirer_du_carnet(adresse):
    ecrire_json(CARNET, [c for c in charger_carnet() if c != adresse])


# ---------- suivi, relances ----------
def charger_suivi():
    """Suivi courant (local ou partagé). La liste garde son état d'origine : seules les modifications sont enregistrées."""
    suivi = ListeSuivi(partage.lire_brut())
    for e in suivi:
        e.setdefault("relances", [])
        if not e.get("premier_mail"):
            e["premier_mail"] = (e.get("maj") or datetime.now().isoformat())[:10]
            e["premier_mail_estime"] = True
    return partage.figer(suivi)


def sauver_suivi(suivi):
    """Enregistre le suivi chargé par charger_suivi() : suivi.json en local, événements signés en partagé."""
    partage.sauver(suivi)


def trigrammes_connus(suivi, moi=""):
    """Trigrammes proposables pour « En charge » : cartes du suivi, auteurs du suivi partagé et utilisateur courant."""
    res = {e.get("en_charge") for e in suivi if e.get("en_charge")} | partage.auteurs()
    if moi:
        res.add(moi)
    return sorted(t for t in res if t and t != "?")


def ajouter_suivi(iv, kind, titre, objet, en_charge=""):
    """Ajoute (ou met à jour) l'intervention dans le suivi, avec une copie pour pouvoir la restaurer."""
    suivi = charger_suivi()
    e = next((x for x in suivi if x["onglet"] == kind and x["iv_id"] == iv["id"]), None)
    if e is None:
        e = {"id": uuid.uuid4().hex[:8], "onglet": kind, "iv_id": iv["id"], "etat": ETATS[0], "relances": [],
             "premier_mail": date.today().isoformat(), "premier_mail_estime": True, "en_charge": en_charge}
        suivi.append(e)
    copie = deepcopy(iv)
    if "fichiers_prec" in copie:
        copie["fichiers_prec"] = {}  # D-028 : un chemin de fichier est propre à un poste, il n'a pas sa place dans le suivi
    copie["fichiers_sup"] = []       # idem pour les fichiers supplémentaires (D-054)
    e.update(titre=titre, objet=objet, debut=iv["debut"], fin=iv["fin"], iv=copie,
             maj=datetime.now().isoformat(timespec="seconds"))
    return suivi, e


def migrer_planifies(kind, campagne):
    """v1.2 gardait les interventions 'Planifié' dans la campagne : elles ne vivent plus que dans le suivi."""
    suivi, modifie, restes = charger_suivi(), False, []
    for iv in campagne:
        if iv.get("statut") != "Planifié":
            restes.append(iv)
            continue
        e = next((x for x in suivi if x["onglet"] == kind and x["iv_id"] == iv["id"]), None)
        if e is None:
            iv["statut"] = "Brouillon"
            restes.append(iv)
        elif "iv" not in e:
            e["iv"], modifie = deepcopy(iv), True
    if modifie:
        sauver_suivi(suivi)
    return restes


def pastille_relance(e, aujourdhui_=None):
    """None, 'rouge' (à relancer) ou 'orange' (relancé depuis moins d'une semaine)."""
    if e["etat"] == "Validée":
        return None
    jour = aujourdhui_ or date.today()
    if e.get("relances"):
        derniere = date.fromisoformat(e["relances"][-1])
        return "orange" if (jour - derniere).days < DELAI_RELANCE else "rouge"
    if e.get("premier_mail") and (jour - date.fromisoformat(e["premier_mail"])).days >= DELAI_RELANCE:
        return "rouge"
    return None


def lignes_carte(e):
    """Deux lignes d'une carte du suivi : client ; commande · type (ou nature + hébergement)."""
    iv = e.get("iv") or {}
    if iv.get("client"):
        if e.get("onglet") == "jri":
            detail = f"{iv.get('nature', '').capitalize()} {iv.get('hebergement', '')}".strip()
        else:
            detail = " + ".join(t.split()[0] for t in iv.get("types", []))
        return iv["client"], " · ".join(x for x in (iv.get("commande"), detail, "EN" if lang(iv) == "EN" else "") if x)
    morceaux = e.get("titre", "").split(" · ")
    return morceaux[0], " · ".join(morceaux[1:])


def correspond_suivi(e, texte):
    """Recherche (sans accents ni majuscules) dans le client, la commande, le titre et l'objet."""
    cle = sans_accents(nfc(texte)).casefold().strip()
    if not cle:
        return True
    iv = e.get("iv") or {}
    champs = " ".join([e.get("titre", ""), e.get("objet", ""), iv.get("client", ""), iv.get("commande", ""),
                       e.get("en_charge", "")])
    return cle in sans_accents(nfc(champs)).casefold()


def trier_suivi(suivi, aujourdhui_=None):
    """Du plus proche au plus lointain par rapport à aujourd'hui (sur la date de début)."""
    jour = aujourdhui_ or date.today()

    def debut(e):
        try:
            return datetime.strptime(e["debut"], DATE_FMT).date()
        except (ValueError, KeyError):
            return date.max

    return sorted(suivi, key=lambda e: (abs((debut(e) - jour).days) if debut(e) != date.max else 10**9, debut(e)))


def ajouter_mois(jour, n=1):
    """Même jour, n mois plus tard (le dernier jour du mois si le jour n'existe pas : 31/01 -> 28/02)."""
    m = jour.month - 1 + n
    annee, mois = jour.year + m // 12, m % 12 + 1
    return date(annee, mois, min(jour.day, calendar.monthrange(annee, mois)[1]))


def date_fin_carte(e):
    try:
        return datetime.strptime(e["fin"], DATE_FMT).date()
    except (ValueError, KeyError, TypeError):
        return None


def est_archivee(e, jour=None):
    """Carte « Validée » dont la date de fin remonte à un mois ou plus (D-051). Calculé d'après la date : rien n'est déplacé, le
    résultat est identique pour tous les postes en suivi partagé. `archive_levee` : carte remise dans le suivi par l'utilisateur."""
    if e.get("etat") != "Validée" or e.get("archive_levee"):
        return False
    fin = date_fin_carte(e)
    return fin is not None and (jour or date.today()) >= ajouter_mois(fin, 1)


def trier_archives(cartes):
    """Archives : les plus récentes d'abord (date de fin décroissante)."""
    return sorted(cartes, key=lambda e: date_fin_carte(e) or date.min, reverse=True)


def fr(iso):
    return date.fromisoformat(iso).strftime(DATE_FMT) if iso else ""


def _memoriser_mail(e, item):
    e["entry_id"] = item.EntryID
    s = item.SentOn
    e["premier_mail"] = date(s.year, s.month, s.day).isoformat()
    e["premier_mail_estime"] = False


def dossier_memorise():
    """Dossier « Éléments envoyés » de la boîte partagée choisi par l'utilisateur dans Outlook (Paramètres › Poste), ou None."""
    d = partage.reglages().get("envoyes_planning")
    return d if isinstance(d, dict) and d.get("entry_id") else None


def dossiers_envoyes(outlook, boite="", memorise=None):
    """Dossiers « Éléments envoyés » où chercher : la boîte partagée indiquée (dossier mémorisé, raccourci, puis recherche
    de la boîte : voir adresses.localiser_envoyes), puis la boîte par défaut."""
    memorise = dossier_memorise() if memorise is None else memorise
    return [s["dossier"] for s in adresses.localiser_envoyes(outlook, boite, memorise) if s["dossier"] is not None]


def retrouver_mail_envoye(outlook, objet, limite=300, boite="", rapport=None, memorise=None):
    """Dernier mail envoyé ayant exactement cet objet (boîte partagée d'abord, puis boîte par défaut). Si `rapport` est une
    liste, elle reçoit une ligne par boîte consultée (nombre de mails examinés, ou raison de l'inaccessibilité)."""
    cible = nfc(objet).strip().casefold()
    memorise = dossier_memorise() if memorise is None else memorise
    for source in adresses.localiser_envoyes(outlook, boite, memorise):
        if source["dossier"] is None:
            if rapport is not None:
                rapport.append(f"{source['libelle']} : inaccessible ({source['erreur']})")
            continue
        try:
            envoyes = source["dossier"].Items
            envoyes.Sort("[SentOn]", True)
        except Exception as exc:
            if rapport is not None:
                rapport.append(f"{source['libelle']} ({source['methode']}) : lecture impossible ({exc})")
            continue
        examines = 0
        for i, item in enumerate(envoyes):
            if i >= limite:
                break
            examines += 1
            try:
                if nfc(item.Subject or "").strip().casefold() == cible:
                    return item
            except Exception:
                continue
        if rapport is not None:
            rapport.append(f"{source['libelle']} ({source['methode']}) : {examines} mail(s) examiné(s), aucun ne porte cet objet")
    return None


def lier_mail_envoye(outlook, e, boite=""):
    perso = e.get("onglet") == "nc"  # Non COFRAC : le mail part de l'adresse personnelle, il est dans les envoyés de son auteur
    item = retrouver_mail_envoye(outlook, e["objet"], boite="" if perso else boite, memorise={} if perso else None)
    if item is not None:
        _memoriser_mail(e, item)
    return item is not None


def creer_relance(outlook, cfg, e, boite=""):
    """Ouvre une réponse au mail initial (même conversation Outlook) avec le texte de relance."""
    item = None
    if e.get("entry_id"):
        try:
            item = outlook.GetNamespace("MAPI").GetItemFromID(e["entry_id"])
        except Exception:
            item = None
    perso = e.get("onglet") == "nc"
    if item is None:
        consultees = []
        item = retrouver_mail_envoye(outlook, e["objet"], boite="" if perso else boite, rapport=consultees,
                                     memorise={} if perso else None)
        if item is None:
            conseil = ("Vérifiez que le mail a bien été envoyé avec cet objet exact.")
            if perso:
                conseil += ("\nLes mails Non COFRAC partent de l'adresse personnelle de la personne qui les envoie : "
                            "seule cette personne (« En charge ») retrouve ce mail dans ses éléments envoyés et peut le relancer.")
            if any("inaccessible" in ligne for ligne in consultees):
                conseil += ("\nUne boîte est inaccessible : dans Outlook, sélectionnez le dossier « Éléments envoyés » de la "
                            "boîte partagée, puis Paramètres › Poste › « Utiliser le dossier sélectionné dans Outlook ».")
            raise LookupError("Le mail initial est introuvable dans les éléments envoyés.\n\n"
                              f"Objet cherché :\n{e['objet']}\n\nBoîtes consultées :\n"
                              + "\n".join("• " + ligne for ligne in consultees) + f"\n\n{conseil}")
        _memoriser_mail(e, item)
    rep = item.ReplyAll()
    iv = e.get("iv") or {}
    rep.To = iv.get("destinataires", "").strip() or item.To
    tech = trouver_tech(cfg, iv.get("technicien", "")) if iv else None
    rep.CC = (tech.get("email", "") if tech and iv.get("cc_tech") else "") or item.CC
    if not perso and expediteur_effectif(cfg):
        rep.SentOnBehalfOfName = expediteur_effectif(cfg)
    L = lang(iv)
    corps = _lire("relance.html", {"periode": f"<b>{_periode(e['debut'], e['fin'], L)}</b>"}, L)
    rep.HTMLBody = _inserer_corps(rep.HTMLBody, '<div style="font-family:Calibri,Arial,sans-serif;font-size:11pt">'
                                  + corps + "</div>")
    rep.Display(False)


def creer_relance_secours(outlook, cfg, e):
    """Relance de secours (D-048), quand le mail initial est introuvable : un NOUVEAU message, donc hors de la conversation
    d'origine, avec les destinataires et l'intervenant en copie de la fiche, l'objet « RE : » + objet d'origine et le texte de
    relance habituel (dans la langue de la fiche). Même expéditeur qu'une relance normale (aucun « de la part de » en Non COFRAC)."""
    iv = e.get("iv") or {}
    L = lang(iv)
    destinataires = (iv.get("destinataires") or "").strip()
    if not destinataires:
        raise ValueError("Aucun destinataire n'est enregistré sur cette carte : impossible de créer un nouveau message.")
    tech = trouver_tech(cfg, iv.get("technicien", ""))
    mail = outlook.CreateItem(0)
    if e.get("onglet") != "nc" and expediteur_effectif(cfg):
        mail.SentOnBehalfOfName = expediteur_effectif(cfg)
    mail.Subject = ("RE: " if L == "EN" else "RE : ") + e["objet"]
    mail.To = destinataires
    mail.CC = tech.get("email", "") if tech and iv.get("cc_tech") else ""
    _ = mail.GetInspector  # charge la signature par défaut
    base = mail.HTMLBody
    corps = _lire("relance.html", {"periode": f"<b>{_periode(e['debut'], e['fin'], L)}</b>"}, L)
    mail.HTMLBody = _inserer_corps(base, '<div style="font-family:Calibri,Arial,sans-serif;font-size:11pt">' + corps + "</div>")
    mail.Display(False)
