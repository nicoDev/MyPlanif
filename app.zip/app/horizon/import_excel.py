"""Import d'un export Excel, ou d'un texte collé depuis Excel : propose des fiches COFRAC / Non COFRAC / JRI
(sans interface graphique).

Deux formats :
- **COFRAC et Non COFRAC** (export de l'outil de gestion, tableau croisé) : une ligne d'en-tête contenant au moins
  « N° COMMANDE », « NOM SITE » et « GROUPE » ; une ligne par commande, suivie de lignes sans n° de commande pour les
  articles suivants ; sous-totaux et « Total général » à la fin. Une commande qui mélange des groupes COFRAC et non
  COFRAC donne **une fiche par onglet** (même n° de commande).
- **JRI** (tableau simple, une ligne par commande) : « N° COMMANDE » et « NOM SITE » obligatoires ; « DATE D'INTER »
  (date de début du déploiement), « ÉTAT COMMANDE » et, facultatives, « NATURE » et « HÉBERGEMENT » sont lues. Les
  autres colonnes sont ignorées.
"""
import csv
import io
import re
import unicodedata
from collections import OrderedDict
from datetime import date, datetime

# colonnes reconnues (titre normalisé -> clé) ; la normalisation retire accents, ponctuation et espaces
COLONNES = {"NCOMMANDE": "commande", "NUMEROCOMMANDE": "commande", "COMMANDE": "commande",
            "NOMSITE": "client", "GROUPE": "groupe", "ETATCOMMANDE": "etat", "COMMERCIALPRINCIPAL": "commercial",
            "REFERENCEARTICLE": "article", "DESIGNATIONARTICLE": "designation", "QUANTITE": "quantite",
            "DATEDINTER": "date_inter", "DATEINTER": "date_inter", "NATURE": "nature", "HEBERGEMENT": "hebergement"}
OBLIGATOIRES = ("commande", "client", "groupe")          # COFRAC et Non COFRAC
OBLIGATOIRES_JRI = ("commande", "client")                # JRI
FORMATS_DATE = ("%d/%m/%Y", "%Y-%m-%d", "%d-%m-%Y", "%d/%m/%y", "%d.%m.%Y")


def _sans_accents(texte):
    return "".join(c for c in unicodedata.normalize("NFD", str(texte)) if not unicodedata.combining(c))


def norm(texte):
    """Texte comparable : sans accents, majuscules, espaces simples."""
    return re.sub(r"\s+", " ", _sans_accents(texte or "").upper()).strip()


def _cle_colonne(titre):
    return re.sub(r"[^A-Z0-9]", "", norm(titre))


def lire_date(valeur):
    """Date lue dans une cellule Excel ou un texte (JJ/MM/AAAA, AAAA-MM-JJ…) ; None si absente ou illisible."""
    if valeur is None or valeur == "":
        return None
    if isinstance(valeur, datetime):
        return valeur.date()
    if isinstance(valeur, date):
        return valeur
    texte = str(valeur).strip()
    for format_ in FORMATS_DATE:
        for essai in (texte, texte[:10]):
            try:
                return datetime.strptime(essai, format_).date()
            except ValueError:
                continue
    return None


# ---------- lecture : fichier ou texte collé -> lignes ----------
def lire_fichier(chemin):
    """Toutes les lignes de la première feuille d'un fichier Excel (.xlsx, .xlsm)."""
    try:
        import openpyxl
    except ImportError:
        raise ImportError("La bibliothèque openpyxl est absente : relancer installer.ps1 pour l'installer.") from None
    classeur = openpyxl.load_workbook(chemin, data_only=True, read_only=True)
    try:
        return [list(r) for r in classeur.worksheets[0].iter_rows(values_only=True)]
    finally:
        classeur.close()


def lire_presse_papiers(texte):
    """Lignes d'un texte copié depuis Excel (cellules séparées par des tabulations ; « ; » ou « , » acceptés à défaut)."""
    texte = (texte or "").replace("\r\n", "\n").replace("\r", "\n").strip("\n")
    echantillon = "\n".join(texte.split("\n")[:5])
    separateur = max(("\t", ";", ","), key=lambda s: (echantillon.count(s), s == "\t"))
    return [[c.strip() for c in ligne] for ligne in csv.reader(io.StringIO(texte), delimiter=separateur)]


def _trouver_entete(lignes, obligatoires=OBLIGATOIRES):
    """(index de la ligne d'en-tête, {clé: index de colonne})."""
    for i, ligne in enumerate(lignes[:60]):
        cols = {}
        for j, valeur in enumerate(ligne):
            cle = COLONNES.get(_cle_colonne(valeur)) if valeur is not None else None
            if cle and cle not in cols:
                cols[cle] = j
        if all(c in cols for c in obligatoires):
            return i, cols
    noms = {"commande": "« N° COMMANDE »", "client": "« NOM SITE »", "groupe": "« GROUPE »"}
    raise ValueError("Colonnes introuvables : la première ligne copiée ou collée doit contenir les titres "
                     + ", ".join(noms[o] for o in obligatoires) + ".")


def _valeur(ligne, cols, cle):
    j = cols.get(cle)
    v = ligne[j] if j is not None and j < len(ligne) else None
    return v if v is not None and str(v).strip() != "" else ""


def _texte(ligne, cols, cle):
    return str(_valeur(ligne, cols, cle)).strip()


# ---------- COFRAC et Non COFRAC ----------
def type_pour_groupe(groupe, cfg):
    """(onglet, type) correspondant à un GROUPE de l'export, ou None. Le type doit exister dans config.json."""
    g = norm(groupe)
    non_cofrac = "NON COFRAC" in g
    cible = None
    if "QUALIF" in g:
        cible = ("nc", "Qualification")
    elif "HVAC" in g:
        cible = ("nc", "HVAC")
    elif "CARACT" in g:
        cible = ("nc", "Caractérisation non COFRAC") if non_cofrac else \
            (("metro", "Caractérisation COFRAC") if "COFRAC" in g else None)
    elif "METRO" in g:
        cible = ("nc", "Métrologie non COFRAC") if non_cofrac else \
            (("metro", "Métrologie COFRAC") if "COFRAC" in g else None)
    if cible is None:
        return None
    kind, nom = cible
    types = cfg["types_nc"] if kind == "nc" else cfg["types"]
    return cible if nom in types else None


def commandes_types(lignes):
    """Commandes d'un export COFRAC / Non COFRAC : [{commande, client, etat, commercial, groupes, lignes}]."""
    debut, cols = _trouver_entete(lignes)
    commandes, courante = [], None
    for ligne in lignes[debut + 1:]:
        if ligne and ligne[0] is not None and norm(ligne[0]).startswith("TOTAL"):
            break
        numero = _texte(ligne, cols, "commande")
        if numero:
            courante = {"commande": numero, "client": _texte(ligne, cols, "client"),
                        "etat": norm(_texte(ligne, cols, "etat")), "commercial": _texte(ligne, cols, "commercial"),
                        "groupes": [], "lignes": 0}
            commandes.append(courante)
        if courante is None:
            continue
        groupe = _texte(ligne, cols, "groupe")
        article = _texte(ligne, cols, "article") or _texte(ligne, cols, "designation")
        if not groupe and not article:
            continue  # ligne de sous-total (quantité seule) ou ligne vide
        courante["lignes"] += 1
        if groupe and groupe not in courante["groupes"]:
            courante["groupes"].append(groupe)
    return commandes


def lire_commandes(chemin):
    """Commandes d'un fichier d'export COFRAC / Non COFRAC (conservé pour compatibilité)."""
    return commandes_types(lire_fichier(chemin))


def _propositions_types(commandes, cfg):
    ordre = {"metro": list(cfg["types"]), "nc": list(cfg["types_nc"])}
    propositions = []
    for c in commandes:
        par_onglet, inconnus = OrderedDict(), []
        for groupe in c["groupes"]:
            cible = type_pour_groupe(groupe, cfg)
            if cible is None:
                inconnus.append(groupe)
            else:
                par_onglet.setdefault(cible[0], set()).add(cible[1])
        base = {"client": c["client"], "commande": c["commande"], "etat": c["etat"], "commercial": c["commercial"],
                "inconnus": inconnus, "doublon": False}
        for kind in ("metro", "nc"):
            if kind in par_onglet:
                types = [t for t in ordre[kind] if t in par_onglet[kind]]
                propositions.append(dict(base, kind=kind, types=types, importable=True, remarque="", cocher=False))
        if not par_onglet:
            propositions.append(dict(base, kind="metro", types=[], importable=False, remarque="", cocher=False))
    return propositions


# ---------- JRI ----------
def nature_depuis(texte):
    n = norm(texte)
    return "installation" if "INSTALL" in n else "extension" if "EXTENS" in n else ""


def hebergement_depuis(texte):
    n = norm(texte)
    return "Cloud" if "CLOUD" in n else "Serveur" if ("SERVEUR" in n or "SERVER" in n) else ""


def commandes_jri(lignes):
    """Commandes d'un tableau JRI : une ligne par commande."""
    debut, cols = _trouver_entete(lignes, OBLIGATOIRES_JRI)
    commandes = []
    for ligne in lignes[debut + 1:]:
        if ligne and ligne[0] is not None and norm(ligne[0]).startswith("TOTAL"):
            break
        numero = _texte(ligne, cols, "commande")
        if not numero:
            continue
        commandes.append({"commande": numero, "client": _texte(ligne, cols, "client"),
                          "etat": norm(_texte(ligne, cols, "etat")), "date_inter": _valeur(ligne, cols, "date_inter"),
                          "nature": nature_depuis(_texte(ligne, cols, "nature")),
                          "hebergement": hebergement_depuis(_texte(ligne, cols, "hebergement"))})
    return commandes


def _propositions_jri(commandes):
    res = []
    for c in commandes:
        jour = lire_date(c["date_inter"])
        res.append({"kind": "jri", "client": c["client"], "commande": c["commande"], "etat": c["etat"], "commercial": "",
                    "types": [], "inconnus": [], "doublon": False, "importable": bool(c["client"]),
                    "date_debut": jour.strftime("%d/%m/%Y") if jour else "",
                    "date_absente": c["date_inter"] == "", "date_illisible": c["date_inter"] != "" and jour is None,
                    "date_passee": bool(jour and jour < date.today()),
                    "nature": c["nature"], "hebergement": c["hebergement"], "remarque": "", "cocher": False})
    return res


# ---------- propositions ----------
def proposer(lignes, cfg, mode="types"):
    """Propositions de fiches d'après des lignes (fichier ou texte collé). `mode` : « types » (COFRAC et Non COFRAC,
    colonne GROUPE) ou « jri ». Renvoie {"commandes": n, "propositions": [...]}."""
    avertissement = ""
    if mode == "jri":
        commandes = commandes_jri(lignes)
        propositions = _propositions_jri(commandes)
        if "groupe" in _trouver_entete(lignes, OBLIGATOIRES_JRI)[1]:
            avertissement = ("Ce tableau contient une colonne GROUPE : c'est probablement un export COFRAC / Non COFRAC, "
                             "à importer depuis l'onglet COFRAC ou Non COFRAC.")
    else:
        commandes = commandes_types(lignes)
        propositions = _propositions_types(commandes, cfg)
    for p in propositions:
        p["remarque"] = remarque_de(p)
        p["cocher"] = cochee_par_defaut(p)
    return {"commandes": len(commandes), "propositions": propositions, "avertissement": avertissement}


def lire_export(chemin, cfg):
    """Propositions COFRAC / Non COFRAC d'un fichier d'export (conservé pour compatibilité)."""
    return proposer(lire_fichier(chemin), cfg, "types")


def remarque_de(p):
    notes = []
    if p["kind"] == "jri":
        if not p["client"]:
            notes.append("NOM SITE absent")
        if p.get("date_absente"):
            notes.append("date d'intervention absente")
        elif p.get("date_illisible"):
            notes.append("date illisible")
        elif p.get("date_passee"):
            notes.append("date passée")
    elif not p["types"]:
        notes.append("groupe non reconnu : " + (", ".join(p["inconnus"]) or "aucun"))
    elif p["inconnus"]:
        notes.append("groupe ignoré : " + ", ".join(p["inconnus"]))
    if p["doublon"]:
        notes.append("déjà présente")
    if p["etat"] and p["etat"] != "ACTIVE":
        notes.append("commande " + p["etat"].lower())
    return " · ".join(notes)


def cochee_par_defaut(p):
    return bool(p["importable"]) and p["etat"] == "ACTIVE" and not p["doublon"]


def cle_commande(texte):
    return re.sub(r"\s+", "", norm(texte))


def marquer_doublons(propositions, existantes):
    """`existantes` : ensemble de (onglet, cle_commande) déjà présents dans la planification ou le suivi."""
    for p in propositions:
        p["doublon"] = (p["kind"], cle_commande(p["commande"])) in existantes
        p["remarque"] = remarque_de(p)
        p["cocher"] = cochee_par_defaut(p)
    return propositions


def types_import(p):
    """Types de la proposition, dans l'ordre de config.json."""
    return list(p["types"])
